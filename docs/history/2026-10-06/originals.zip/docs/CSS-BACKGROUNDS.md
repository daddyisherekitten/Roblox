# CSS-Hintergrundbilder

Die Engine unterstützt Hintergrundebenen auf Blockboxen mit demselben CSS, das
auch ein Browser liest:

- `background-image` mit `url(...)`, `linear-gradient()`,
  `repeating-linear-gradient()`, `radial-gradient()` und
  `repeating-radial-gradient()`;
- mehrere Ebenen, wobei die erste CSS-Ebene oben liegt;
- `background-size` mit `auto`, ein oder zwei Längen/Prozenten, `cover` und
  `contain`;
- `background-position` mit Schlüsselwörtern, Längen, Prozenten und
  Kantenoffsets wie `right 12px bottom 10px`;
- `background-repeat` mit getrennten Achsen, `repeat-x`, `repeat-y`, `space`
  und `round`;
- `background-origin` und `background-clip` für Border-, Padding- und
  Contentbox;
- die Kurzform `background`, die Farbe und alle Ebenen-Longhands zurücksetzt.

`url(...)` lädt keine beliebigen Internetdateien. Wie bei `img` ordnet
`options.Images` den exakten Quellpfad einer freigegebenen Roblox-Asset-ID zu.
Die Groß-/Kleinschreibung des URL-Inhalts bleibt dabei erhalten. In einer
normalen Browserdatei zeigt derselbe Pfad direkt auf die Bilddatei.

## Darstellung und Cache

`Rendering/BackgroundImages` hängt passive, nicht anklickbare Bildschichten an
die vorhandene Box. URL-Ebenen verwenden native `ImageLabel`s. Verläufe werden
von `Rendering/BackgroundPixels` in ein `EditableImage` gerastert. Ein Verlauf
wird nur für eine neue Kombination aus Verlauf, Rastergröße und `currentcolor`
berechnet. Reflow und wiederholte Zustandswechsel verwenden danach denselben
Cacheeintrag.

Eine Verlaufstextur hat höchstens 256 Pixel pro Kante und 65536 Pixel. Pro
Seite gelten höchstens acht Ebenen je Box, 64 Verlaufstexturen und insgesamt
4194304 Cachepixel. Die Seite meldet eine Diagnose und lässt nur die betroffene
Ebene weg, falls die API oder das Budget fehlt. Beim Zerstören der PageSession
werden alle `EditableImage`s freigegeben.

Die Verläufe interpolieren Alpha vormultipliziert, verteilen ausgelassene
Stopppositionen, begrenzen rückwärts laufende Stopps und unterstützen doppelte
Positionen. Lineare Winkel und Richtungen folgen der CSS-Ausrichtung. Radiale
Kreise/Ellipsen unterstützen Seiten-/Eckgrößen, explizite Radien und eine
eigene Mittelpunktposition.

## Bewusste Grenzen

- Keine `conic-gradient()`, `image-set()`, `cross-fade()` oder heruntergeladenen
  Remote-Bilder.
- Hintergrundbilder auf zerlegten Inline-Textfragmenten werden nicht gemalt;
  einfarbige Inline-Hintergründe bleiben wie bisher verfügbar.
- `space` verwendet die normale Wiederholungsphase als Näherung. `round`
  wählt eine ganzzahlige Kachelzahl und passt die Kachelgröße an.
- URL-`auto` füllt ohne separate intrinsische Hintergrundmetadaten die
  Positionierungsfläche. `cover` und `contain` verwenden Robloxs native
  Bildanpassung.
- Ungleiche innere Rundungen werden auf einen gemeinsamen Kreisradius
  angenähert.

Die neue Browser-/Roblox-Untertestseite
`examples/websites/css-background-position` prüft getrennte Positionsachsen.
`tests/Backgrounds.luau` deckt zusätzlich Parser, Kaskade, URL-Schreibweise,
Rasterfarben/-alpha, Größen-Cache und Freigabe ab.
