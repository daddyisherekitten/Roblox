# CSS-Transformationen in 2D und 3D

Blockboxen, atomare Inlineboxen und ersetzte Blockelemente verwenden eine gemeinsame
4x4-Matrix. CSS-Funktionen werden in ihrer angegebenen Reihenfolge multipliziert;
`transform-origin` wird davor und danach angewendet. Der normale Layoutfluss bleibt
unverändert. Die Implementierung folgt dem [CSS-Transforms-Modell](https://www.w3.org/TR/css-transforms-2/).

Unterstützte Funktionen:

- `translate`, `translateX/Y/Z`, `translate3d` einschließlich X/Y-Prozenten;
- `rotate`, `rotateX/Y/Z`, `rotate3d` mit normalisierter Drehachse;
- `scale`, `scaleX/Y/Z`, `scale3d`, ungleiche und negative Faktoren;
- `matrix`, `matrix3d`, `skew`, `skewX/Y`, `perspective`;
- einzelne Eigenschaften `translate`, `rotate`, `scale` auch mit drei Komponenten;
- `transform-origin` mit dritter Z-Länge und `perspective-origin`;
- `transform-style: preserve-3d/flat` und `backface-visibility`.

Gleichmäßige 2D-Transformationen bleiben native Roblox-GUIs mit wiederverwendetem
`UIScale`. Andere Transformationen verwenden eine retained EditableImage-Fläche.
Eine `preserve-3d`-Gruppe übernimmt die Matrizen aller Eltern und Kinder; Flächen
werden pro Pixel nach Tiefe sortiert und mit ihrer Transparenz zusammengesetzt.
Perspektivisch korrigierte Texturkoordinaten vermeiden Verzerrungen an der
Triangulationsdiagonale. Flächen hinter der Kamera werden entfernt; kreuzende
Flächen werden vor der homogenen Division an der Kameraebene geschnitten.

`flat`, Opacity und gruppierende Overflow-/Containment-Eigenschaften komponieren
Nachfahren zuerst zu einer Ebene. Der Perspektivwert einer Box wirkt auf ihre
Kinder, während die Funktion `perspective()` innerhalb ihrer eigenen Liste wirkt.
Rückseiten werden an der akkumulierten Matrix geprüft, nicht an einzelnen Winkeln.

Animationen und Übergänge interpolieren passende Funktionen komponentenweise.
Dadurch bleiben auch ganze Umdrehungen erhalten. Unterschiedliche Listen verwenden
Matrixzerlegung mit Quaternion-Interpolation; singuläre Matrizen wechseln diskret.
Pausierte Animationen belegen keinen Frame-Listener. Unveränderte Szenen behalten
ihre Bildfläche, und Text-/Hintergrundtexturen werden getrennt zwischengespeichert.

## Rasterprofil und Grenzen

Der Projektionsrenderer zeichnet Text, solide rechteckige Rahmen, Hintergrundfarben,
Gradienten und verfügbare Canvas-Pixel. Das deckt alle sechs beschrifteten Flächen des
Würfels auf `html-css-stress-effects` ab. Beliebige native Controls, VideoFrames,
externe Assettexturen, SVG-GUIs und sämtliche CSS-Effekte sind noch keine vollständigen
Browser-Compositing-Flächen. Projektive Trefferflächen für interaktive Nachfahren
sind ebenfalls nicht implementiert; native 2D-Links und Controls bleiben bedienbar.

Maximal 64 Flächen und 64 Verschachtelungsebenen pro Szene; Ausgabe höchstens
512 Pixel pro Kante. EditableImage-Verfügbarkeit und das gemeinsame Seitenbudget
begrenzen die Darstellung zusätzlich. Die native Textebene des Browsers kann sich
von den Rasterglyphen unterscheiden. `StarterGui.ClipsDescendantsSupportsRotation`
muss für native gedrehte GUIs weiterhin aktiviert sein.

`tests/ThreeDTransforms.luau` prüft die Browser-Matrix und gemessene Würfelgrenzen,
Funktionsreihenfolge, Perspektive, Rückseiten, Kameraclipping, kreuzende Flächen,
Gruppen-Opacity, Keyframes, unterbrochene Hover-Übergänge, Caches und Freigabe.
`HTML_3D_PREVIEW=1 node scripts/run-html-tests.cjs ThreeDTransforms` erzeugt außerdem
`build/three-d-preview.png` mit den tatsächlich gerasterten Würfelpixeln.
