# Aufklappbare Bereiche

```html
<details>
  <summary>Weitere Informationen</summary>
  <p>Dieser Inhalt erscheint beim Aufklappen.</p>
</details>
```

`details` ist zunächst geschlossen; mit `open` ist der Inhalt beim Start sichtbar.
Das Attribut ist boolesch: Auch `open="false"` bedeutet geöffnet. Das erste direkte
`summary` ist der aktive Titel und steht visuell vor dem restlichen Inhalt. Weitere
`summary`-Elemente und alleinstehende Summarys sind normale Blöcke. Ohne Titel
erscheint „Details“. Formatierte Titel verwenden das vorhandene Textlayout.

Mausklick, Touch-Tippen und Enter/Leertaste am fokussierten Titel wechseln den
Zustand. Ein abgebrochenes `click`-Event verhindert das Umschalten. Tab/Shift+Tab
berücksichtigen den Titel und überspringen zugeklappte Nachfahren. Die Anzeige
verwendet passive Frames/TextLabels mit zentralem Controller, keine GuiButtons.
Der Dreieckspfeil folgt Schriftgröße und Farbe; der Fokusrahmen verändert keine Maße.
Der Titel zeigt den Fokusrahmen bei Tastaturbedienung, nicht beim Anklicken oder
Antippen zum Auf-/Zuklappen.
Die Pfeilkontur folgt der Nutzerreferenz: bei 18px CSS-Schrift 10×12px sichtbare
Fläche und 19px Vorschub bis zum Titel. Passive horizontale Runs übernehmen die
gemessenen Randtransparenzen; die Unterkante liegt auf der Textgrundlinie.

Rendering/Disclosure verwaltet den Zustand, den anonymen Inhaltscontainer und den
Marker. Geschlossene Inhalte bleiben im Renderbaum als `AllChildren` erhalten,
sind jedoch unsichtbar und nicht Teil der aktuellen `Children` für das Layout.
DirtyLayout registriert auch diese Bereiche und akzeptiert die Details-Box als
gezieltes Änderungsziel. Beim Öffnen/Schließen werden betroffene Layoutbereiche
berechnet; davor liegende unabhängige Teilbäume können wiederverwendet werden.
Vorhandene GUIs, Editorwerte und Zustände verschachtelter Details bleiben erhalten.

Die Original-DOM-Struktur bleibt erhalten; nur das `open`-Attribut wird beim
Umschalten geändert. Anonyme Container und der optionale Ersatztitel gehören nur
zum Renderbaum. Formularwerte aus geschlossenen Details werden weiterhin übertragen;
ein Formular-Reset setzt die Werte zurück und ändert den Aufklappzustand nicht.

Teilumfang: keine exklusiven `name`-Gruppen, keine Animation, kein automatisches
Öffnen für Fokus/Validierung, keine `toggle`-/`beforetoggle`-Events und keine
HTMLDetailsElement-JavaScript-API. Autoren-CSS wird beim Umschalten nicht neu
ausgewertet (`[open]`-Selektoren gelten somit für den Startzustand). Standardmarker
und Fokusdarstellung sind angenähert; `::marker`-CSS und abweichende Summary-
Display-/Listmarker-Arten sind nicht vollständig umgesetzt.

Beispiel 30 in den synchronen Browser-/Studio-Demos. `tests/Details.luau` prüft
Startzustände, Fallback, DOM-Erhaltung, Maus/Touch/Tastatur, Klickabbruch, Tab,
Formulardaten/Reset, Verschachtelung, Editor-Erhaltung und Teil-/Voll-Layout.
GUI-/Messungs-Mocks ersetzen den visuellen Studio-Vergleich nicht.

Referenz: [HTML details und summary](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-details-element).
