# Formulare und Eingabe – erster Teilumfang

Beispiel 29 enthält dieselben HTML-Elemente im Browser und in Roblox. Der Browser
verwendet weiterhin seine nativen Steuerelemente. Roblox zeichnet deren Rahmen,
Farben und Rundungen näherungsweise; ein visueller Studio-Abgleich steht noch aus.

## Unterstützt

- `form`, `label` mit `for` oder verschachteltem Feld, `output`.
- `fieldset` und `legend`, einschließlich `fieldset disabled`.
- `input` mit `text`, `email`, `url`, `password`, `number`, `checkbox`, `radio`, `range`, `button`, `submit`, `reset`.
- `textarea` und `button` mit reinem Textinhalt.
- `select` als Einfachauswahl und `option` mit `value`, `label`, `selected`, `disabled`.
- `datalist` über `input[list]` für editierbare Text-, E-Mail-, URL- und
  Zahlenfelder, einschließlich Filterung und Auswahl mit Maus oder Tastatur.
- `progress` und `meter` als passive Anzeigen; Werte per `page:SetValue`.
- `id`, `name`, `value`, `checked`, `disabled`, `readonly`, `placeholder`,
  `maxlength`, `minlength`, `required`, `size`, `rows`, `cols`, `tabindex`, `autofocus`, `form`,
  `novalidate` und `formnovalidate` im beschriebenen Teilumfang.
- Maus und Touch, Label-Klick, Fokus, Tab/Shift+Tab innerhalb der Seite,
  Radio-Auswahl mit Pfeiltasten, Button-Aktivierung mit Leertaste/Enter.
- Lokales Submit/Reset, Pflichtfeldprüfung auf leere Texte und nicht ausgewählte
  Checkbox-/Radiogruppen. `invalid`, Fokus und englische Validierungs-Sprechblase.
- CSS-Kindselektor `>` zusätzlich zu den bisherigen Nachfahren-Selektoren.

Text, Passwort und Textarea verwenden eine native Roblox `TextBox` für die
Texteingabe. Radios bestehen aus Außenkreis, weißem Innenring und blauem Punkt;
Checkboxen aus einer Box und zwei gedrehten Strichen. Fokussierte Textfelder
bekommen einen 2px-Rahmen, ohne ihre Layoutgröße zu ändern.

Einzeilige Text-/Passwortfelder und Select trennen die logische Zeilenhöhe von der lokalen
Schriftkorrektur: ungekürzte FontMetrics.TextSize + 1px. Standard-Arial ergibt 17px
Textbereich plus je 1px Padding = 19px innen (21px mit Rahmen). Die angezeigte
TextSize bleibt 14; ihre Grundlinie liegt 5px über der inneren unteren Rahmenkante.
Explizite CSS-Höhen bleiben maßgebend; zusätzlicher vertikaler Platz zentriert die
logische Textzeile. Passwortmaske und Editor erhalten dieselbe Position. Textarea,
Buttons und globale Fontprofile behalten ihre bisherigen Größen.

Buttons (`button` sowie `input` mit button/submit/reset) zentrieren ihre
Beschriftungszeile jetzt innerhalb der verfügbaren Inhaltsfläche. Eine feste
Höhe oder `min-height` verteilt den zusätzlichen Platz um die Zeile; die
Grundlinie hängt nicht von den sichtbaren Buchstaben des aktuellen Texts ab.
Die Standardausrichtung ist `align-content:center`, wie im
[HTML-Renderingprofil](https://html.spec.whatwg.org/multipage/rendering.html#form-controls).
Autoren können start/end oder bei Flexbuttons die entsprechende Flexausrichtung
setzen. Asymmetrisches Padding verschiebt die Inhaltsfläche entsprechend.
Bestehende Eingabefeld-Grundlinien und Fontkalibrierungen bleiben erhalten.

Absolut positionierte Steuerelemente und Bilder rechnen Prozenthöhen gegen
die bereits bestimmte Höhe ihrer Bezugsbox. Das gilt auch, wenn diese Höhe
über `aspect-ratio` entsteht. Rahmen, GUI-Identität und Hitbox bleiben bei
Größenänderungen erhalten. Die Positionierungsregression prüft volle und
halbe Höhen in einem quadratischen Container.

## Formulargruppen

`fieldset` zeichnet standardmäßig einen 2px-Groove-Rahmen, mit 2px Außenabstand
links/rechts und Padding `.35em .75em .625em`. Die erste sichtbare, nicht absolut
positionierte direkte `legend` sitzt auf der oberen Rahmenkante und erhält 2px
Padding links/rechts. Ihre Breite richtet sich nach dem Inhalt; längere Beschriftungen
brechen um. Der Rahmen wird in der Lücke tatsächlich ausgespart, ohne Hintergrundfarbe
über den Text zu legen. Weitere Legenden stehen im normalen Inhaltsfluss.

Auch bei `display:flex` bleibt die erste Legende außerhalb der Flexelemente.
`min-width:0` erlaubt einer Gruppe, unter ihre standardmäßige minimale Inhaltsbreite
zu schrumpfen. Unveränderte Teilbäume bleiben über DirtyLayout wiederverwendbar.

`fieldset disabled` deaktiviert die enthaltenen Formularfelder für Bedienung, Fokus,
Tab, Validierung und Formulardaten. Ausgenommen sind Nachfahren seiner ersten direkten
DOM-Legende, unabhängig von deren Sichtbarkeit. Jede verschachtelte deaktivierte Gruppe
wird separat geprüft; ein eigenes `disabled` am Feld bleibt wirksam.

Teilumfang: horizontales LTR-Layout; keine dynamischen Attributänderungen oder native
`fieldset.elements`-API. Spezielle Kombinationen mit Overflow, Schatten und vertikalen
Schreibrichtungen sind noch nicht vollständig browsergleich. Referenz:
[HTML-Standard](https://html.spec.whatwg.org/multipage/rendering.html#the-fieldset-and-legend-elements).

## Luau-API

Die Methoden werden beim Mounten einer Seite mit Formularfeldern eingerichtet:

```lua
page:On("form-preview", "submit", function(event)
    event:PreventDefault()
    page:SetValue("preview-result", "Button geklickt.")
    -- event.Data.Entries: {{Name = "...", Value = "..."}, ...}
    -- event.Data.Submitter: DOM-Knoten des auslösenden Buttons, falls vorhanden.
end)

local listener = page:On("input", function(event)
    -- event.Target: DOM-Knoten; event.Data.Value oder event.Data.Checked.
end)
listener:Disconnect()

page:SetValue("preview-name", "Tobias")
local name = page:GetValue("preview-name")
page:SetChecked("checkbox-id", true)
local checked = page:GetChecked("checkbox-id")
page:Focus("preview-name")
local entries = page:GetFormData("form-preview")
page:Reset("form-preview")
```

`On(id, eventName, callback)` kann auch einen DOM-Knoten als erstes Argument
erhalten. `On(eventName, callback)` hört auf Seitenebene. Ereignisse laufen
vom Ziel über seine Eltern bis zur Seite. `StopPropagation()` beendet diesen
Weg; `PreventDefault()` unterbindet die Standardaktion bei `click` und `reset`.
Submit besitzt noch keine externe Standardaktion. Weitere Ereignisse:
`change`, `focus`, `blur`, `pointerdown`, `pointerup`, `pointerenter`, `pointerleave`,
`invalid`. Das ist eine einfache Luau-Ereignis-API, kein vollständiges DOM-Eventmodell.

Formulardaten behalten DOM-Reihenfolge und doppelte Namen als einzelne Einträge.
Unbenannte/deaktivierte Felder, nicht gewählte Checkboxen/Radios und `output`
werden ausgelassen. Beim Submit zählt nur der auslösende Submit-Button mit;
`GetFormData` fügt keinen Button hinzu. Gleichnamige Radios teilen eine Gruppe
je Formular. Bei mehreren `checked`-Vorgaben gewinnt das letzte Feld auch nach Reset.
Programmgesteuerte Änderungen lösen keine `input`-/`change`-Ereignisse aus.

## Struktur und Aufwand

### Autofocus

`autofocus` setzt einmal nach dem ersten fertigen Seitenlayout den Fokus auf das
erste geeignete Formularfeld in DOM-Reihenfolge. Deaktivierte Felder (auch durch
fieldset), ausgeblendete Felder, Output und passive Anzeigen werden übersprungen.
`readonly` und `tabindex="-1"` verhindern programmgesteuerten Fokus nicht.
Das Attribut ist boolesch: seine Anwesenheit zählt, auch bei `autofocus="false"`.

Vorhandener Fokus, bereits erfolgte Benutzerinteraktion oder Fenster-Fokusverlust
während des Ladens verhindern eine spätere Übernahme. Auch eine fokussierte TextBox
außerhalb der Seite bleibt erhalten. Resize, Teil-Layout und Reset wiederholen den
Autofokus nicht. Der Status-Listener wird nach dem ersten Versuch getrennt und beim
Dispose aufgeräumt; ohne Attribut wird kein zusätzlicher Listener angelegt.

Teilumfang: vorhandene fokussierbare Formularcontrols; keine generischen
contenteditable-Elemente, Dialog-/Popover-Fokusbereiche oder zusätzliche Scrolllogik.
Gemeinsamer Test: E-Mail-Feld. Regressionen: Tests/Autofocus.
Referenz: [HTML autofocus](https://html.spec.whatwg.org/multipage/interaction.html#the-autofocus-attribute).

### Datalist-Vorschläge

Ein `input[list]` findet die `datalist` mit der passenden ID beim Aufbau der
Seite. Aktivierte `option`-Werte werden ohne Beeinflussung der freien Eingabe
angeboten. Fokus oder ein erneuter Klick öffnet die Liste. Eingabe filtert ohne
Neulayout ohne Beachtung der Groß-/Kleinschreibung über Wert und Beschriftung.
Pfeil hoch/runter verändert die Hervorhebung, Enter übernimmt den Wert und Escape
schließt die Liste. Maus und Touch verwenden denselben passiven Popup-Hit-Test wie
Select; Auswahl erzeugt `input`, während `change` wie bei einem Textfeld beim
Abschluss der Bearbeitung folgt.

Der aktuelle Teilumfang gilt für die bereits editierbaren Text-, E-Mail-, URL-
und Zahlenfelder. Browserabhängige Picker für Datum und Farbe, Tickmarken an
Range-Feldern, dynamische Änderungen am Listen-DOM sowie die vollständigen
Ereignis- und Accessibility-Details fehlen noch. Die Abdeckung liegt in
`tests/Forms.luau`; die frühere sichtbare Datalist-Seite wurde entfernt.

### E-Mail, URL und Mindestlänge

`input type="email"` und `input type="url"` verwenden dieselbe native TextBox,
Schriftkorrektur, Innenhöhe und Grundlinie wie Textfelder. Ihre Werte entfernen
Zeilenumbrüche und äußeren ASCII-Leerraum. E-Mail unterstützt auch `multiple`
als kommaseparierte Liste; leere Einträge innerhalb einer Liste sind ungültig.

Beim Absenden prüft der Controller die E-Mail-Syntax beziehungsweise eine absolute
URL (mit Schema, z.B. `https://example.com`). Geprüft werden auch Host, Portgrenze,
IPv4-/IPv6-Schreibweise; andere absolute Formen wie `mailto:` sind zulässig.
Die Prüfung betrifft Syntax, nicht Erreichbarkeit. URLValue ist ein lokaler Teilumfang
des URL-Standards: keine vollständige IDNA-/Punycode-Umwandlung, URL-Normalisierung
oder sämtliche Sonderregeln für file-URLs. E-Mail-Domains unterstützen ASCII und
bereits vorliegendes Punycode; Unicode-Domains werden nicht automatisch umgewandelt.

`minlength` gilt für Text, Passwort, E-Mail, URL und Textarea. Gezählt werden UTF-16-
Codeeinheiten; Textarea-Zeilenenden werden zuvor auf LF vereinheitlicht. Wie in HTML
greift die Mindestlänge nur bei nichtleerem, zuletzt vom Benutzer verändertem Text.
Initialwerte, Reset und `page:SetValue` lösen allein keinen too-short-Fehler aus.
Ein leeres Feld wird erst mit `required` ungültig. Ungültige/negative Mindestlängen
werden ignoriert; `minlength` an anderen unterstützten Kontrolltypen hat keine Wirkung.

Das erste ungültige Feld löst `invalid` aus und verhindert Submit. Ohne
`event:PreventDefault()` erhält es Fokus und eine englische Validierungs-Sprechblase.
`disabled`, `readonly`, `novalidate` und `formnovalidate` bleiben berücksichtigt.
Die Validierung benötigt kein neues Layout. Referenzen:
[HTML-Eingabetypen](https://html.spec.whatwg.org/multipage/input.html),
[Mindestlänge](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#attr-fe-minlength).
Tests: TextValidation; bestehende Formularbeispiele durch E-Mail, URL und
Textarea mit Mindestlänge ersetzt, keine zusätzlichen Felder.

### Englische Validierungsmeldungen

`Controls/ValidationMessage` erzeugt passende Texte für fehlende Werte, E-Mail,
URL, Mindestlänge und Zahlenbedingungen. `event.Data` enthält `Reason` und `Message`.
`invalid:PreventDefault()` unterdrückt Fokus und Standard-Sprechblase; Submit bleibt
blockiert. Eingabewerte werden nur bei E-Mail-Hinweisen zitiert, auf 60 UTF-16-Einheiten
begrenzt und ohne RichText dargestellt. Passwortwerte werden nicht ausgegeben.

`Input/ValidationPopup` zeichnet passive Frames/TextLabels: weißen Hintergrund,
grauen 1px-Rahmen, kleine Rundung, Dreieckspfeil, orangefarbenes Ausrufezeichen
und optionalen UIShadow. Arial 14, umbrochener Text; maximale Breite 300px.
Die Blase sitzt unter dem Feld beziehungsweise bei Platzmangel darüber und wird
horizontal ins Seitenfenster begrenzt. Keine interaktiven Buttons, keine Frame-Schleife
oder Layout-Anforderung. Textmaße über synchrones TextService:GetTextSize.

Bearbeitung, Fokuswechsel, Klick/Touch, Escape, Reset, Scrollen, Verschieben/Resize
des Ankers sowie Fenster-Fokusverlust entfernen die Blase. Dispose trennt ihre
Listener und entfernt den Teilbaum. Das vorhandene Formular reicht zum Vergleich:
ungültige E-Mail eingeben und Testen drücken. Browsermeldungen bleiben nativ und
folgen der Browsersprache; die Roblox-Meldungen sind Englisch.

Referenz für die fehlende-@-Meldung:
[Chromium-Validierungstests](https://chromium.googlesource.com/chromium/blink/+/HEAD/LayoutTests/fast/forms/validationMessage-expected.txt).
Optik ist angenähert und muss in Studio mit der Nutzerreferenz verglichen werden.

### Textarea-Ziehgriff

Das vorhandene Textarea-Beispiel besitzt einen 12×12px-Ziehgriff direkt innerhalb
der unteren/rechten Rahmenkante. EditableImage zeichnet die Nutzerreferenz mit
7 und 3 diagonalen Pixeln in RGB 102 auf transparentem Hintergrund. Eine Textur
pro Seite, beim ersten Feld angelegt und beim Dispose freigegeben. Bei fehlender
EditableImage-Freigabe ersetzen zehn passive Pixelframes dieselbe Darstellung.

Maus/Touch ziehen das Feld in beide Richtungen; der Mauszeiger wird nicht geändert.
`resize: none | both | horizontal | vertical` steuert den Griff (Textarea-Standard:
both; andere Elemente unterstützen das Ziehen noch nicht). Der Griff erhält
weder TextButton/ImageButton noch eigene GUI-Input-Listener. Ein reiner Klick
ohne Größenänderung fordert kein Layout an. Beim Greifen wird der Eingabefokus
aufgehoben: kein Schreiben und kein 2px-Fokusrahmen während der Geste. Nach dem
Loslassen bleibt das Feld unfokussiert, bis es wieder aktiviert wird. Textwert und
Schriftgröße bleiben erhalten. Die Größenänderung erzeugt keine input/change-
Ereignisse; das normale Blur kann zuvor bearbeiteten Text mit change abschließen.
Reset setzt den Text zurück und behält die gezogene Größe.

Änderungen schreiben Pixelmaße nach CSS-box-sizing in den ursprünglichen
Control-Stil, auch für Block-/Flex-Controls mit temporärem Layout-Stil. Vorhandene
min/max-Beschränkungen gelten weiter. Mindestinhalt beim Ziehen: 12px pro Achse.
Das Teil-Layout erhält das betroffene Item; der Scheduler bündelt lokale
Control-Änderungen weiterhin in 1/60s. Ein gleichzeitig laufender Fenster-Resize
wartet bei `HTMLViewportResizing=true` am Mount-Ziel bis zum echten Loslassen
und übernimmt dann sofort alle ausstehenden Änderungen. Größenwechsel ohne
aktive Geste starten sofort. Keine zusätzliche Frame-Schleife. Release außerhalb und
Fenster-Fokusverlust beenden die Geste, Dispose räumt auf.

Module: Rendering/ResizeGrip, Controls/TextareaView, Input/TextareaResize.
Tests: TextareaResize, PageLifecycle und vorhandenes gemeinsames Textarea-Beispiel.

### Fortschritt und Messwert

`progress` verwendet `value` und `max` (Standard 1, muss positiv sein). Werte
werden auf 0–max begrenzt. Ohne `value` ist der Fortschritt unbestimmt und ein
30%-Segment läuft vor/zurück. Ein vorhandenes, aber ungültiges `value` bedeutet 0.

`meter` verwendet `min` (Standard 0), `max` (Standard 1), `value` (Standard 0),
`low`, `high` und `optimum`. Werte und Grenzwerte werden in den gültigen Bereich
begrenzt. Ohne Angaben liegen low/high an den Grenzen, optimum in der Mitte.
Die Füllfarbe folgt dem Verhältnis zum Optimum: grün im optimalen Bereich, gelb
im benachbarten Bereich und rot im gegenüberliegenden Bereich. Liegt optimum
zwischen low/high, sind beide äußeren Bereiche gelb. Gleiche min/max ergeben
einen leeren Balken; max kleiner als min wird auf min angehoben.

```lua
page:SetValue("preview-progress", 75)
page:SetValue("preview-progress", nil) -- unbestimmter Fortschritt
page:SetValue("preview-meter", 90)
```

`GetValue` liefert wie bei anderen Controls einen Zahlenstring; unbestimmter
Fortschritt liefert "0". Änderungen ersetzen keine GUIs und fordern kein Layout
an. Beide Elemente sind keine Formularfelder: kein Submit-Wert, kein Reset,
keine Validierung, kein Fokus/Tab und keine Eingabeereignisse. Der HTML-Inhalt
bleibt im DOM als Fallbacktext erhalten, wird aber nicht zusätzlich gezeichnet.

Darstellung aus Frames/UICorner/UIStroke: 8px Spur mittig in einer 1em hohen Box;
natürliche Breite 10em bei progress, 5em bei meter. CSS-Größen, Padding, Rahmen
und vertical-align laufen durch das vorhandene Box-/Inline-Layout. Schriftprofile
bleiben unverändert. Farben sind zunächst angenähert, native Studio-Optik noch
abzugleichen; keine vertikale Darstellung oder bar-spezifischen CSS-Pseudoelemente.

`Controls/GaugeValue` normalisiert Werte/Bereiche. `GaugeView` zeichnet und verwaltet
die optionale TweenService-Animation. Ein laufender Tween bleibt bei Resize und
gecachten Paint-Snapshots erhalten; value setzen, visibility:hidden oder Dispose
beendet ihn. Keine zusätzliche Luau-Frame-Schleife. Grenzen werden beim Mounten
gelesen; zur Laufzeit ist zunächst nur value über die Seiten-API veränderbar.
Tests: `tests/Gauges.luau`, gemeinsame Demo: je ein Element in Beispiel 29.
Grundlage: [HTML progress und meter](https://html.spec.whatwg.org/multipage/form-elements.html#the-progress-element).

### Zahlenfeld

`input type="number"` verwendet eine TextBox und zwei selbst gezeichnete Pfeile
aus Frames. Pfeile erscheinen bei Hover/Fokus, bei `disabled`/`readonly` bleiben
sie verborgen. Klick/Touch oben erhöht, unten verringert; Pfeil hoch/runter auf
der Tastatur funktioniert auch bei aktivem Editor. Pro Pfeilklick ein Schritt;
noch keine Haltewiederholung oder Mausrad-Steuerung.

`min`/`max` sind optional, `step` ist standardmäßig 1. Schrittbasis: `min`, sonst
ursprüngliches `value`, sonst 0. Bei `step="any"` wird keine Schrittgenauigkeit
validiert; die UI-Pfeile verwenden vorerst Einerschritte. Zahlen ohne vorgegebenen
Wert bleiben leer. Gültige Eingaben außerhalb der Grenzen werden nicht automatisch
geändert, sondern bei Submit als ungültig erkannt. `required`, ungültige Eingabe,
Unter-/Überlauf und Schrittfehler führen zu `invalid` und Fokus. `novalidate` und
`formnovalidate` umgehen diese Prüfung wie bei den übrigen Feldern.

Während des Tippens bleibt Rohtext (`EditText`) erhalten, etwa `-` oder `1e`.
`GetValue` und Formulardaten liefern für ungültige Eingaben eine leere Zeichenkette;
`BadInput` unterscheidet diese vom leeren gültigen Feld. Dezimalpunkt und Exponenten
werden unterstützt; lokalisierte Komma-Eingabe und native Zeichenfilter noch nicht.
`SetValue` übernimmt gültige Zahlenstrings, ungültige werden geleert. `maxlength`
und `size` beeinflussen Zahlenfelder nicht. Reset stellt den Startwert wieder her.

Tippen erzeugt `input`, Verlassen nach Wertänderung `change`. Pfeilschritte erzeugen
je ein `input` und `change`; beim späteren Fokuswechsel gibt es kein zweites Change.
Keine Layoutanforderung bei Wertänderungen. Höhe/Schriftkorrektur entsprechen den
Textfeldern (standardmäßig 21px außen, TextSize 14). Der Editor lässt 18px für die
Pfeile frei. Nach Nutzerreferenz: 7×4px-Dreiecke in RGB 139, 4px Abstand dazwischen;
15×14px Hintergrund RGB 252 mit 3px Abstand zum inneren rechten Rand.
Gemeinsamer Test: ein Zahlenfeld 1–10 in Beispiel 29.

Module: `NumericValue` (gemeinsamer Parser mit Range), `NumberValue` (Werte/Schritte/
Prüfung), `NumberView` (Pfeile und Trefferflächen). Tests: `tests/Number.luau`.
Semantische Grundlage: [HTML Number State](https://html.spec.whatwg.org/multipage/input.html#number-state-(type=number)).

### Schieberegler

`input type="range"` verwendet `min`, `max`, `step` (auch `any`) und `value`.
Ohne Grenzen gilt 0–100, ohne Schrittweite 1, ohne gültigen Wert die Mitte.
Werte werden begrenzt und auf erlaubte Schritte gerundet; bei gleichem Abstand
gewinnt der größere Wert. Schrittbasis ist `min`, sonst das ursprüngliche
`value`-Attribut, sonst 0. Bei `max < min` bleibt der Wert auf `min`.
Grundlage: [HTML-Standard](https://html.spec.whatwg.org/multipage/input.html#range-state-(type=range)).

`Controls/RangeValue` normalisiert Startwerte und `page:SetValue`.
`Controls/RangeView` zeichnet graue Spur, blauen Füllstand und runden Griff aus
passiven Frames. Standardgröße: 129×16px plus 2px Margin, Griff 16px, Spur 8px
einschließlich 1px Innenrahmen (RGB 178); innen RGB 239 wie im Browser-Referenzbild.
Hover über dem Regler färbt den blauen Füllstand; der Griff ändert seine Farbe
erst beim direkten Überfahren seiner Kreisfläche. Über dem Griff reagieren beide.
Der graue Schienenhintergrund verwendet RGB 239 normal, 229 bei Hover und 245
beim Drücken oder bei deaktiviertem Regler; Disabled hat Vorrang vor Hover.
CSS-Breite/Höhe verändern die Geometrie; Wertänderungen benötigen keine Textmessung
und kein neues Layout. `Input/RangeDrag` erfasst die Geste bis zum Loslassen,
auch außerhalb des Reglers. Ein Griff-Klick erhält den Abstand zum Mittelpunkt.
Maus und Touch lösen `input` bei Wertänderungen aus, beim Loslassen einmal `change`
bei verändertem Endwert. Fenster-Fokusverlust beendet die Geste ebenfalls.
Pfeiltasten ändern um einen Schritt, Home/End springen an die Grenzen.
Bei `step="any"` verwenden Pfeile 1% des Bereichs.

`disabled`, Fokus/Tab, Formulardaten und Reset sind angebunden; `readonly`,
`required` und `maxlength` gelten für Range nicht. Programmatische Wertänderungen
und Reset erzeugen keine `input`-/`change`-Ereignisse. Beispiel 29 enthält einen
Regler 0–100. Tests: `tests/Range.luau` mit Eingabe-/GUI-Mocks.
Vorerst horizontal von links nach rechts; keine Tickmarks/`datalist`, vertikale
Ausrichtung oder CSS-Pseudoelemente für Spur/Griff. Native Touch-Scrollkonflikte
und die genaue Browser-/Studio-Optik müssen noch visuell geprüft werden.

### Dropdown

`Controls/SelectOptions` liest Optionstexte/-werte und die Startauswahl. Die letzte
`selected`-Vorgabe gewinnt; ohne Vorgabe wird die erste aktivierte Option gewählt.
`page:SetValue` wählt den ersten passenden Wert, auch bei doppelten Werten. Ein
unbekannter Wert hebt die Auswahl auf. `GetValue` liefert dann eine leere Zeichenkette;
das Feld wird wie eine ausgewählte deaktivierte Option beim Submit ausgelassen.
Reset stellt die ursprüngliche Auswahl wieder her. `required` berücksichtigt eine
fehlende Auswahl und eine leere erste Platzhalteroption. `disabled` am Select und
an Optionen wird beim Auswählen beachtet; ein `optgroup disabled` deaktiviert seine
Optionen ebenfalls. Gruppenüberschriften werden separat und nicht auswählbar gezeichnet.

`Input/SelectPopup` zeichnet die Liste aus Frames/TextLabels und einem nativen
ScrollingFrame. Sie liegt außerhalb des Seiten-Scrollinhalts und öffnet je nach
Platz darunter oder darüber. Maus/Touch laufen durch den zentralen Controller;
Ziehen wählt keine Option aus. Pfeile ändern die Auswahl oder die vorläufige
Markierung einer offenen Liste; Enter/Leertaste bestätigt, Escape verwirft sie.
Klick außerhalb, Fokuswechsel, Reset, Resize und Bewegung des Ankers schließen sie.
Der Popup-Teilbaum und seine Listener werden anschließend entfernt.

`Input/SelectTypeAhead` sucht bei fokussiertem Select anhand des angezeigten
Optionstexts (einschließlich `label`). Schnell getippte Zeichen bilden ein Präfix;
nach einer Sekunde Pause beginnt eine neue Suche. Wiederholte gleiche Buchstaben
wechseln zyklisch zwischen passenden Optionen, deaktivierte Optionen werden
übersprungen. Groß-/Kleinschreibung folgt dem vorhandenen Latin-Mapping inklusive
Umlauten. Leerzeichen können ein aktives Suchpräfix erweitern.

Bei geschlossener Liste wird direkt ausgewählt; bei geöffneter Liste nur markiert
und gegebenenfalls zur Zeile gescrollt. Enter bestätigt, Escape verwirft die Markierung.
Kein Treffer ändert den Wert nicht. Auswahl desselben Eintrags erzeugt keine doppelten
Events. Fokuswechsel, Öffnen/Schließen, Pfeilnavigation, programmatisches SetValue und
Reset leeren die Suche. Keine Timer oder neuen GUI-Objekte für die Suche.

Der Controller verwendet GetStringForKeyCode für druckbare Haupttastatur-Tasten.
Ctrl/Alt/Meta-Kombinationen und bereits verarbeitete Eingaben werden ignoriert.
Teilumfang: keine IME-Komposition, Bildschirmtastatur, vollständige Unicode-Faltung
oder modifierabhängige Sonderzeichen-/Ziffernblock-Übersetzung. Tests:
SelectTypeAhead sowie die Controller-/Popup-Regressionen in Select.

`optgroup label="…"` erzeugt eine nicht auswählbare fette Überschrift im Dropdown.
Zugehörige Optionen sind um 12px eingerückt; ihre Auswahlfläche umfasst weiterhin
die gesamte Zeile. `disabled` an einer Gruppe deaktiviert alle ihre Optionen.
Überschriften sind weder Formularwerte noch Such- oder Pfeiltastenziele. Die
ausgewählte Option behält im geschlossenen Feld ihre normale Darstellung.
Leere Gruppen bleiben als Überschrift sichtbar. Individuelles Gruppen-CSS,
`legend`-Inhalte und verschachtelte Gruppen sind nicht unterstützt.

`Controls/SelectOptions` liefert neben der reinen Optionsliste die sichtbaren
`SelectRows` mit Gruppenzeilen. Optionsindizes bleiben stabil; das Popup speichert
deren tatsächliche Zeilenpositionen für `Reveal`. Die Feldbreite berücksichtigt
auch fette Gruppenüberschriften und die Einrückung. Tests: `tests/Optgroups.luau`.
Semantik: [HTML optgroup](https://html.spec.whatwg.org/multipage/form-elements.html#the-optgroup-element).

Die Feldbreite berücksichtigt die längste Option plus Pfeilbereich. Messwerte
werden je Schriftgröße/-familie gespeichert. Eine Auswahl ändert nur die Anzeige
und löst bei Benutzereingabe einmal `input` und `change` aus; kein Seitenlayout.
Beispiel 29 enthält genau ein Dropdown mit drei Optionen in den Gruppen
„Verfügbar“ und „Geplant“ (deaktiviert). `multiple` und `size > 1`
melden eine Diagnose und verwenden vorerst die Einfachauswahl. Individuelles
Options-CSS und native Browser-Popup-Optik sind nicht vollständig
nachgebildet. Tests: `tests/Select.luau`.

Der Radio-Punkt verwendet eine weiße EditableImage-Alphamaske, die pro Seite beim
ersten Radio erzeugt und gemeinsam benutzt wird. Die 9×9-Maske übernimmt die
gemessenen Alphawerte des Punkts aus der vergrößerten HTML-Referenz des Nutzers.
Ein 5×5-Quadrant (`COVERAGE` in `Rendering/RadioDot.luau`) wird gespiegelt; am Rand
stehen abgestufte Werte 40/70/102/202 statt eines konstanten Transparenzrings.
Abweichende Controlgrößen skalieren das Bild
mit dem bisherigen inneren Bereich. Hover/Pressed/Disabled verändern nur
ImageColor3, niemals die Pixel. Beim Schließen wird das Bild freigegeben. Wenn
EditableImage nicht verfügbar ist, erscheint der bisherige runde Frame als Ersatz.

- `Controls/Defaults`: Standardstile, vor dem Autoren-CSS angewendet.
- `Controls/State`, `Controls/FormModel`: Werte, Radiogruppen, Daten, Submit/Reset.
- `Controls/View`: GUI-Erzeugung, Maße und Zustandsdarstellung.
- `Input/HitTest`: native GUI-Reihenfolge, Vorfahren-Clipping und DOM-Zuordnung.
  Anonyme Compositor- und Top-Layer-Flächen lassen ihren eigenen Treffer
  durch, auch bei einem registrierten DOM-Vorfahren. Ihre echten Nachkommen
  bleiben separat anklickbar; `pointer-events:none` wird weiter am
  getroffenen DOM-Element ausgewertet, nicht an der Compositor-Hülle.
- `Input/Events`, `Input/Controller`: Ereignisse, Maus/Touch/Tastatur, Fokus, API.

Ein Controller je Seite hört auf Eingabeereignisse. Es gibt keine neue
Frame-Schleife. Texteingabe, Fokus und Auswahl ändern nur die betroffenen GUIs;
`output`-Text markiert seinen Bereich für ein [partielles Layout](DIRTY-LAYOUT.md).
Geeignete unveränderte Teilbäume werden dabei wiederverwendet.
Bei unveränderten nativen Textmaßen entfällt das Layout vollständig; die Größenprüfung
läuft im gleichen Worker. Ein Wechsel zwischen leerer und gefüllter Ausgabe ändert
die Höhe und benötigt weiterhin ein partielles Layout.
Fenster-Resize verwendet dieselben TextBox-Instanzen und erhält Werte/Fokus;
Ziehen am Textarea-Griff hebt den Eingabefokus hingegen bewusst auf. Listener
werden mit der Seite aufgeräumt; ersetzte Textfragmente bleiben nicht durch
die Hit-Test-Zuordnung im Speicher. Native Scrollbereiche bleiben eingeschaltet.

## Grenzen und Prüfung

Passwörter werden mit Punkten über einer unsichtbar geschriebenen TextBox
dargestellt. Cursor-/Auswahlpositionen und horizontales Scrollen langer Passwörter
sind noch nicht an diese Maske angepasst. Mobile Tastatur und native Eingabe
müssen ebenfalls in Studio beziehungsweise auf dem Gerät geprüft werden.
Die Grundlage ist [Roblox TextBox](https://create.roblox.com/docs/reference/engine/classes/TextBox).
Die Trefferreihenfolge kommt von
[GetGuiObjectsAtPosition](https://create.roblox.com/docs/reference/engine/classes/BasePlayerGui#GetGuiObjectsAtPosition).

Noch nicht enthalten: JavaScript-/`on…`-Ausführung, HTTP-Versand, dynamische
CSS-Pseudoklassen, vollständige HTML-Validierung, Feldset-Regeln, Mehrfachauswahl,
Datei-/Zahl-/Datumsfelder, native Browser-Ziehgriffe und automatisches Scrollen
zum Tab-Ziel. Tab beginnt nach Fokus oder Hover eines Felds. Nicht unterstützte
Input-Typen fallen auf Text zurück; `hidden` und `display:none`-Felder werden
derzeit auch in den Formulardaten ausgelassen. Verschachtelte Button-Inhalte,
mehrzeilige Output-Layouts und die vollständigen Rahmen-/Schattendekorationen
der übrigen Engine sind für Controls noch nicht umgesetzt.

`tests/Forms.luau` prüft Render-/Layout-Wiederverwendung, native Signal-Anbindung
mit GUI-Mocks, Label-/Tab-Fokus, UTF-16-Maxlength, Passwortmaskierung, Radiogruppen,
Submit/Reset und Pflichtfelder, Ereignisabbruch, Trefferreihenfolge, Clipping,
Touch-Abbruch und Cleanup. Die Tests ersetzen keinen visuellen Studio-Vergleich.
