# HTML-Grundparser: aktueller Umfang

Die vollständige Restliste bis zur konformen HTML-Elementabdeckung steht in
[HTML-COMPLETION.md](HTML-COMPLETION.md).

`head`, `title`, `meta`, `link` und `base` werden beim Mount gemeinsam
ausgewertet. Titel, Dokument-/Basis-URL, Standardziel, Meta-Datensätze und
aufgelöste Linkressourcen sind auf der Page verfügbar; Links und lokale
Stylesheets verwenden dieselbe Basisadresse. Umfang und Grenzen:
[Dokumentkopf und Metadaten](DOCUMENT-METADATA.md).

`filter` auf img-Bildpixeln: brightness, contrast, grayscale, invert, sepia,
saturate, hue-rotate, opacity, blur(0–100px) und drop-shadow(), kombinierbar in Reihenfolge. EditableImage mit
Seitencache und Original-Fallback; Demo34. [IMAGE-FILTERS.md](IMAGE-FILTERS.md).

CSS `cursor` mit allen gelieferten Cursor-Assets, automatischem Text-/Linkzeiger
und Resize-Capture. Demo32; [CURSORS.md](CURSORS.md).

`table`/`tr`/`td`/`th` und `thead`/`tbody`/`tfoot`: automatische Spaltenbreiten,
colspan/rowspan, separate Zellrahmen mit border-spacing sowie border-collapse:collapse
mit gemeinsamen Rahmen. Beispiel 31; [TABLES.md](TABLES.md).

`table-layout: fixed` sowie `col`/`colgroup`: Spaltenbreiten über CSS und span,
Spaltenfarben und gemeinsame Spaltenrahmen. Test 31 zeigt 100px/20%/Restplatz.
`caption`/`caption-side`, Hintergrundfarben auf Zeilen und Zeilengruppen sowie
`empty-cells:show/hide` bei separaten Rahmen sind ebenfalls in Test 31 enthalten.

Test 33 ergänzt Tabellen-/Zeilen-/Zellhöhen mit Prozentbezug, `visibility:collapse`
für Zeilen/Spalten und Gruppen, explizite CSS-Tabellenrollen auf anderen Elementen,
implizite Rasterzeilen bei überlangen rowspans sowie `direction:rtl` für Spalten
und logische Textausrichtung. Grenzen, insbesondere Prozentkonflikte und fehlender
vollständiger Bidi-Textsatz: [TABLES.md](TABLES.md).

`details`/`summary`: aufklappbare Bereiche mit `open`, passiven Pfeilen und
Maus/Touch/Tastaturbedienung. Beispiel 30; Teilumfang: [DETAILS.md](DETAILS.md).

`autofocus` auf Formularcontrols: einmal beim ersten fertigen Layout, unter
Beachtung vorhandener Eingabe/Fokuszustände. Details: [FORMS.md](FORMS.md).

`input type="email"`, `input type="url"` und `minlength` ergänzt. Syntax-/Längenprüfung
nutzt das vorhandene invalid-/Fokus-System. Details und URL-/IDN-Grenzen: [FORMS.md](FORMS.md).

`fieldset`/`legend`: Formulargruppen mit unterbrochenem oberen Rahmen und
`disabled`-Vererbung (Ausnahme erste direkte DOM-Legende). Das gemeinsame Beispiel 29
gruppiert die vorhandene Checkbox und die Radios. Details und Grenzen: [FORMS.md](FORMS.md).

Neu: Formulare mit TextBox, Number, Checkbox, Radio, Range, Buttons, Select/Option, Label, Output und lokalem
Ereignis-/Hit-Test-System; Teilumfang und API: [FORMS.md](FORMS.md). Vergleich 29.

`progress` und `meter`: passive Fortschritts-/Messwertbalken mit Wertebegrenzung,
Meter-Farbbereichen und unbestimmtem Fortschritt. Details ebenfalls in FORMS.md.

`em` und `rem` bei unterstützten CSS-Längen, einschließlich Kurzformen.
Root-/Elternbezug, Vererbung und Grenzen: [RELATIVE-LENGTHS.md](RELATIVE-LENGTHS.md).
Katalog: CSSProperties.RelativeUnits; Vergleichsbeispiel 28, Tests: RelativeLengths.
Ältere Abschnitte mit em/rem als Einschränkung werden dadurch ersetzt.

Rahmen-Eckübergänge jetzt diagonal, auch bei ungleichen Breiten; kleine
EditableImage-Eckbilder mit bisheriger Darstellung als Fallback.
[Details](BORDER-CORNERS.md). Bestehende Demo15 und 18–20.

Neu: word-wrap-Alias, border-style outset/groove/ridge, hsl()/hsla(), address,
dl/dt/dd und figure/figcaption. Standards und Grenzen:
[Kleine Ergänzungen](SMALL-ADDITIONS.md). Demoabschnitte 18–20.

Neu: `text-overflow: clip | ellipsis`, mit `overflow-x:hidden` für LTR-Zeilen.
Originaltext und Layout bleiben erhalten; Beispiel 17 zum Resize-Vergleich.
[Details und Grenzen](TEXT-OVERFLOW.md).

Neu: `outline`, `outline-width`, `outline-style`, `outline-color` und `outline-offset`
auf Blöcken, Bildern und Formular-Controls; zusätzliche Kontur ohne Layout-/Scrollplatz.
Stile auto/solid/dashed/dotted/double/none, positive/negative Abstände.
Native Fokusrahmen bleiben auch bei eigenen CSS-Rändern erhalten.
[Verhalten und Grenzen](OUTLINE.md).

## Bereits vorhanden

- Ein eigener Elementbaum aus Document-, Element-, Text- und Comment-Knoten.
- Verschachtelung mit Eltern-/Kind-Beziehungen, Namen und Attributen.
- Tag- und Attributnamen werden kleingeschrieben; Werte und Text bleiben erhalten.
- Attribute mit einfachen/doppelten Anführungszeichen oder ohne Anführungszeichen.
- Boolesche Attribute wie `checked`: vorhanden als leere Zeichenkette. `checked="false"` ist ebenfalls vorhanden.
- Bei mehrfach vorhandenen Attributen gewinnt das erste.
- HTML-Void-Elemente wie `img`, `br`, `input`, `meta`, `link` benötigen kein End-Tag.
- Optionale li-End-Tags vor dem nächsten li beziehungsweise dem Ende der direkten ul/ol-Liste; die nächste Listengrenze begrenzt die Suche.
- Optionale option-End-Tags innerhalb select/optgroup; Optionswerte und Startauswahl siehe FORMS.md.
- Kommentare und einfaches `<!DOCTYPE html>`.
- Häufige benannte Zeichenreferenzen mit Semikolon und dezimale/hexadezimale Unicode-Referenzen.
- Unbekannte benannte Referenzen bleiben unverändert; keine doppelte Decodierung.
- `script` und `style` bleiben Rohtext. Der reine Parser wertet sie nicht aus; der Renderer verarbeitet anschließend style-Regeln.
- `textarea` und `title` behalten Tags als Text, decodieren aber Zeichenreferenzen.
- BOM am Anfang entfernen, CR/CRLF in LF normalisieren, Nullzeichen ersetzen.
- Diagnosemeldungen für einige fehlerhafte Eingaben und einfache Wiederherstellung am passenden End-Tag.
- `findById` und `textContent` ohne rekursive Traversierung.

## Noch keine vollständige Browser-HTML-Verarbeitung

Dies ist ein dokumentierter HTML-Teilumfang. `parseHTML` bleibt Fragmentmodus;
`parseDocument` und `mountHTML` legen fehlende `html/head/body`-Container an.
Ausgelassene End-Tags wie `<p>eins<p>zwei` werden noch nicht nach den HTML5-Regeln korrigiert.
Auch die vollständige Tabellen-Reparatur, spezielle Formatierungsrekonstruktion und MathML fehlen.
Deklarative Shadow Roots über `template[shadowrootmode]` werden angehängt; der
Renderer verteilt benannte und namenlose Slots. Dynamische Shadow-DOM-APIs,
`slotchange`, Event-Retargeting, `:host` und `::slotted()` fehlen noch.
`<div/>` schließt sich im HTML-Teilumfang nicht selbst; der Slash erzeugt eine Diagnose.
Benannte Zeichenreferenzen ohne Semikolon und die vollständige HTML-Zeichentabelle fehlen.
Numerische C1-Steuerzeichen werden noch nicht nach der HTML-Windows-1252-Tabelle umgesetzt.
Andere Tags werden als normale Elemente gespeichert. Das verspricht noch keine Darstellung oder Funktion.

Leerzeichen bleiben im DOM erhalten. Zusammenfassen und Zeilenumbruch übernimmt das getrennte Textlayout.
CSS-Werte in `style` werden nur als Attributtext gespeichert. Bilder werden nicht geladen.
Es werden weder Roblox-GUIs erstellt noch Eingaben verarbeitet oder Scripts ausgeführt.

## Grenzen und Fehler

```lua
local document = Engine.parseHTML(html, {
    MaxBytes = 1024 * 1024, -- maximale Eingabelänge
    MaxNodes = 20000,      -- einschließlich Document
    MaxDepth = 256,       -- Elementtiefe, erstes Element = 1
    MaxDiagnostics = 100,
})
```

Die Werte sind positive ganze Zahlen. Überschrittene Grenzen brechen mit einem Luau-Fehler ab;
bei fremden Eingaben kann der Aufrufer `pcall` verwenden. Der Aufruf ist synchron und sollte bei einer Änderung
des gesamten HTML-Quelltexts erfolgen, nicht in jeder Frame-Schleife.
Diagnosen stehen in `document.Diagnostics` und enthalten Code, Message und Position.
Position ist ein Byte-Offset in der normalisierten Eingabe. Nach dem Meldungslimit wird
`DiagnosticsTruncated` gesetzt. Ein vollständiges Browser-Diagnosesystem ist das noch nicht.

Die Engine protokolliert den Inhalt nicht automatisch und enthält keine Testskripte.
Die CLI-/Studio-Tests liegen in `tests/HTML.luau`; die Demo liegt in `examples/HTMLParser.client.luau`.

## Erste Darstellung ergänzt

Neu unterstützt: hr, mark, sup/sub, background auf Inline-Text, vertical-align baseline/super/sub, font-size smaller und text-align-last. Standardwerte, Quellen, Fragmentlayout und Grenzen stehen in [Kleine Elemente](SMALL-ELEMENTS.md).

`Engine.mountHTML(targetFrame, html)` stellt inzwischen einen einfachen Block-Teilumfang mit CSS-Regeln und Inline-Styles dar.

Blockboxen unterstützen außerdem mehrschichtige `background-image`-Ebenen mit
zugeordneten Roblox-Assets sowie linearen, radialen und wiederholenden
Verläufen. Größe, Position, Wiederholung, Origin und Clip verwenden denselben
CSS-Quelltext wie der Browser. Details und Budgets:
[CSS-Hintergrundbilder](CSS-BACKGROUNDS.md).
Der Parser selbst bleibt unabhängig von dieser Darstellung. Das bearbeitbare Beispiel liegt in
`examples/HTMLPage.client.luau`; unterstützte Style-Eigenschaften stehen in der README.
Der HTML-Block enthält das vollständige Dokument einschließlich Google-Fonts-Link und CSS.
Er lässt sich unverändert als eigenständige HTML-Datei speichern. Der Browser lädt die Schriften online;
Roblox wertet die style-Regeln aus und verwendet für bekannte Familien seine registrierten Fonts.
Registrierte externe Stylesheets werden geladen. Es gibt keinen freien Netzwerkdownload von Stylesheets oder Fontdateien; `@font-face` wird als gültige Browser-Metadaten akzeptiert, die Fontwahl bleibt auf registrierte Roblox-Familien beschränkt.

`CSS/Stylesheet.luau` sammelt alle style-Blöcke vor der Darstellung und unterstützt Tag-, Klassen-, ID-,
Universal-, kombinierte, Nachfahren- und direkte Kindselektoren (`>`) sowie Kommagruppen. Regeln gelten nach Spezifität und
Quellreihenfolge; Inline-Styles haben Vorrang, `!important` steht über normalen Deklarationen.
`CSS/Syntax.luau` berücksichtigt Kommentare, Zeichenketten und geklammerte Werte beim Trennen.
Ungültige Werte ersetzen keine gültigen vorherigen Werte. Nicht unterstützte Selektoren verwerfen die
gesamte Selektorgruppe mit Diagnose. At-Regeln werden einschließlich verschachtelter Blöcke übersprungen.
Style-Medien sind auf leer/all/screen beschränkt; andere Angaben werden mit Diagnose übersprungen.
HTML verwendet Tag-, Klassen-, ID-, Universal-, Attribut-, Nachfahren-, Kind- und Geschwisterselektoren sowie strukturelle und interaktive Pseudoklassen. CSS-Escapes fehlen noch. Die vollständige CSS-Restliste steht in [CSS-COMPLETION.md](CSS-COMPLETION.md).
`font-weight` akzeptiert normal/400, bold/700 und Zahlen von 1 bis 1000 mit Vererbung. Der nächste Roblox-Schnitt in 100er-Stufen von Thin bis Heavy wird für Messung und Darstellung verwendet; 600 entspricht SemiBold. Die `font`-Kurzform unterstützt diese Gewichte einschließlich Größe und Zeilenhöhe. h1/h2/b/strong verwenden standardmäßig 700; CSS kann dies überschreiben. bolder/lighter fehlen.

Welche Elemente ausdrücklich behandelt werden und welche Einschränkungen sie haben, steht zentral in
[`src/HTMLEngine/HTML/Elements.luau`](../src/HTMLEngine/HTML/Elements.luau), auch abrufbar als `Engine.Elements`.
Renderer und Standardformatierung lesen diesen Katalog. `partial` bezeichnet den dokumentierten Darstellungs-Teilumfang,
`parser-only` ausschließlich die Speicherung im DOM. Andere Tags kann der Parser ebenfalls speichern;
ihre bisherige Darstellung als generischer Block verspricht keine Unterstützung der jeweiligen HTML-Funktion.
Der Katalog beschreibt Elementtypen. Konkrete Seitenelemente liegen weiterhin in `page.Document`.

CSS-Eigenschaften sind in [`CSS/Properties.luau`](../src/HTMLEngine/CSS/Properties.luau) dokumentiert (`Engine.CSSProperties`).

Textschatten: `text-shadow` unterstützt zunächst bis zu 16 scharfe Schatten mit px-Offset, Farbe/Alpha und Vererbung; none deaktiviert sie. Kein Blur. Details und Grenzen: [TEXT-SHADOW.md](TEXT-SHADOW.md).

Bilder: `img` unterstützt die seitenbezogene src→Asset-Zuordnung, alt, width/height, CSS-Größengrenzen und alle fünf object-fit-Werte. `picture`/`source` sowie `srcset`/`sizes` wählen beim Mount eine responsive Quelle; `map`/`area` liefern rechteckige, runde, polygonale und Default-Linkflächen. vertical-align unterstützt zusätzlich middle, text-top/text-bottom, top/bottom und px/%. Rahmen, runde Ecken, Margin/Padding und box-sizing sind direkt auf img möglich. Fehlende automatische Achsen können die Roblox-Assetmaße einmal pro Seite lesen. Details, Einschränkungen und Browser-Testdatei: [IMAGES.md](IMAGES.md).

Medien: `audio`, `video`, deren `source`-Kinder sowie einfache WebVTT-`track`-
Untertitel verwenden im Browser normale Dateien und in Roblox getrennte
`Audio`-/`Videos`-/`Tracks`-Zuordnungen. Eigene Controls unterstützen Play,
Pause, Seek, Mute und CC; Video-Poster bleiben normale `Images`-Zuordnungen.
Details und Grenzen: [MEDIA.md](MEDIA.md).

Eingebettete Dokumente: `iframe`, `object[type=text/html]` und
`embed[type=text/html]` mounten registrierte interne Websites in einer eigenen
PageSession. `object` zeigt bei fehlender Quelle oder nicht unterstütztem Typ
seinen HTML-Fallback. Größen, Rahmen, Scrollen und Lifecycle laufen über das
gewöhnliche Layout. Details und Grenzen: [IFRAMES.md](IFRAMES.md).

Listen: ul/ol/li erzeugen Blockcontainer und separate Außenmarker. Standardmäßig 40px linkes Padding auf ul/ol, vertikale Außenabstände von 1em nach der endgültigen CSS-Schriftgröße, bei verschachtelten Listen 0. li hat kein zusätzliches Margin/Padding. ul verwendet disc, ab zweiter Listenebene circle und ab dritter square; ol decimal. Autor-CSS überschreibt diese Standards. Grundlage: [HTML-Standard: Listen](https://html.spec.whatwg.org/multipage/rendering.html#lists).

`list-style-type: disc/circle/square/decimal/decimal-leading-zero/lower-alpha/upper-alpha/lower-roman/upper-roman/none` wird vererbt. Nummerierung berücksichtigt gerenderte direkte li-Kinder, ol start/reversed und li value (vorzeichenbehaftete Ganzzahlen bis 32 Bit). Verborgene Einträge und mit display:block umgestellte li werden nicht gezählt; list-style-type:none blendet nur den Marker aus. Unterlisten zählen unabhängig. Ein isoliertes li bekommt einen Punkt. Alphabetisch ab 1, römisch 1–3999, außerhalb decimal. `list-style-image:url(...)` verwendet ein über `options.Images` zugeordnetes quadratisches 1em-Bild und fällt ohne Zuordnung auf den Markertyp zurück. Keine generischen CSS-Counter, type=a/A/i/I oder RTL-Marker. Details: [Listenformate](LIST-DECORATION-EXTENSIONS.md).

Marker stehen außerhalb der li-Inhaltsbreite und verkleinern diese nicht. WordFlow liefert die erste Zeilengrundlinie, BlockLayout reicht diese über Unterblöcke weiter. So bleiben Marker bei mehrzeiligem Text sowie gemischten Schriftgrößen an der ersten Zeile; leere Einträge mit Marker erhalten eine Zeilenhöhe. Dezimalmarker einschließlich Punkt/Leerzeichen werden individuell gemessen und rechts an der Inhaltskante ausgerichtet. Font-Preload schließt diese Labels ein, Messungen bleiben beim Resize erhalten und werden bei Abbruch nicht geschrieben. Symbolmarker nutzen Frames/UICorner/UIStroke, orientiert an [Blink-Listengeometrie](https://raw.githubusercontent.com/chromium/chromium/main/third_party/blink/renderer/core/layout/list/list_marker.cc); echte Font-Ascent ist in Roblox nicht verfügbar, daher verwenden sie die bestehende Baseline-Näherung. Pixelidentische Marker sind nicht garantiert.

BlockLayout berechnet für ul/ol/li/blockquote zusätzlich effektive obere/untere Ränder vor der Anordnung: Kindränder am offenen oberen/unteren Rand fallen mit dem Elternrand zusammen. Border/Padding, overflow hidden und unten feste/minimale Höhe verhindern dies. Text unterbricht den Zusammenfall. Das verhindert doppelte Absatzabstände in Listeneinträgen, ohne Style.Margin beim Resize zu verändern. Kein vollständiges allgemeines Eltern-Kind- oder Leerblock-Collapsing; linke negative Markerüberläufe erweitern die Canvas nicht. Tests in tests/Lists.luau decken Abstände, Verschachtelung, Umbrüche, Markergrundlinien, Nummernwechsel, leere/verborgene Einträge, CSS-Overrides und Messwiederverwendung ab. Native Sichtprüfung noch offen.

`line-height` unterstützt normal, nichtnegative Dezimalzahlen, px und Prozentwerte einschließlich Vererbung.
Faktoren beziehen sich auf die CSS-Schriftgröße; Prozentwerte werden vor der Vererbung in Pixel aufgelöst.
Der Zeilenschritt wird getrennt von der Höhe der Wort-Labels berechnet. Wörter mit verschiedenen Schriftgrößen
und Schriftfamilien teilen sich pro Zeile die Grundlinie aus ihren Fontprofilen. Der größte Platz über und unter
der Grundlinie bestimmt die Zeilenhöhe, mindestens mit der Fontbox des Absatzstils. Gemischte Schriften können
deshalb auch bei gleicher fester `line-height` eine höhere Zeile ergeben. `normal` und die logischen Fontmetriken
bleiben Näherungen; unkalibrierte Fonts verwenden `round(TextSize * 0.8)` als geschätzte Grundlinie.

Inline-Text unterstützt `font-size`, `font-family`, `font-weight`, `font-style`, `color` und `line-height` mit Vererbung sowie `display: none`.
Verschachtelte Spans werden berücksichtigt. Leerraum wird über Taggrenzen hinweg zusammengefasst; jedes Wort und
sein nötiges Leerzeichen werden weiterhin separat gemessen. Ändert sich der Stil innerhalb eines ungetrennten Wortes,
bleibt dessen erster Stil erhalten und eine Diagnose erklärt die Einschränkung. Ein vollständiges Inline-Box-Modell,
Inline-Margin/Padding/Hintergrund und andere `vertical-align`-Werte fehlen. Leere Spans und reine
Inline-Vorfahren ohne eigenen Text liefern noch keine zusätzlichen Zeilenmetriken.
Details und ein Beispiel: [README – Gemeinsame Grundlinie](../README.md#gemeinsame-grundlinie).

`text-align` unterstützt start (Standard), end, left, center, right und justify mit Vererbung. Maßgeblich ist der Stil des Blockcontainers;
ein eigener Span-Wert verschiebt keine einzelnen Wörter. Jede Zeile wird nach dem Umbruch innerhalb der Inhaltsbreite
ausgerichtet, einschließlich letzter Zeile und br. Padding, Grundlinien und individuelle Wortmessungen bleiben erhalten.
start/end folgen direction; vollständiger Unicode-Bidi-Textsatz fehlt. Überbreite Wörter können nach links überlaufen; das bisherige Scrollmodell kann
diesen linken Überlauf nicht nachträglich zugänglich machen. Die sichtbare Demo enthält nur noch kompakte Beispiele.

`justify` dehnt nur normale Wortabstände bei automatischem Umbruch. Letzte Zeilen, Zeilen vor br und
Zeilen ohne dehnbare Abstände bleiben linksbündig. Geschützte Leerzeichen werden nicht zerlegt.
`text-align-last` überschreibt die Ausrichtung letzter Zeilen und Zeilen vor festen Umbrüchen; keine automatische Silbentrennung.

## Weitere Schritte

### Leerraum und Umbruch

`white-space: normal/nowrap/pre/pre-wrap/pre-line/break-spaces` wird vererbt. normal (Standard) und nowrap kollabieren HTML-Leerraum; nowrap unterdrückt automatische Zeilenumbrüche, nicht br. pre/pre-wrap erhalten U+0020, Tab und Quelltext-Zeilenumbrüche (CRLF/CR/Form Feed normalisiert), pre-wrap erlaubt zusätzlich Umbrüche zwischen Wortgruppen. pre-line erhält diese Quelltext-Zeilenumbrüche, kollabiert jedoch Leerzeichen/Tabs und entfernt sie an Zeilengrenzen. break-spaces erhält Leerraum einschließlich Endleerzeichen, erlaubt einen Umbruch nach jedem erhaltenen Leerzeichen/Tab (nicht vor dem ersten einer Folge) und berücksichtigt ihn bei Ausrichtung und Canvas-Ausdehnung. Normale inline-nowrap-Gruppen werden vor dem Umbrechen zusammen auf ihre Breite geprüft. Der DOM bleibt unverändert.

InlineWords erzeugt für erhaltenen Leerraum Space-Einträge und für erhaltene Zeilenumbrüche Breaks. In break-spaces erhält jedes Leerzeichen/Tab einen eigenen Eintrag; ansonsten bleiben Folgen zusammen. RenderTree erstellt transparente Space-Frames, keine Satz-Labels; WordLayout misst pro Space-Eintrag eine eigene native Leerzeichenbreite und behält sie. WordFlow berechnet Tabs nach der Zeilenposition, berücksichtigt Leerzeilen, führende Einrückungen, pre-Endleerzeichen und hängende pre-wrap-Endleerzeichen. Letztere zählen aktuell nicht zur Ausrichtung oder rechten Canvas-Ausdehnung. Erhaltene Leerzeichen können bei justify gedehnt werden. TextDecoration zeichnet auch auf Space-Frames. Whitespace-only-Zeilen in pre/pre-wrap/break-spaces belegen Höhe. Ein abschließender Zeilenumbruch fügt keine zusätzliche Leerzeile hinzu.

`tab-size` ist vererbt, Standard 8; akzeptiert nichtnegative Zahlen und px (inklusive 0 und Bruchzahlen), keine Prozentwerte oder anderen Längeneinheiten. Zahlen multiplizieren die native Leerzeichenbreite der nächsten Blockschrift inklusive deren word-spacing/letter-spacing; ein abweichender Inline-Stil verändert diese Bezugsbreite nicht. Pixelwerte definieren den Abstand der Stopps direkt. 0 entfernt den Tabvorschub; kollabierende Modi wandeln Tabs weiterhin in normale Leerzeichen um. Zusätzliche Messungen der Blockschrift sind je Space-Eintrag gecacht und werden nach Schriftänderung erneuert. Grundlage: [CSS Text: tab-size](https://www.w3.org/TR/css-text-3/#tab-size-property).

Bei Tabs beträgt der Mindestvorschub 0.5ch (halbe native Breite der Ziffer 0), nicht eine halbe Leerzeichenbreite. Ist der nächste Stopp näher, wird der folgende verwendet. Die zusätzliche Ziffernmessung erfolgt nur für Space-Einträge mit Tabs und wird zusammen mit der Leerzeichenmessung wiederverwendet. Grundlage: [CSS Text: Tabpositionierung](https://www.w3.org/TR/css-text-3/#white-space-phase-2).

Grenzen: keine vollständigen Unicode-/Sprachregeln; insbesondere keine zusätzlichen Unicode-Leerraumtrennzeichen für break-spaces. Tabstopps mit Blocksatz bleiben eine Näherung, da die Dehnung nach der Tabpositionierung erfolgt. pre-wrap-Endleerzeichen werden derzeit auch vor festen Umbrüchen und am Blockende vollständig hängend behandelt; die CSS-Unterscheidung zwischen bedingtem und unbedingtem Hängen fehlt. Wechsel zwischen kollabierendem/erhaltendem Leerraum an komplexen Inline-Grenzen folgt dem vereinfachten Wortmodell; kein vollständiger CSS-Text-Algorithmus. Kein dynamischer Wechsel der Wort-/Whitespace-Struktur ohne neues Mount. Tests: tests/WhiteSpace.luau. Grundlage: [CSS Text: white-space](https://www.w3.org/TR/css-text-3/#white-space-property). Die gemeinsame HTML-/Studio-Demo enthält je eine Variante; native Sichtprüfung offen.

### Vertikale Außenabstände

Benachbarte Blockgeschwister verwenden für unteren/oberen Margin den größeren der beiden nichtnegativen Werte. Reiner HTML-Leerraum und display:none trennen sie nicht; ein tatsächlicher Textlauf schon. Die Berechnung erfolgt bei jedem Layout neu ohne Änderungen an den CSS-Werten. Padding, Rahmen und overflow der Geschwister ändern diese äußere Regel nicht. Margin nach einer festen Box wird nicht noch einmal an das Ende ihrer überlaufenden Kinder angehängt. Grenzen: noch kein Eltern-Kind-Collapsing, Zusammenfallen durch leere Blöcke oder negative Margins. Die bestehende kompakte Demo zeigt den Effekt bereits zwischen ihren p-Absätzen und Karten. Test: tests/MarginCollapse.luau. Grundlage: [CSS collapsing margins](https://www.w3.org/TR/CSS2/box.html#collapsing-margins).

### Höhenbegrenzung und Überlauf

`min-height: auto/0/px`, `max-height: none/0/px` und `overflow: hidden/visible/auto/scroll` sind für Blockcontainer implementiert und nicht vererbt. overflow nimmt einen oder zwei Werte (x/y); overflow-x und overflow-y setzen die einzelnen Achsen. Höhengrenzen sind nichtnegativ und berücksichtigen box-sizing. auto entspricht keiner zusätzlichen Mindesthöhe, none entfernt die Maximalhöhe. Erst Maximum, dann Minimum anwenden; Padding und Rahmen können bei border-box nicht unterschritten werden. Prozenthöhen, intrinsische Werte und andere Einheiten fehlen.

Alle Kinder werden vollständig angeordnet. Die belegte Höhe im Blockfluss ist die begrenzte Boxhöhe plus Margin; sichtbarer Überlauf wird separat bis zur Seiten-Scrollfläche weitergereicht. Ein hidden/auto/scroll-Vorfahre begrenzt diese äußere Ausdehnung auf seine Box. Auto/scroll bewegen einen eigenen Inhaltsbaum im nativen ScrollingFrame innerhalb der Rahmenkante; Leistenplatz und lokale Scrollfläche werden im Layout berücksichtigt. Reines hidden nutzt weiterhin den Frame-Zuschnitt an der Außenkante. Clipping bleibt rechteckig, auch bei UICorner. Ein Kind mit visible kann das Clipping seiner Vorfahren nicht aufheben. Keine öffentliche programmatische Scroll-API oder Übertragung von html/body-overflow auf den Viewport. Details: [Scrollbereiche](SCROLLING.md). Tests: `tests/Overflow.luau` und `tests/Scrolling.luau`; Demo-IDs scroll-text und scroll-cards. Studio-Sichtprüfung offen.

### Weitere bereits implementierte Eigenschaften

`box-sizing` unterstützt content-box (Standard) und border-box, ohne Vererbung. Bei border-box werden width/height/min-width/max-width einschließlich Padding und Rahmen verstanden, ohne Margin. Inhaltsmaße können auf 0 fallen; die Box bleibt mindestens so groß wie ihre Padding-/Rahmenkanten. `min-width` akzeptiert auto/0/px/%, `max-width` none/0/px/%; alle Längen nichtnegativ. Im vorhandenen Blocklayout entspricht min-width:auto keiner zusätzlichen Mindestbreite. Grenzen werden nach width/Auto-Breite angewendet, zuerst Maximum, dann Minimum; dadurch gewinnt min-width im Konflikt. Prozent beziehen sich auf die Eltern-Inhaltsbreite, auch bei verschachtelten Border-Boxen. Inline-Text speichert box-sizing ohne eigene Größenwirkung (Universalregel möglich); min/max-width auf Inline-Text bleiben nicht unterstützt. Keine intrinsischen Größen, em/rem oder calc; Höhengrenzen unterstützen nur px. Resize verändert Boxen/Umbruch, ohne unveränderte Wortmaße neu zu messen. Feste Höhen belegen nur ihre Boxhöhe im Seitenfluss; sichtbarer Überlauf wird separat für die Scrollfläche erfasst. Grundlage: [CSS Box Sizing Level 3](https://www.w3.org/TR/css-sizing-3/). Tests: tests/BoxSizing.luau; Beispiel id=box-sizing mit 180–480px Gesamtbreite. Visuelle Studio-Bestätigung offen.

Blöcke und Bilder unterstützen `border` mit px oder thin/medium/thick, solid/inset/outset/groove/ridge/none/dashed/dotted/double und einer Farbe oder currentcolor in beliebiger Reihenfolge. Fehlende Werte werden auf 3px/none/currentcolor zurückgesetzt. `border-width`, `border-style` und `border-color` akzeptieren 1–4 Werte; `border-top/right/bottom/left` und ihre Longhands setzen einzelne Kanten. CSS-Reihenfolge und !important gelten pro Komponente und Seite. Die Eigenschaften werden nicht vererbt. currentcolor wird nach der Cascade anhand der finalen Textfarbe aufgelöst. `border-radius` akzeptiert ein bis vier Werte und elliptische Werte nach `/`; die vier Eck-Longhands unterstützen Längen und Prozente. Auch bei border:none bleibt die Rundung bestehen. Einfarbige Boxen verwenden eine vollständige gerundete EditableImage-Oberfläche. Bei `overflow:hidden` enthält dasselbe Bild eine Vordergrundmaske gegen den nächsten deckenden Hintergrund und der HitTest folgt der exakten Ellipse. Transparente Umgebungen und Bildhintergründe verwenden die größte gemeinsame sichere UICorner-Rundung. Musterkanten sind rechteckig, ohne durchgehenden Musterverlauf um Ecken. Details und Mustergrenzen: [Rahmenkanten](BORDER-SIDES.md).

BlockLayout behandelt Rahmen als zusätzliche Kanten im content-box-Modell: Auto-Breite zieht Rahmen/Padding/Margin vom Platz ab, explizite px/%-Breite und px-Höhe bleiben Inhaltsmaße. Kindpositionen, Umbruch, Geschwisterfluss und Scrollausdehnung berücksichtigen den Rahmen. UIStroke zeichnet mit BorderStrokePosition.Inner, UICorner rundet Hintergrund/Rahmen und begrenzt den Radius nativ auf die halbe kürzere Boxkante. Modifikatoren werden einmal beim Aufbau über GuiFactory.modifier erstellt, beim Resize wiederverwendet und mit ihren Eltern entfernt. Grundlagen: [Roblox UI appearance modifiers](https://create.roblox.com/docs/ui/appearance-modifiers). Tests: tests/Border.luau und tests/GuiFactory.luau; echte Studio-Optik noch nicht geprüft.

`letter-spacing: normal/0/px` (auch negative px) wird vererbt. Nichtnull Werte erzeugen ein Wort-Frame mit einem Label je Graphem; [Roblox utf8.graphemes](https://create.roblox.com/docs/reference/engine/libraries/utf8/graphemes) hält zusammengesetzte Zeichen zusammen. Jeder Cluster wird einzeln gemessen, kein geteilter Messcache. Wortweite ist die Summe der Zeichenbreiten plus Abstände zwischen ihnen; kein Zusatz am Zeilenanfang/-ende. Normale Wortlücken berücksichtigen die zusätzlichen Zeichenübergänge, kombiniert mit word-spacing und justify. Auch NBSP-Gruppen bleiben untrennbar, ihre innere Wortweite berücksichtigt im Zeichenmodus word-spacing. Baselines, text-indent und skip-ink funktionieren weiter; SkipInk nutzt die Zeichenpositionen statt Präfixmessungen. normal/0 bleibt beim Seitenaufbau der bisherige Wort-Label-Pfad. Grenzen: voneinander unabhängige Zeichendarstellung ohne wortübergreifendes Shaping/Kerning/Ligaturen, keine %, em/rem oder RTL. Negative Abstände können überlappen; rechter sichtbarer Überlauf wird mitgerechnet. Kein neues DOM-Dirty-System oder dynamischer Wechsel der Label-Struktur. Tests: `tests/LetterSpacing.luau`; CLI-Graphemgrenzen der Unicode-Testdaten kommen aus JS Intl.Segmenter, echter Roblox-Sichttest noch offen.

`word-spacing: normal/0/px` (px auch negativ) wird vererbt und zum normalen gemessenen Leerzeichen addiert. Kollabierter Whitespace erhält den Stil des ersten überlebenden Leerzeichens. Der Wert ist in CSS-Pixeln, ohne Font-Größenkorrektur. Umbrüche, Ausrichtung, Blocksatz, Einzug und Unterlinien verwenden den Zusatzabstand; native Messwerte bleiben unverändert und wiederverwendbar. Große negative Werte dürfen überlappen; horizontale Ausdehnung berücksichtigt auch frühere, weiter rechts endende Wörter. Noch keine %, em/rem oder weiteren Unicode-Worttrenner. NBSP innerhalb eines nativen Wort-Labels bleibt nativ/untrennbar und erzeugt bei nichtnull Abstand eine Diagnose; der Zeichenmodus bei letter-spacing unterstützt dagegen diesen Zusatzabstand. Tests: `tests/WordSpacing.luau`, ein kompakter Demo-Absatz mit 6 px Zusatzabstand. Semantik: [CSS word-spacing](https://www.w3.org/TR/css-text-3/#word-spacing-property).

`text-transform: none/uppercase/lowercase/capitalize` wird vor Wortmessung und Label-Erzeugung angewendet. DOM-textContent bleibt unverändert. Unterstützt werden ASCII und Latin-1-Buchstaben inklusive Ä/Ö/Ü/ß/ẞ; uppercase erweitert ß zu SS, lowercase wandelt ẞ zu ß. capitalize verändert nur Wortanfänge, erkennt Leerraum/NBSP und Bindestriche, lässt die übrige Schreibweise stehen. Keine vollständigen Unicode-/Sprachregeln; andere Zeichen bleiben erhalten. Stilwechsel erzeugen untrennbare Fragmente; text-transform wird je Fragment angewendet, capitalize setzt die Großschreibung an einer Fragmentgrenze nicht neu an.

`text-indent` akzeptiert 0, px und Prozent (auch negativ) mit Vererbung. Prozentwerte beziehen sich auf die aktuelle Block-Inhaltsbreite. Nur die erste formatierte Zeile erhält den Einzug, weder automatische Folgezeilen noch Zeilen nach br; spätere anonyme Textblöcke nach einem Blockelement beginnen ohne erneuten Elterneinzug. Inline-Angaben verschieben keine einzelnen Wörter. Ausrichtung und Blocksatz berücksichtigen den verfügbaren Platz; unveränderte Wortmaße bleiben bei Resize erhalten. Keine em/rem-, hanging-, each-line- oder RTL-Unterstützung. Negativer linker Überlauf bleibt eine Einschränkung des bisherigen Scrollmodells.

Semantikgrundlage: [CSS Text Level 3](https://www.w3.org/TR/css-text-3/), Abschnitte text-transform und text-indent. Tests: `tests/TextTransform.luau`, `tests/TextIndent.luau`; je ein kompakter Beispielabsatz im gemeinsamen HTML-Dokument.

Unter-/Durchstreichungen sind mit `text-decoration: none/underline/line-through` und der Kombination
beider Linien sowie u/s/del ergänzt. Die Engine schätzt bewusst: Unterlinie Baseline+max(1, round(CSS-font-size/14)) px (1 px bis Größe 20, 2 px ab 21, 3 px ab 35; weitere Übergänge geschätzt), Durchstrich
Baseline-round(CSS-font-size/4), automatische Dicke max(1, floor(CSS-font-size * 0.049)) für alle Schriften und Gewichte. Gemeinsame Näherung passend zu den drei gemeldeten Übergängen: 2 px ab 41, 3 px ab 62, 4 px ab 82. text-decoration-thickness akzeptiert auto, px und Prozent (explizite px/% gerundet, mindestens 1 px). Das gemeinsame Demo-HTML verwendet automatische Dicke; Browser-auto kann abweichen. Keine individuellen Fontmetriken.
Dekorationen werden von Vorfahren weitergetragen, obwohl die CSS-Eigenschaft selbst nicht vererbt wird;
ein child none entfernt deshalb keine bestehende Vorfahrenlinie. Ursprungsfarbe/-dicke bleiben erhalten.
Normale Wortabstände, Umbrüche und Blocksatz werden berücksichtigt. Experimentelles `text-decoration-skip-ink: auto/none`: auto ist Standard, schätzt Lücken bei p/g/j/q/y über wortlokale Präfixmessungen und mit der Textgröße skalierende Randabstände. Keine echten Glyphenkonturen, keine Garantie für alle Schriftvarianten oder andere Alphabete. none unterdrückt diese Zusatzmessungen und Lücken; Durchstriche bleiben durchgehend. Beim Umbruch bleiben Lücken und Frame-Segmente wiederverwendbar. Kein Kerning über Fragmentgrenzen,
overline oder getrennten text-decoration-color/style/text-underline-offset-Eigenschaften; kein from-font.
Browser und Roblox verwenden dasselbe Demo-HTML; die vereinfachte Geometrie muss nicht pixelgleich sein.

Den vorhandenen Inline-Style- und Block-Teilumfang um weitere CSS-Funktionen, genaueren Textfluss und
weitere Layoutverfahren erweitern. DOM-Änderungen und gezielte Aktualisierungen erhalten
eigene Schnittstellen; der rohe Baum ist bisher noch kein reaktives Dirty-System.

Wort- und Leerzeichenmessungen berücksichtigen das Schriftgewicht getrennt. Unveränderte individuelle Maße bleiben beim Umbruch erhalten; Änderungen nur am Gewicht lösen die betroffene Messung neu aus. Bold verwendet vorerst die Regular-Größen-/Linienwerte als Näherung und wird nicht als separat kalibriert gemeldet.

`font-style` unterstützt normal/italic mit Vererbung und CSS-Overrides. i/em sind standardmäßig kursiv;
verschachtelte starke Betonung kombiniert italic mit Gewicht 700. oblique/Neigungswinkel fehlen.
FontProfiles.face nimmt optional Gewicht und Stil entgegen; Wort- und Leerzeichenmessschlüssel enthalten beides.
Italic/Fett-Kursiv verwenden Regular-Größen- und Linienwerte als Näherung, nicht als eigene Kalibrierung.
Welche Schnitte tatsächlich existieren, hängt von der Roblox-Familie ab; fehlende Schnitte löst Roblox auf.
Der kurze Google-Fonts-Link der identischen Browser-/Studio-Demo fordert alle vier Varianten an.
