# Eingebettete Dokumente

Ein normales Browser-`iframe` kann eine registrierte Engine-Website auch in
Roblox einbetten:

```html
<iframe
  src="../css-background-position/index.html"
  title="Background positions"
  width="720"
  height="420">
</iframe>
```

Im Browser lädt `src` wie gewohnt. In Roblox löst der Website-Katalog dieselbe
URL auf und mountet das gefundene Modul als eigene `PageSession` in die
begrenzte iframe-Fläche. Das eingebettete Dokument besitzt eine eigene
Scrollposition, Eingabesteuerung, Formulare, Medien und Ressourcenbereinigung.
Die CSS-Hintergrundfarbe von `html` beziehungsweise bei transparentem Root von
`body` wird auf den vollständigen Dokument-Canvas übertragen. Sie füllt damit
auch den sichtbaren iframe-Bereich und horizontalen Überlauf statt dort die
weiße technische Host-Fläche zu zeigen.

Ohne Größenangaben verwendet das Element 300 × 150 Pixel. HTML-Attribute und
CSS für Breite, Höhe, Box-Sizing, Padding, Rahmen, Margin, Sichtbarkeit,
Positionierung, Flex und Grid laufen über das normale Layout der Engine.

Interne Links navigieren standardmäßig nur das eingebettete Dokument.
`target="_parent"` wechselt die direkt umgebende Seite; `target="_top"` wird
durch verschachtelte Frames bis zur obersten Seite weitergereicht. Fragmente
derselben Adresse scrollen ohne erneuten Mount. Eine unbekannte interne URL
zeigt die registrierte 404-Seite.

`srcdoc` wird ebenfalls als unabhängiges Dokument gerendert. Leeres `src`
erzeugt eine leere `about:blank`-Seite. Maximal vier iframe-Ebenen dürfen
gleichzeitig verschachtelt werden. Beim Navigieren, Entfernen oder Zerstören der
Elternseite wird jede untergeordnete PageSession bereinigt.

`object` und `embed` verwenden für interne HTML-Dokumente dieselbe isolierte
Laufzeit. `object` liest die Adresse aus `data`, `embed` aus `src`:

```html
<object data="../css-background-position/index.html" type="text/html">
  <p>Fallback content</p>
</object>
<embed src="../css-individual-transforms/index.html" type="text/html">
```

Ohne `data` oder bei einem nicht unterstützten `object[type]` rendert die
Engine den Kindinhalt. Bei erfolgreichem HTML-Dokument bleibt dieser
Fallback wie im Browser verborgen. `embed` ist ein leeres Element und zeigt
bei nicht unterstütztem Typ stattdessen einen lokalen Fehlerzustand. Derzeit
werden `text/html`, `application/xhtml+xml` und ein fehlender Typ als internes
HTML-Dokument behandelt.

Roblox stellt keinen allgemeinen WebView bereit. Externe Websites können daher
nicht dargestellt werden und erzeugen einen sichtbaren Fallback. Noch nicht
vorhanden sind benannte Browsing-Kontexte, eigener Verlauf, echtes Lazy Loading,
load/error-DOM-Ereignisse, Sandbox- und Permissions-Policy-Regeln.
`object` und `embed` unterstützen noch keine Bilder, Plugins, Formzuordnung
oder externen Netzressourcen.
