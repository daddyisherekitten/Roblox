# WAAPI: Layoutwerte und zusammengesetzte Effekte

Stand: 4. Oktober 2026. Ergänzung zu P09. Grundlage sind [Web Animations Level 1](https://www.w3.org/TR/web-animations-1/), [Web Animations Level 2](https://www.w3.org/TR/web-animations-2/) und [CSS Transforms: Interpolation, Addition und Accumulation](https://www.w3.org/TR/css-transforms-1/#interpolation-of-transforms).

## Einordnung

Die Script-Animationen verwenden dieselben CSS-Werte und dieselben behaltenen Boxen wie das normale Layout. Das erweiterte Profil umfasst Breite/Höhe, physische und logische Min-/Max-Maße, Positionierungsabstände, Margin/Padding, Flex-Basis/Grow/Shrink, Zeilen-/Spaltenabstände und Buchstaben-/Wortabstände. Transform, Offset-Distance, Opacity und Hintergrundfarbe bleiben Paint-Effekte.

Die Autorwerte werden getrennt von den abgetasteten Werten aufbewahrt. Ein neuer Frame darf den letzten Frame deshalb nicht als neuen Ausgangswert verwenden. Ändert JavaScript während einer additiven Animation die Autorbreite, wird der nächste abgetastete Wert mit dieser neuen Breite kombiniert. `cancel()` stellt den aktuellen Autorwert wieder her.

Layoutwerte markieren die betroffene Box und ihre Abhängigkeiten als schmutzig. Ein synchroner Geometriezugriff veröffentlicht das ausstehende Layout, danach verwenden unveränderte weitere Zugriffe die veröffentlichten Werte. Transform-/Opacity-Abtastungen verändern Paint und aktuelle CSSOM-Werte ohne eigenes Neulayout. Ein pausierter Effekt behält keine Animation-Frame-Anforderung.

## Composition und Commit

`composite:'add'` und `'accumulate'` folgen dem jeweiligen Werttyp. Längen/Zahlen werden addiert. Transform-Addition verkettet Operationen, Accumulation kombiniert passende Funktionen: Scale akkumuliert relativ zur Identität `1`, statt die Faktoren zu multiplizieren. Individuelle `translate`/`rotate`/`scale`-Eigenschaften bleiben von der animierten `transform`-Eigenschaft getrennt und werden einmal auf das Ergebnis angewendet. Keyframe-eigene Composite-Werte und implizite Endpunkte sind Teil derselben Abtastung.

`commitStyles()` schreibt den berechneten Wert in die Inline-Deklaration. Bei einem weiterhin aktiven additiven Effekt kann das **vor** `cancel()` eine weitere Addition ergeben; der Browser zeigt bei einer Autorbreite von `100px` und einem additiven Effekt von `20px` nach Commit `140px`, nach Cancel `120px`. Das ist keine Zusage, dass Commit allein einen additiven Effekt visuell einfriert.

Wichtige Deklarationen behalten ihre Cascade-Priorität. Opacity-Endpunkte und Zwischenwerte der Effektkette bleiben für die Composition ungeklammert; erst der verwendete Endwert wird auf `0..1` begrenzt.

## Ausdrückliche Browser-/Profilgrenze

`KeyframeEffect.iterationComposite` ist eine Level-2-Erweiterung. Das hier erfasste Chromium bietet die Eigenschaft nicht an: die Konstruktoroption wird ignoriert, ein Setter erzeugt nur eine eigene Eigenschaft. Die Engine implementiert die beschriebene Iterationsakkumulation. Die drei entsprechenden Fixture-Fälle enthalten deshalb getrennte `nativeExpected`- und `engineExpected`-Werte und gelten **nicht** als visuelle Chromium-Gleichheitstests.

Die native Null-Dauer-Referenz enthält 24 Fälle mit `iterations:0/1/2/Infinity`, `iterationStart:0/.3` und Zeitpunkten vor/auf/nach dem Ende. Bei Null-Dauer mit unendlichen Iterationen ist `currentIteration` nach dem Ende tatsächlich `Infinity`, die aktive Dauer aber `0`. Die Engine erhält diese Zeitangaben. Ein nichtendlicher Wiederholungszähler darf keinen unendlichen Host-Loop oder nichtendliche Transformwerte erzeugen; für die Level-2-Akkumulation verwendet das begrenzte Profil in diesem Sonderfall den aktuellen Ersatzwert.

Ein verbundener Shadow-Target darf animiert werden und Styles committen. Die Animation-Enumeration folgt jedoch dem DOM-Baum ihres Tree-Scope: `document.getAnimations()` und `host.getAnimations({subtree:true})` überschreiten die Shadow-Grenze nicht. Das ist getrennt von der Shadow-inklusive Verbundenheitsprüfung beim Rendern/Commit.

## Vergleich und Prüfung

`tests/fixtures/animation-layout-reference.html` enthält die ausführbaren Quellen für 24 deterministisch pausierte Fälle. `animation-layout-native.json` enthält die tatsächliche Browserausgabe. `javascript-animation-layout.json` übernimmt die 21 gemeinsamen Ergebnisse und kennzeichnet die drei Level-2-Abweichungen ausdrücklich. `animation-zero-duration-reference.html` und `animation-zero-duration-native.json` halten die zusätzliche Timing-Referenz fest.

`animation-context-reference.html`/`animation-context-native.json` ergänzen drei native Fälle: Opacity aus Variablen bleibt bis zur Composition ungeklammert; Prozentgrößen mit `min()`/`max()` erhalten ihre Ausdrücke über Commit/Cancel und eine spätere Änderung der Containerbreite. Die gemeinsame Gruppe enthält damit 24 Browserreferenzen und drei explizite Level-2-Erweiterungen.

`JavaScriptAnimationLayout` verbindet Runtime, CSSOM, echten RenderTree, DirtyLayout und Animation-Adapter. Der Test prüft CSSOM-Geometrie sowie die gemalten nativen GUI-Maße/Positionen, live geänderte Autorwerte, Cancellation, Commit, wichtige Deklarationen, Prozent-/Pixel-Mischungen, Transform-Reihenfolge, Shadow-Targets und das Entfernen von Frame-/Task-Anforderungen beim Zerstören. Er führt keine FPS-Messungen durch.

Folge-Layouts restaurieren den zuletzt veröffentlichten lokalen Script-Animationszeitpunkt. Sie lesen die Uhr nicht erneut, um ein neues Sample zu erzeugen. Der nächste Frame sowie explizite Timing-/API-Änderungen veröffentlichen neue Samples; direkte `commitStyles()`-Abfragen lesen weiterhin den aktuellen Zustand. CSS-Effekte verwenden dieselbe Trennung zwischen Frame-Abtastung und Layout-Repaint. `JavaScriptWebAnimations` prüft den Script-Fall mit einer zwischen Layoutveröffentlichungen veränderten Uhr. `HTMLPageAnimationScheduling` verbindet den tatsächlichen Page-Worker mit RenderTree, BlockLayout und CSS-Runtime: eine während der Ausführung voranschreitende Uhr und unendliche Größen-Keyframes müssen innerhalb eines Frames zur Ruhe kommen, ohne Boxen zu ersetzen oder nach Cancellation eine Frame-Verbindung zu behalten.
