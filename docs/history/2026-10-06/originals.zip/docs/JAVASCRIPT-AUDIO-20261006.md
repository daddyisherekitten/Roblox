# JavaScript-Audio · 6. Oktober 2026

Gewöhnliches HTML-JavaScript kann nun den vorhandenen Roblox-Soundhost steuern.
`Audio()` und `new Audio(src)` erzeugen echte `HTMLAudioElement`-DOM-Knoten.
Dasselbe Modell gilt für vorhandene `<audio>`-Elemente, entfernte Elemente und
die sichtbare Roblox-Steuerleiste. Es benötigt keine JavaScript-Erweiterung.

## Verwendung

```html
<button id="play">Ton abspielen</button>
<button id="stop">Pause</button>
<script>
const tone = new Audio("media/tone.ogg");
tone.volume = 0.4;
document.getElementById("play").addEventListener("click", async () => {
  try {
    await tone.play();
  } catch (error) {
    console.error(error.name, error.message);
  }
});
document.getElementById("stop").addEventListener("click", () => tone.pause());
// tone.currentTime = 0; setzt einen geladenen Ton an seinen Anfang.
</script>
```

Der Browser lädt die Datei unter diesem Pfad. Roblox braucht beim Mount dieselbe
Pfadzuordnung wie statisches Audio:

```lua
local page = Engine.mountHTML(target, HTML, {
    Audio = { ["media/tone.ogg"] = "rbxassetid://DEINE_SOUND_ID" },
})
```

`DEINE_SOUND_ID` ist durch die ID eines für diese Experience freigegebenen
Sound-Assets zu ersetzen. Die Zuordnung wird beim Mount kopiert. Sie ist kein
HTTP-Decoder; Audio-Data-URLs, Blob-URLs und beliebige Webdateien werden nicht
automatisch in Roblox-Sounds umgewandelt.

## Implementierter Umfang

| Oberfläche | Verhalten |
| --- | --- |
| Konstruktion/Identität | `Audio()`, `new Audio()`, `new Audio(src)`, `HTMLAudioElement` und `HTMLMediaElement`-Prototypen; Audio setzt `preload="auto"`. |
| Methoden | `play()` mit Promise, `pause()`, `load()`, `fastSeek(time)`, `canPlayType(type)`. Wiederholtes `play()` startet einen laufenden Sound nicht neu. |
| Eigenschaften | `src`, `currentSrc`, `preload`, `crossOrigin`, `autoplay`, `loop`, `controls`, `defaultMuted`, `muted`, `volume`, `currentTime`, `duration`, `playbackRate`, `defaultPlaybackRate`, `paused`, `ended`, `seeking`, `readyState`, `networkState`, `error`. |
| Fehler/Bereiche | `MediaError` mit Code/Message und Konstanten, `TimeRanges` mit `length/start/end`; statische Kopien von `buffered`, `seekable`, `played`. |
| Ereignisse | `loadstart`, `abort`, `emptied`, `suspend`, `durationchange`, `loadedmetadata`, `loadeddata`, `canplay`, `canplaythrough`, `play`, `waiting`, `playing`, `pause`, `timeupdate`, `seeking`, `seeked`, `volumechange`, `ratechange`, `error`, `ended`; auch über `on…`-Handler. |
| Ressourcen | Eine Sound-Instanz je gebundenem Audioelement, einschließlich dynamischer Controls; Quellenwechsel und veraltete Ladeantworten werden generationengeprüft. Ein Seitenwechsel zerstört Sounds und Verbindungen. |

`play()` wird nach `playing` erfüllt. Microtasks aus einem `playing`-Handler
laufen vor der entsprechenden Promise-Reaktion. `pause()` und `load()` brechen
betroffene offene Play-Promises mit `AbortError` ab. Ein fehlendes Asset ergibt
`NotSupportedError` und einen tatsächlichen Fehlerzustand. Ohne ausgewählte
Quelle darf ein Play-Promise zunächst offen bleiben. Ein Quellenwechsel meldet
keinen Erfolg der alten Quelle.

Direktes `src` hat Vorrang; ohne `src` wird die erste typkompatible, zugeordnete
`source` gewählt. Veränderungen des direkten `src` laden neu. Nach Änderungen
eines vorhandenen `source.src` oder `source.type` ist `audio.load()` erforderlich.
`preload="none"` wählt die Quelle, bereitet sie aber erst bei Play oder Autoplay
vor. Verbundene, ladende Audioelemente halten die Dokument-Loadbarriere; ein
entferntes Element blockiert sie nicht weiter, kann aber weiterspielen.

Lautstärke, Mute, Zeitposition, Rate und Wiedergabe erzeugen keine DOM- oder
Layoutinvalidierung. Die Steuerleiste teilt den nativen Zustand. `controls`
verändert hingegen die Darstellung: Audio ohne Controls berechnet sich selbst
bei entgegenstehendem Autoren-CSS als `display:none`. Entfernen/erneutes
Einfügen oder Umschalten von Controls ersetzt den laufenden Sound nicht.
Native Audio-Zeitereignisse werden gemeinsam auf etwa vier pro Sekunde begrenzt;
die vorhandene Steuerleisten-/Caption-Aktualisierung bleibt separat begrenzt.

## Konkrete Grenzen

- Dieses Profil bindet **Audio** an JavaScript. Die komplette Video-JavaScript-
  Oberfläche, `textTracks/addTextTrack`, Fullscreen/Picture-in-Picture und die
  vollständige `HTMLMediaElement`-Familie bleiben offen.
- Wiedergaberaten sind auf `0.5` bis `2` beschränkt. Andere endliche Raten
  ergeben `NotSupportedError`; `volume` außerhalb `0` bis `1` ergibt
  `IndexSizeError`. Nicht endliche Zahlen ergeben `TypeError`.
- `canPlayType()` gibt `""` zurück, weil Assetzuordnungen keine Browsercodec-
  Fähigkeit nachweisen. `crossOrigin` wird reflektiert, führt aber keine
  Browser-CORS-/Credentials-Anfrage aus. Browser-Autoplay-Sperren sind kein
  identischer Roblox-Hostmechanismus.
- `metadata` und `auto` bereiten dasselbe vollständige Roblox-Asset vor.
  `buffered/seekable` bilden danach die gesamte Dauer ab; sie sind keine echten
  Streaming- oder Netzstatistiken. Vollständiger Source-Fallback nach einem
  nativen Ladefehler sowie alle Netzwerk-/Decode-Unterfälle bleiben offen.
- Web Audio (`AudioContext`, Oszillatoren, Filter, Mixer), MediaSource, DRM,
  Aufnahme und Streaming sind separate Ausbaugebiete.

## Prüfung und Referenzen

`tests/JavaScriptAudio.luau` prüft die gemeinsame VM, DOM-Identität, Web-IDL-
Fehler, Aufgaben-/Microtask-Reihenfolge, Pause/Play-Rennen, Quellenwechsel,
Ladebarriere, Preload, Zeitbereiche und Abbau. `tests/AudioHost.luau` verbindet
den tatsächlichen AudioHost mit MediaRuntime sowie HTMLScripts/RenderTree und
prüft Sound-Wiederverwendung, native Controls, Seek, Ende, Fehler und dynamische
Darstellung mit kontrollierten nativen Diensten. Das ist kein hörbarer
Studio-Test oder FPS-Benchmark.

`tests/fixtures/audio-browser-reference.html` erzeugt eine stumme PCM-Datei und
prüft Standardverhalten im echten Browser. Das Ergebnis ist unter
`tests/fixtures/audio-browser-reference.json` festgehalten: Standardwerte,
unsichtbares Audio, Volume-Fehler, früher Pause-Abbruch, Ereignis-/Promise-
Reihenfolge, Seek/Fortsetzen, Ende, Mute und leeres `src` wurden verglichen.
Die vollständigen Engine-Regressionen, Projektprüfung und Rojo-Build sind in
`build/audio-full-tests.log`, `build/audio-final-focused.log`,
`build/audio-project-audit.log` und `build/audio-rojo-build.log` dokumentiert.

Standardgrundlage: [WHATWG-Medien](https://html.spec.whatwg.org/multipage/media.html)
und [WHATWG-Rendering](https://html.spec.whatwg.org/multipage/rendering.html).
Die native Wiedergabe verwendet die kursorerhaltende `Sound.Playing`-
Eigenschaft; siehe [Roblox Sound](https://create.roblox.com/docs/reference/engine/classes/Sound).
