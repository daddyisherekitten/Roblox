# R02: Dokumente, DOM-Interfaces und dynamische Tabellen

Die API verwendet dieselben Datenknoten, Wrapper, Mutationspfade und Renderer-Reconciliation wie die vorhandene Engine. Übernahme in ein anderes Dokument erhält die Identität des author-seitig vorhandenen Wrappers, eigene Eigenschaften, Listener und den aktuellen Zustand von Eingabefeldern. Es wird kein zweites DOM für diese APIs aufgebaut.

## Implementiert

- `DOMImplementation`, `DocumentType`, `XMLDocument`, `Attr`, `CDATASection`, `ProcessingInstruction`, `NamedNodeMap` und die üblichen `NodeList`-/`HTMLCollection`-Prototypen.
- `createHTMLDocument`, `createDocument`, `createDocumentType`, `createElementNS`, `createAttribute[NS]`, `createCDATASection`, `createProcessingInstruction`, `importNode` und `adoptNode`.
- Dokument- und Elementmetadaten, `documentElement`, tatsächliche `head`-/`body`-Knoten, `title`, `doctype`, `compatMode`, UTF-8-Zeichensatz und Content-Type. Detached-Dokumente haben kein Window und keine aktive Navigation.
- Gemeinsame HTML-Attributreflexion einschließlich URLs, `lang`, `dir`, `translate`, `contentEditable`, `inputMode`, `enterKeyHint`, booleschen und enumerierten Attributen. Gemeinsame Interfaces wie `HTMLQuoteElement` erlauben alle zugehörigen Tags.
- Lebende, stabile Attr-Knoten und namespacebezogene Attributoperationen. HTML-Namen sind ASCII case-insensitive; XML-Namen und Namespace-Metadaten bleiben erhalten.
- `DOMParser` für HTML und XML-MIME-Typen. Die geparsten Dokumente übernehmen die URL des relevanten Dokuments und haben keinen Browsing Context; HTML-Skripte bleiben inert. XML verwendet den vorhandenen strikten UTF-8-/XML-Scanner, Namespace-Scope, QName-Prüfung, CDATA, PI, Kommentare und `parsererror` bei Fehlern.
- HTML-Doctype-Knoten und die gebräuchlichen Quirks-/Limited-Quirks-Klassifizierungen, einschließlich HTML 4.01 mit/ohne System-ID.
- Lebende Collections mit numerischen enumerierbaren und benannten nicht enumerierbaren Properties in Dokumentreihenfolge.
- Dynamische Tabellen/Abschnitte/Zeilen/Zellen, Span-Reflexion und aktuelle Eingabewerte während Einfügen/Entfernen. Tabellen verwenden weiterhin die zentrale Parser-Normalisierung und den Tabellen-Renderer.
- `moveBefore` über den gemeinsamen Mutationspfad; erhaltene Moves beeinflussen Listener, native Eingaben und Custom-Element-Lebenszyklen über explizite Move-Metadaten.

## Nachweise

`node scripts/run-html-tests.cjs JavaScriptDocuments JavaScriptDOMExpansion JavaScriptDOMQueries JavaScriptRuntimeStorage JavaScriptRealmLifetime`

Die Dokumentgruppe prüft echte Runtime-Bridges, Fremd-Dokumentübernahme mit erhaltenem Wrapper/Eingabewert, XML-/HTML-Parser, Attr-Identität, Descriptor-Receiver, gemeinsame HTML-Interfaces, Collections, Tabellenkombinationen und Moves. Die bestehende Query-Gruppe vergleicht ihre Ergebnisse mit einem aufgezeichneten nativen Chromium-Durchlauf. Realm-Lifetime prüft, dass entsorgte Seiten nicht durch globale Wrapper-Registry-Zyklen festgehalten werden.

Bei `option` erhält `adoptNode` den aktuellen ausgewählten Zustand und dessen Dirty-Flag. `cloneNode` initialisiert den Zustand dagegen aus den kopierten `selected`-Attributen; bei einem einfachen `select` gewinnt das letzte ausgewählte Option-Element. Dieser Unterschied ist in `tests/fixtures/javascript-option-clone-browser.json` unmittelbar nach dem Klonen mit Chromium 154 aufgezeichnet und wird zusätzlich von der vorhandenen DOM-Control-Gruppe geprüft.

## Bewusste Grenzen

Dies ist kein vollständiger WHATWG-HTML-Tree-Builder oder vollständiger XML-Prozessor. XML-DTD-/Entity-Deklarationen, externe DTDs/Entitäten und ein vollständiger XML-Serializer sind nicht implementiert. Solche XML-Eingaben liefern `parsererror`. Der HTML-Tokenizer behandelt komplexe Doctype-Zeichenfolgen noch nicht mit sämtlichen standardisierten Tokenizer-Zuständen; vollständige Parser-Kompatibilität bleibt ein gesonderter Ausbaupunkt. Quirks-Metadaten allein implementieren nicht sämtliche historische Browser-Layout-Quirks.

HTML-Interfaces reflektieren die tatsächlich implementierten DOM-/Host-Operationen. Netz-, Medien- oder Font-Ladezustände werden dadurch nicht künstlich als verfügbar ausgewiesen. Die Detailalgorithmen aller Legacy-HTML-Interfaces und vollständige WebIDL-Eigenschaftsüberschreibung sind weitere Konformitätsarbeit. Eine vollständige Iframe-Navigation mit Realm-Wechsel benötigt zusätzlich die Ereignis-/Ressourcenmigration des Runtime-Hosts.

Die auf Navigation basierende URL-Reflexion ist kein vollständiger Ersatz für alle Browser-URL-Algorithmen. Insbesondere die vollständigen Frozen-Base-URL-Regeln in Detached-Dokumenten sowie XML-Base-/exotische URL-Fälle benötigen weitere Konformitätsarbeit.

Referenzen: [DOM Standard](https://dom.spec.whatwg.org/), [HTML DOM-Interfaces](https://html.spec.whatwg.org/multipage/common-dom-interfaces.html), [HTML Initial Insertion Mode](https://html.spec.whatwg.org/multipage/parsing.html#the-initial-insertion-mode).
