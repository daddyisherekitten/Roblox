# Schnellerer Seitenaufbau

## 5. Oktober 2026: längeres Laden mit kleineren Arbeitsabschnitten

Der erste Aufbau einer Seite erhält standardmäßig **höchstens 2 ms als Ziel
pro kooperativem Arbeitsabschnitt**. `WorkContext` teilt den nativen
Heartbeat-Rahmen zwischen gleichzeitig ladenden Dokumenten, Layoutjobs und
SVG-Jobs. Ein neuer Job setzt die verbleibende Frist eines anderen Jobs nicht
zurück. Die nächste Fortsetzung wartet auf einen weiteren Frame. Es ist ein
Ziel zwischen Checkpoints, kein harter Grenzwert für einen einzelnen Aufruf.

Die Pausen umfassen HTML-/CSS-Parsing, Dokumentmetadaten, CSS-Matching,
Renderbaum und GUI-Erzeugung, JavaScript-Parsing, Bibliotheksinstallation und
Skriptausführung, initiales Layout sowie SVG-Klonen, Szenenaufbau,
Pfadgeometrie, Hitboxen, Raster und Cache-Kopien. CSS-Verläufe, Masken,
Rahmen, Perspektive und Schatten pausieren ebenfalls beim Pixelaufbau.
Texturen werden im Ladescope mit höchstens 64 KiB je Upload-Streifen
übertragen; der letzte Streifen enthält exakt seine verbleibenden Zeilen.
Die vollständige SVG-Textur wird erst danach als fertig gemeldet. Pixel,
Auflösung, Antialiasing, DOM-Reihenfolge und Layoutregeln bleiben erhalten.

Der erste `Engine.mountHTML()`-Aufruf lädt die statischen Abhängigkeiten von
HTMLPage in Abhängigkeitsreihenfolge mit einem Checkpoint pro Modul. Die Liste
`Rendering/LoadingModules` wird mit `node scripts/export-loading-modules.cjs`
erzeugt und von der Projektprüfung auf Aktualität geprüft. Weitere Mounts
überspringen diese Liste. Moduldefinitionen erzeugen keine Seiten oder
Eingabeverbindungen.

Die neue Seite bleibt bis zum ersten stabilen Layout, den sichtbaren SVGs und
den ausstehenden DOM-Änderungen hinter ihrer weißen Ladefläche. Beim Laden
entsteht diese Fläche bereits vor dem HTML-Parsing. Resize und spätere
DOM-Änderungen schalten die Ladefläche nicht wieder ein. SVG-Vorbereitung von
Hoverzuständen darf nach dem Einblenden weiterlaufen; auch ihr Szenenaufbau
bleibt dabei kooperativ. Bereits gestartete private Arbeiten behalten ihre
Pausen bis zum Ende, selbst wenn die Präsentation ihre Lade-Lease beendet.
Texturänderungen an bereits sichtbaren SVGs werden vollständig in einem
Upload veröffentlicht; Hintergrundvorbereitung zeigt keine halben Bildstände.

Ladescopes gehören zum jeweiligen Coroutine-Aufruf. Direkte Parseraufrufe
bleiben synchron; nach dem Einblenden wird für normale JS-/GUI-Arbeit kein
Ladescope geöffnet. Async-/Generator-Stacks leiten CPU-Pausen über ihren
Host-Aufruf weiter, sodass daraus kein falsches `await` oder `yield` entsteht.
Ein Abbruch während der Realm-Konstruktion lässt die private Konstruktion
weiter in Abschnitten bis zum vollständigen Destruktor laufen und entsorgt
den unveröffentlichten Realm sofort. GUI-/Texturressourcen werden beim Abbruch
freigegeben. Aufbaufehler werden von echten Abbrüchen getrennt und gemeldet.
Die zusätzliche Heartbeat-Verbindung wird entfernt, sobald die letzte
Lade-Lease und ihre bereits laufenden Arbeiten beendet sind.

`RenderWorkBudgetMS` begrenzt wie bisher reguläres Layout. Beim ersten Laden
verwendet die Engine `min(2, RenderWorkBudgetMS)`; `0` deaktiviert diese
kooperativen Ladepausen ebenfalls. Die längere Ladezeit ist hier ausdrücklich
beabsichtigt. Es gibt keine zeitgesteuerte Resize-Neuberechnung als Nebenwirkung.

`page.LoadStats` hält die bisherigen Runs, Pausen, Wartezeit und längsten
gemessenen Abschnitt. Diese Werte schließen nur die expliziten kooperativen
Pausen aus: native Asset-/Textdienst-Wartezeiten können in den übrigen Zeiten
enthalten sein. Sie sind **keine FPS- oder exakten CPU-Messwerte**. SVG-Statistiken
trennen zusätzlich `BuildMS`, `BuildActiveMS` und `BuildWaitMS`; Pixelrasterzeiten
behalten ihre Trennung von Arbeit und explizitem Warten.

Einzelne Roblox-Aufrufe wie Modulkompilierung, `Instance.new`, Textmessung,
`CreateEditableImage`, Bilddownloads und GPU-/GUI-Verarbeitung können in Luau
nicht beliebig unterteilt werden. Die Änderungen beseitigen große eigene
Arbeitsblöcke, garantieren aber keine absolute Ruckelfreiheit der nativen Engine.
Die tatsächlichen Framezeiten beim kalten Laden prüft der Nutzer in Studio.

`LoadingWork`, `LoadingTextures`, `EngineEntry` und `PageLoading` prüfen
deterministisch geteilte Fristen, Scope-/Listener-Lebensdauer, kalte Imports,
unsichtbaren Aufbau, Abbruch, bytegleiche Raster-/Uploaddaten,
Async-/Generator-Reihenfolge und fortlaufende SVG-Vorbereitung. Animationen
und inkrementelles Layout behalten ihre eigenen Regressionen. Es werden
keine nativen FPS-Benchmarks ausgeführt.

## Frühere Optimierungen

Stand: 10. September 2026. Drei Änderungen sind umgesetzt:

1. **Schriften früh anfordern.** `RenderTree` setzt den endgültigen FontFace bereits beim
   Erzeugen der Wort-Labels. `FontPreload` übergibt vor dem ersten Layout je ein bestehendes
   Label pro verwendeter Textschrift/Variante gemeinsam an `ContentProvider:PreloadAsync`.
   Unsichtbare Teilbäume und unbenutzte Katalogschriften werden nicht vorgeladen. Das Layout
   wartet nicht zusätzlich auf den gesamten Preload; seine Textmessungen behandeln Ladefehler
   weiterhin selbst. Vorladen ist best effort. Nach Seitenabbau werden keine neuen Aufträge
   gestartet und keine späten Diagnosen geschrieben. Bereits laufende Roblox-Downloads können
   nicht abgebrochen werden. Nur in Leerraum verwendete Varianten werden weiterhin bei ihrer
   individuellen Messung geladen.
2. **Font-Konfigurationen pro Seite wiederverwenden.** `FontProfiles.newResolver()` hält je
   Familie die verwendeten Kombinationen aus neun Roblox-Gewichten und normal/italic. RenderTree und WordLayout
   verwenden denselben Resolver. Die öffentliche `face()`-Funktion liefert weiterhin frische
   Font-Werte; andere Seiten teilen diesen Cache nicht. Es werden keine Textmaße zwischen
   Wörtern oder Seiten geteilt. Wort- und Leerzeichenmessschlüssel bleiben vollständig erhalten.
3. **CSS-Werte einmal parsen.** `InlineStyle.compile()` bereitet unveränderliche Deklarationen
   vor. `Stylesheet.collect()` ruft dies einmal pro Regeltext auf, auch bei Kommagruppen. Beim
   Selektormatching werden Referenzen auf vorbereitete Werte gesammelt. Normal/important,
   Spezifität, Quellreihenfolge und Inline-Vorrang bleiben erhalten. Veränderliche Werte wie
   Margin/LineHeight werden pro Element kopiert; Prozent-Zeilenhöhen erst nach Anwendung aller
   Deklarationen berechnet. Diagnosen entstehen weiterhin erst bei tatsächlicher Anwendung.

`Syntax.declarations()` liefert intern Text und Important-Markierung; `Stylesheet.match()`
liefert Normal-/Important-Gruppen statt zusammengeklebter CSS-Zeichenketten. Der DOM bleibt unverändert.

## Prüfung

`tests/LoadOptimizations.luau` prüft Parse-Anzahlen, unabhängige berechnete Styles, CSS-Vorrang,
Font-Konstruktoraufrufe, Seitentrennung, frühe Font-Zuweisung, Einzelmessungen und Preload-Abbruch/
Fehlerbehandlung. `tests/PageLifecycle.luau` prüft zusätzlich die Verbindung zum Mount-Ablauf.
Die gesamte CLI-Testsuite und Syntaxprüfung bestehen.

Ein lokaler Vergleich mit Luau-CLI `-O2`, 1.500 Absätzen, drei CSS-Regeln, zwei Warmläufen und
dem Median aus sieben Gruppen mit je vier Aufbauten ergab:

| CSS-/Baumaufbau pro Durchlauf | Vorher | Nachher |
| --- | ---: | ---: |
| Median auf diesem Rechner | 41,272 ms | 9,435 ms |

Der DOM wurde vorher geparst. GUI-Erzeugung war durch Tabellen ersetzt; Font-Downloads und
Roblox-Textmessung waren nicht enthalten. Dies misst vor allem die vermiedene CSS-Wiederholung,
keinen Gesamt-Ladezeitgewinn in Studio. Der Versuchsaufbau liegt unter `build/benchmark-css-tail.luau`;
die gebündelten Vorher-/Nachher-Stände unter `build/benchmark-css-before.luau` und `build/benchmark-css-after.luau`.
Native visuelle Prüfung und Zeitmessung mit kalten/warmen Roblox-Schriftdateien stehen noch aus.

Grundlage: [Roblox TextService](https://create.roblox.com/docs/reference/engine/classes/TextService)
und [ContentProvider](https://create.roblox.com/docs/reference/engine/classes/ContentProvider).
