# Audio, Video und WebVTT

`audio` und `video` verwenden denselben HTML-Quelltext im Browser und in Roblox.
Der Browser lädt die Pfade aus `src`, `source`, `poster` und `track` direkt. Die
Roblox-Seite ordnet diese Pfade beim Mount eigenen Assets beziehungsweise einem
WebVTT-String zu.

```lua
local page = Engine.mountHTML(target, HTML, {
    Audio = {
        ["media/tone.ogg"] = "9120386436",
        ["media/tone.mp3"] = "9120386436",
    },
    Videos = {
        ["media/clip.webm"] = "5608384572",
        ["media/clip.mp4"] = "5608384572",
    },
    Images = {
        ["media/poster.png"] = "94339162936897",
    },
    Tracks = {
        ["media/captions.vtt"] = [[WEBVTT

00:00.500 --> 00:02.500
First caption
]],
    },
})
```

IDs dürfen als positive Ganzzahl, Dezimalstring oder vollständige
`rbxassetid://`-Adresse angegeben werden. Die Engine kopiert jede Zuordnung beim
Mount. Spätere Änderungen an der übergebenen Tabelle verändern eine laufende
Seite daher nicht.

## Quellenwahl

Ein direktes `src` hat Vorrang. Ohne direktes `src` werden `source`-Kinder in
DOM-Reihenfolge geprüft. Quellen ohne Typ oder mit einem syntaktisch passenden
`audio/*` beziehungsweise `video/*` sind Kandidaten; die erste Kandidatin mit
einer Roblox-Zuordnung gewinnt. Die Browserdateien können unterschiedliche
Formate enthalten, obwohl mehrere Pfade in Roblox auf dasselbe freigegebene
Asset zeigen.

## Darstellung und Steuerung

- Audio verwendet ein `Sound`. Video verwendet `VideoPlayer`, `VideoDisplay`,
  `Wire` und `AudioDeviceOutput`; auf Roblox-Versionen ohne diese Pipeline fällt
  die Engine auf `VideoFrame` zurück.
- `controls`, `autoplay`, `loop`, `muted`, `width`, `height`, `preload` und
  Video-`poster` werden ausgewertet. `preload="none"` verschiebt das Laden eines
  `VideoPlayer` beziehungsweise eines JavaScript-Audios bis zum ersten Play; `metadata` und `auto` bereiten die
  Roblox-Ressource im Hintergrund vor.
- Die eigene Roblox-Leiste bietet Play/Pause, eine klick- und ziehbare
  Zeitachse, eine größere Zeitanzeige, Mute, einen klick- und ziehbaren
  Lautstärke-Slider, eine Geschwindigkeitswahl mit `0.5x`, `1x`, `1.5x` und
  `2x` sowie bei vorhandenen Textspuren CC. Mehrfaches CC schaltet in
  Dokumentreihenfolge durch alle Sprachen und anschließend aus. Videos bieten
  zusätzlich Vollbild; `controlslist="nofullscreen"` entfernt diese Aktion.
  Die Controls blenden auf schmalen Medien zuerst Vollbild, CC,
  Geschwindigkeitswahl und zuletzt den Lautstärkeregler aus. Beim
  `VideoFrame`-Fallback wird die nicht verfügbare Geschwindigkeitswahl
  ausgeblendet.
- Buttons und Regler besitzen Hover- und gedrückte Zustände. Medien mit
  `controls` sind per Tab erreichbar und erhalten einen sichtbaren Fokusrahmen.
  Leertaste oder Enter schaltet Play/Pause, Links/Rechts springt fünf Sekunden,
  Hoch/Runter ändert die Lautstärke um `0.1`, `M` schaltet Mute, `C` wechselt
  die Textspur und `F` schaltet Video-Vollbild. Escape beendet Vollbild.
- `page:PlayMedia(id)`, `page:PauseMedia(id)`,
  `page:SetMediaPlaybackRate(id, rate)`, `page:SetMediaVolume(id, volume)`,
  `page:SetMediaTextTrack(id, indexOrLabel)`,
  `page:EnterMediaFullscreen(id)`, `page:ExitMediaFullscreen()` und
  `page:GetMediaState(id)` sind für Elemente mit `id` verfügbar. Eine Textspur
  kann über ihren 1-basierten Index, `label`, `srclang` oder `src` gewählt und
  mit `nil`, `false`, `0` oder `"off"` ausgeschaltet werden. `rate` muss
  zwischen `0.5` und `2`, `volume` zwischen `0` und `1` liegen;
  `GetMediaState` liefert zusätzlich `TextTrack`, `Loading`, `Error` und
  `Fullscreen`.
- `loadstart`, `loadedmetadata`, `canplay`, `error`, `play`, `pause`, `ended`,
  `timeupdate`, `seeking`, `volumechange`, `ratechange`, `texttrackchange` und
  `fullscreenchange` laufen durch das vorhandene lokale Ereignissystem
  `page:On(...)`.
- `Sound` und der `VideoFrame`-Fallback werden einmal über
  `ContentProvider:PreloadAsync()` vorbereitet. `VideoPlayer` verwendet
  `LoadAsync()`. Die Engine startet keine getrennte Dauerschleife je Medium;
  eine gemeinsame, auf zehn Updates pro Sekunde begrenzte Heartbeat-Verbindung
  aktualisiert Zeit und Captions.

## JavaScript-Audio

Seit dem 6. Oktober 2026 steuert normales JavaScript auch `<audio>` und
`new Audio(src)`: `play()` liefert ein Promise; `pause()`, `load()`, Zeitposition,
Lautstärke, Mute, Loop und Rate sind mit demselben Sound wie die sichtbare
Steuerleiste verbunden. Audio ohne Controls bleibt unsichtbar und kann dennoch
spielen. Die Dateipfade benötigen in Roblox weiterhin `options.Audio`.
Wiedergabe- und Lautstärkeänderungen lösen keine Seitenlayouts aus.

```js
const tone = new Audio("media/tone.ogg");
tone.volume = 0.4;
playButton.addEventListener("click", () => {
    tone.play().catch(error => console.error(error.name, error.message));
});
pauseButton.addEventListener("click", () => tone.pause());
```

Das [JavaScript-Audioprofil](JAVASCRIPT-AUDIO-20261006.md) enthält die vollständige
implementierte API, Ereignisse, Beispiele, Prüfung und offene Grenzen.
JavaScript-Audio-Zeitereignisse sind auf etwa vier pro Sekunde begrenzt.
Die Video-JavaScript-API und Web Audio sind damit noch nicht vollständig
implementiert.

## WebVTT-Teilumfang

Unterstützt werden Textspuren an Audio und Video, eine `WEBVTT`-Kopfzeile,
optionale Cue-IDs, Zeitmarken in
`mm:ss.mmm` oder `hh:mm:ss.mmm`, mehrzeiliger Cue-Text und einfache Entfernung
von Markup. `&amp;`, `&lt;`, `&gt;` und `&nbsp;` werden decodiert. Die Standardspur
wird zunächst aktiviert; mehrere Spuren können nacheinander gewählt werden.

Noch nicht unterstützt sind Regionen, Positions-/Ausrichtungseinstellungen,
Cue-CSS, Voice-/Language-Spans, mehrere gleichzeitig aktive Spuren, dynamisch
hinzugefügte Track-Knoten, freie Raten außerhalb `0.5` bis `2`, echte
Puffer-/Netzstatistiken, Streaming, Picture-in-Picture, MediaSource und DRM.
`preload="metadata"` kann wegen der Roblox-APIs nicht getrennt von einem
vollständigen Asset-Load abgebildet werden. `controlslist` unterstützt derzeit
`nofullscreen`; Download und Remote Playback werden ohnehin nicht angeboten.
Roblox-Assets müssen für die Experience freigegeben sein; sonst bleibt die
Ressource trotz korrekter Zuordnung nicht abspielbar.

Die frühere sichtbare Medienseite wurde beim Neustart des Testkatalogs entfernt.
`tests/Media.luau` und `tests/MediaRuntime.luau` decken Auswahl, Darstellung und
Steuerung weiterhin ab. `tests/JavaScriptAudio.luau` und `tests/AudioHost.luau`
prüfen zusätzlich JavaScript und die gemeinsame native Audiosteuerung.
