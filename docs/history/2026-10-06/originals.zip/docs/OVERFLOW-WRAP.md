# overflow-wrap

Unterstützt sind `normal` (Standard) und das vererbte `break-word`, in separatem
CSS, style-Blöcken und Inline-Styles. Ein Wort, das auf die nächste Zeile passt,
bleibt ganz. Ein sonst überlaufendes Wort wird an Graphemgrenzen in passende
Textstücke zerlegt. Kein Bindestrich wird eingefügt. `white-space: nowrap` und
`pre` verhindern auch diese Notumbrüche. Bilder werden nicht geteilt.

```html
<p style="max-width:240px; overflow-wrap:break-word;">
  Lange URL: https://diesisteinesehrlangetestadresseohneleerzeichen.example
</p>
```

Die ursprünglichen Wortobjekte und ihr Text bleiben erhalten. Normale Wörter
verwenden ihre bisherigen Labels und Maße. Erst bei Bedarf misst OverflowWrap
vollständige Teilstrings und erzeugt zusätzliche Wortlabels; ohne letter-spacing
werden keine einzelnen Buchstabenlabels erzeugt. WordFlow ordnet diese Stücke
mit denselben Baselines, Abständen und Ausrichtungsregeln an. WordLayout zeichnet
Text, Hintergrund, Linien und Schatten auf den tatsächlich angeordneten Stücken.
Die zusätzliche Höhe verschiebt folgende Blöcke über den bestehenden Reflow.

Teilstringmaße werden pro Originalwort und Font/Größe/Spacing gespeichert,
begrenzt auf 256 Einträge. Bei Resize werden Fragmentlabels pro Zeilenstück
wiederverwendet und überzählige ausgeblendet. Sobald das Wort wieder ganz passt,
erscheint sein ursprüngliches Label. Bei aktivem letter-spacing werden die
gemessenen Graphemmaße weiterbenutzt; ändert sich ein Fragmenttext, wird dessen
Zeichenlabelgruppe ersetzt. Seitenlöschung während einer Messung bricht vor
dem Aufbau neuer Fragmentlabels ab.

Grenzen: kein `anywhere`, `word-break`, automatisches Hyphenieren oder vollständiger
Unicode-Zeilenumbruchalgorithmus. Die vorhandenen normalen Umbruchstellen bleiben
Leerraum und br; zusätzliche Browser-Trennstellen z.B. an URL-Satzzeichen können
abweichen. Einzelne Grapheme, die breiter als die gesamte Zeile sind, laufen
weiterhin über. Kontextabhängige Schriftformung über Inline-Stilgrenzen sowie
extreme negative Abstände bleiben Näherungen des bestehenden Renderers.
Kein neues intrinsisches Min-Content-Sizing und kein DOM-Mutationssystem.

Tests prüfen Vererbung, unveränderte normale Wörter, gemischte Inline-Stile,
Resize-Wiederverwendung, Folgeblöcke, White-Space-Modi, Ausrichtung, Einrückung,
kombinierende Zeichen/Emoji, Schatten, Linien, Transparenz und letter-spacing.
Die gemeinsame Demo enthält eine URL-Zeile. Native Sichtprüfung in Studio offen.

Grundlage: [CSS Text – overflow-wrap](https://www.w3.org/TR/css-text-3/#overflow-wrap-property).
