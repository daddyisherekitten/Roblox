# Textschatten

Erster Prototyp: `text-shadow` rendert scharfe Textkopien mit Versatz hinter dem jeweiligen Wort. Das gemeinsame Browser-/Studio-HTML enthält ein kompaktes Beispiel mit einfachem Schatten, zwei farbigen Schatten bei letter-spacing und einem Kind mit none.

```css
text-shadow: 2px 3px 0px rgba(0, 0, 0, 0.4);
text-shadow: -1px 1px #9ab8e6, 2px 3px rgba(0, 0, 0, 0.4);
text-shadow: none;
```

Unterstützt: bis zu 16 kommagetrennte Schatten, zwei signierte 0/px-Offsets, optionaler Blur-Wert ausschließlich 0/0px, Farbe vor oder nach der Längengruppe. Farben entsprechen box-shadow einschließlich currentcolor, transparent, Alpha-Hex und kommagetrenntem rgb/rgba. Ausgelassene Farbe verwendet currentcolor am gerenderten Text. Die Eigenschaft wird vererbt; ein Kind kann die Schatten mit none entfernen. CSS-Regeln, Inline-Styles und !important verwenden die bestehende Cascade.

CSS/BoxShadow.parse teilt die bereits vorhandene Längen-/Farb-/Kommalisten-Auswertung mit einem begrenzten Textmodus: höchstens drei Längen, kein inset, kein Spread, kein Blur größer null. Nicht unterstützte Deklarationen erzeugen eine Diagnose und überschreiben keine vorherige gültige Deklaration. Box-shadow behält seinen bisherigen Umfang.

Rendering/TextShadows erzeugt nur für sichtbare Schatten zusätzliche TextLabels. Normale Wörter bekommen dafür einen Frame mit separatem Vordergrundtext. Bei letter-spacing werden die vorhandenen Grapheme kopiert. Alle Kopien übernehmen die fertig gemessene Schrift, Größe, Position und Ausdehnung; keine eigenen Messungen, Preload-Ziele oder Layout-Einträge. Der erste CSS-Schatten liegt vor den folgenden, alle liegen hinter dem Text. Inline-Hintergründe bleiben am umgebenden Wort-Frame. Bestehende Textdekorationen bleiben sichtbar. Native GUI-Objekte werden beim Reflow wiederverwendet und beim Entfernen der Seite mit aufgeräumt. Keine Render-Schleife und keine Schatten ohne aktive Deklaration; vollständig transparente Schatten erzeugen keine Kopien.

Grenzen dieses Prototyps: kein weicher Blur, keine Schatten für Unter-/Über-/Durchstriche, Listenmarker oder Bild-alt. Die Zeichenkopien werden unabhängig zusammengesetzt; überlappende halbtransparente Zeichen können vom Browser abweichen. Die Stapelung erfolgt je Wort. Bei großem Versatz kann ein späteres Wort mit seinem Schatten früheren Text überdecken. Das ist noch keine gemeinsame Schattenebene für die gesamte Zeile. Schatten verändern weder Layout noch Scrollausdehnung; Eltern-Clipping gilt weiterhin. Bei N Schatten entstehen je Wort bzw. Graphem N zusätzliche Labels. Allgemeine DOM-/Style-Mutationen bleiben Teil des späteren Dirty-Systems.

Tests/TextShadows prüft CSS-Werte und Fehler, Cascade/Vererbung/none, Farbe/Alpha/Reihenfolge, Schriftgewicht/Kursiv, Grapheme, Wortgrenzen, Inline-Hintergründe, identische Textmessungsanzahl und Geometrie sowie Wiederverwendung beim Umbruch. Nativer Sichtvergleich in Roblox Studio steht aus.

Referenz: [CSS Text Decoration 3 – Text Shadows](https://www.w3.org/TR/css-text-decor-3/#text-shadow-property). Vollständiges CSS umfasst auch Schatten der Textdekorationen; dieser erste Prototyp beschränkt sich ausdrücklich auf Glyphenkopien.
