# Website-Seiten

Der aktive Website-Katalog enthält seit dem 6. Oktober 2026 drei Seiten von
**spielraum.** Die bisherigen Architektur-, Hover-, JavaScript-, Fernweh- und
Atelier-Seiten sind entfernt. Ihre Quellen liegen ausschließlich als nicht
ausgelieferte Regressionstestdaten in `tests/fixtures/retired-websites.json`.

| Browserdateien | Roblox-Modul | Inhalt |
| --- | --- | --- |
| `examples/websites/main` | `Main` | Spiele-Hauptseite mit Memory, Hangman, Einführung und Spielelinks |
| `examples/websites/memory` | `Memory` | Spielbares Memory mit 6/8/12 Paaren, Mischen, Zug-/Paarzähler, Uhr, Pause, Tastaturbedienung, Ergebnis und persönlichem Rekord |
| `examples/websites/hangman` | `Hangman` | Wortspiel mit vier Kategorien, 32 deutschen Wörtern, sechs Fehlversuchen, Tastatur/Alphabetbuttons, einem Tipp pro Wort und persönlicher Statistik |

## Im Browser

```powershell
python scripts/serve-websites.py
```

`http://localhost:8000/` leitet zur Hauptseite weiter. Direkte Adressen:

- `http://localhost:8000/main/index.html`
- `http://localhost:8000/memory/index.html`
- `http://localhost:8000/hangman/index.html`

Alle Seiten verwenden normale HTML-Dokumente, CSS, lokale SVGs und eine
externe JavaScriptdatei mit `<script src="app.js" defer></script>`. Sie benötigen
keine Bibliotheken oder externen Schrift-/Bilddienste. Links sind gewöhnliche
relative HTML-Adressen; die Seiten funktionieren auch im normalen Browser.

## Eigene HTML-, CSS- und JavaScript-Module

Jede Seite besitzt folgende generierte Module unter `src/HTMLEngine/Websites`:

| ModuleScript | Inhalt |
| --- | --- |
| `HTML` | Unveränderter Quelltext aus `index.html` |
| `CSS` | Unveränderter Quelltext aus `styles.css` |
| `JavaScript` | Unveränderter JavaScript-Quelltext aus `app.js`, als String |
| Seitenmodul (`init.luau`) | Name, URL, ScriptPath und Ressourcenoptionen |

Das `JavaScript`-ModuleScript ist kein Roblox-LocalScript und enthält keine
Übersetzung des Spiels nach Luau. Der Website-Katalog registriert seinen String
unter der absoluten `app.js`-Adresse. Der bestehende HTML-Skriptloader führt
denselben JavaScriptcode in der Engine-Laufzeit aus. Die Optionen werden dabei
kopiert; vorhandene ScriptSources bleiben erhalten.

Bearbeitet werden die Browserdateien. Anschließend synchronisieren:

```powershell
python scripts/sync-website.py main Main "Spielraum"
python scripts/sync-website.py memory Memory "Memory — Spielraum"
python scripts/sync-website.py hangman Hangman "Hangman — Spielraum"
```

`LocalScripts: ["app.js"]` in `options.json` erzeugt das separate JavaScript-
Kindmodul und `ScriptPath = "app.js"`. Bei mehreren lokalen Skripten bleibt
deren bisherige Zuordnung über `JavaScriptServices.ScriptSources` erhalten.
`LocalSVG` verpackt die lokalen Illustrationen für den Roblox-Ressourcenhost.

## In Roblox

`examples/StudioDemoConfig.luau` enthält ausschließlich `ActiveDemo = "HTMLPage"`.
Die Startseite wird nur mit `local WEBSITE = "Main"` in
`examples/HTMLPage.client.luau` gewählt. Für einen direkten Spielstart dort
`"Memory"` oder `"Hangman"` eintragen. Nach Änderungen **Stop → Play** ausführen.
Hauptseite und Spiele navigieren über den bestehenden Website-Katalog.

Das erste Laden bleibt bis zum stabilen Layout und den sichtbaren SVG-Uploads
hinter der blanken Ladefläche. Späterer Resize blendet die Seite nicht erneut
aus. Details: [Laden und Arbeitsabschnitte](LOADING-PERFORMANCE.md).

## Memory: Verhalten und Speicherung

Die erste aufgedeckte Karte startet die Uhr. Erst die zweite Karte zählt als
Zug. Gefundene Paare bleiben offen. Bei einem Fehlpaar werden beide Karten
nach 850 ms verdeckt; währenddessen ist keine dritte Karte aufdeckbar.
Pause stoppt Uhr und Fehlpaar-Timer und verdeckt das Spielfeld. Fortsetzen
verwendet die verbleibende Wartezeit. Neustart verwirft alte Timer und erhält
bei gleicher Schwierigkeit die Kartenobjekte. Eine andere Schwierigkeit
erzeugt die benötigte Kartenanzahl. Im großen Spiel sind es ab 600 px sechs,
darunter vier Spalten. Alle Karten bleiben quadratisch.
Der volle Kartenbutton erhält seine Prozenthöhe aus der fertigen Bezugsbox.
Die Sterne der Rückseiten, der Mischpfeil und die Motive sind lokale SVG-Bilder;
sie benötigen keine Unicode-Abdeckung der Roblox-Schrift. Der Stern ist eine
Website-Ressource, keine besondere Zeichenbehandlung in der Engine. Beim
Aufdecken ändern sich Transparenz und Farben; das Rückseitensymbol löst keinen
zusätzlichen display-Wechsel aus und blockiert durch pointer-events:none
keine Kartenklicks.

Bestleistungen liegen unter `spielraum.memory.records.v1`, getrennt nach
Paaranzahl. Weniger Züge zählen zuerst, bei Gleichstand die kürzere Zeit.
Die Hauptseite zeigt den Rekord für acht Paare. Der Spielbereich kann den
Rekord der gewählten Schwierigkeit löschen. Ungültige oder nicht verfügbare
Speicherdaten verhindern das Spielen nicht. Im Browser ist dies normaler
Web Storage; Roblox verwendet die vorhandene Speicherbrücke, deren dauerhafte
Speicherung einen synchronisierten HTMLStorage-Server benötigt.

Tab/Enter/Leertaste bedienen die nativen Buttons; Escape pausiert bzw. setzt
fort. Hover- und Aufdeckübergänge verwenden CSS. `prefers-reduced-motion`
schaltet diese Übergänge ab. Symbole und Namen erklären die Motive gemeinsam.

## Prüfen

`node scripts/run-html-tests.cjs MemoryGame` führt den echten Spielcode in der
Engine aus: Schwierigkeiten, Fehlpaare, Pause/Fortsetzen, Neustart-Rennen,
Gewinn, Speicherung, Timerfreigabe, native Layouts und getrennte Scriptmodule.
`MemoryRendering` beginnt mit dem leeren Spielfeld, bevor das tatsächliche
defer-Skript die Karten erzeugt. Es prüft transparente Ebenen, Bildregistrierung,
Motivnamen, Cliprechtecke, Aufdecken, Fehlpaare und erneutes Aufdecken. Der
Renderer muss neue Transparenzebenen vor dem ersten Layout berücksichtigen;
sonst behalten sie ihre native Standardgröße und schneiden Karteninhalte ab.
`HangmanGame` prüft Gewinn/Verlust, wiederholte Eingaben, Umlaute, Kategorien,
Tipp, Statistik und responsive Spielfeldgrößen mit dem tatsächlichen Spielcode.
Der vollständige Runner erhält die bisherigen Engine-Regressionen über die
nicht veröffentlichten Fixtures. `python scripts/test-sync-website.py` prüft
die Quellübernahme; `node scripts/check-project.cjs` und Rojo prüfen das Projekt.
Automatische Browserprüfungen ergänzen das funktionale Engineprofil. Die native
Studio-Darstellung und FPS prüft Tobias; eine vollständige Browserkonformität
wird dadurch nicht behauptet.

## Hangman: Verhalten und Speicherung

Vier Kategorien enthalten insgesamt 32 deutsche Wörter. Bereits geratene
Buchstaben zählen nicht erneut; ein Treffer deckt alle passenden Stellen auf.
Ä, Ö und Ü besitzen eigene Alphabetbuttons. Nach sechs verschiedenen falschen
Buchstaben endet die Runde und das vollständige Wort erscheint. Pro Wort ist
ein Tipp erlaubt, der einen noch fehlenden Buchstaben ohne Fehlversuch aufdeckt.
Ein Kategorienwechsel und „Neues Wort“ setzen die laufende Runde zurück. Das
nächste Wort unterscheidet sich vom vorherigen.

Das Spiel verwendet keine Uhr und keine Animationsschleife. Alphabetbuttons
und Wortfelder werden wiederverwendet. Die Zeichnung besitzt sieben lokale
SVG-Ladezustände; ein Fehlversuch wechselt nur deren Quelle. Gesamtgewinne und
beste Serie werden unter `spielraum.hangman.records.v1` gespeichert. Ohne
verfügbaren Speicher bleibt das Spiel nutzbar. Die laufende Serie beginnt pro
Seitenbesuch neu.
