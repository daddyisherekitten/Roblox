"""S45 combination fixtures; identical SVG/scripts in Luau and native browser."""
from pathlib import Path
import base64, hashlib, json, sys, re, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent.parent
cases=[]
def text(label,x,y,size=18):
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="#172033" pointer-events="none">{label}</text>'
def add(name,caption,body,script=''):
    svg='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+body+('<script><![CDATA['+script+']]></script>' if script else '')+'</svg>\n'
    ET.fromstring(svg)
    cases.append(dict(Name=name,Caption=caption,SVG=svg))

petals=''.join(f'<use href="#petal" transform="rotate({a})"/>' for a in range(0,360,45))
add('S45-flower','Blume: acht aeussere und acht innere use-Blaetter, zwei Verlaeufe, Gruppen-Deckkraft. Ueber ein Blatt fahren: es wird rosa und der Cursor zum Fadenkreuz. Mitte bleibt gelb.',
    '<defs><linearGradient id="petalPaint" x2="0" y2="1"><stop stop-color="#dbeafe"/><stop offset="1" stop-color="#2563eb"/></linearGradient><radialGradient id="heartPaint"><stop stop-color="#fef08a"/><stop offset="1" stop-color="#f59e0b"/></radialGradient><path id="petal" d="M0 0C-72-42-52-125 0-122C52-125 72-42 0 0Z" fill="var(--petal-color, url(#petalPaint))" stroke="#4338ca" stroke-width="2"/></defs><style>use{cursor:crosshair}use:hover{--petal-color:#f472b6}</style><rect width="480" height="320" fill="#f5f5dc"/><g transform="translate(240 157)"><g opacity=".75">'+petals+'</g><g transform="rotate(22.5) scale(.57)">'+petals+'</g><circle r="29" fill="url(#heartPaint)" stroke="#b45309" stroke-width="2"/></g>'+text('SVG FLOWER',183,306,18))

add('S45-chart','Diagramm: Achsen, gestricheltes Raster, Verlauf unter der Kurve, Punktmarkierungen und echte Textkonturen. Die blaue Beschriftung folgt dem oberen Kurvenpfad; Beschriftungen bei allen drei Groessen vergleichen.',
    '<defs><linearGradient id="area" x2="0" y2="1"><stop stop-color="#60a5fa" stop-opacity=".8"/><stop offset="1" stop-color="#dbeafe" stop-opacity=".15"/></linearGradient><path id="labelPath" d="M70 85Q235 12 420 75"/></defs><rect x="16" y="12" width="448" height="296" rx="12" fill="white"/><text font-size="21" fill="#2563eb"><textPath href="#labelPath" startOffset="7%">SVG performance overview</textPath></text>'+
    ''.join(f'<path d="M65 {y}H440" fill="none" stroke="#cbd5e1" stroke-dasharray="3 5"/>'+text(str(v),28,y+5,14) for y,v in [(110,100),(160,75),(210,50),(260,25)])+
    '<path d="M65 235C120 220 130 160 180 178S275 220 310 145S395 105 435 110V270H65Z" fill="url(#area)"/><path d="M65 235C120 220 130 160 180 178S275 220 310 145S395 105 435 110" fill="none" stroke="#2563eb" stroke-width="3"/><path d="M65 90V270H445" fill="none" stroke="#334155" stroke-width="2"/>'+
    ''.join(f'<circle cx="{x}" cy="{y}" r="5" fill="white" stroke="#2563eb" stroke-width="2"/>'+text(label,x-8,293,15) for x,y,label in [(65,235,'A'),(180,178,'B'),(310,145,'C'),(435,110,'D')]))

add('S45-symbols','Symbolkarte: wiederverwendeter Stern mit Punktmuster und weicher Maske links; Pfeil mit Start-/Endmarkern rechts. Unten pruefen Kreis-Clip und multiply-Blend das Zusammensetzen.',
    '<defs><pattern id="dots" patternUnits="userSpaceOnUse" width="14" height="14"><rect width="14" height="14" fill="#dbeafe"/><circle cx="7" cy="7" r="3" fill="#2563eb"/></pattern><linearGradient id="fade"><stop stop-color="white"/><stop offset="1" stop-color="black"/></linearGradient><mask id="soft"><rect width="480" height="320" fill="url(#fade)"/></mask><path id="star" d="M0-58 17-18 58-18 27 9 37 52 0 29-37 52-27 9-58-18-17-18Z"/><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L10 5 0 10Z" fill="context-stroke"/></marker><clipPath id="round"><circle cx="120" cy="245" r="53"/></clipPath></defs>'+
    '<use href="#star" x="90" y="86" fill="url(#dots)" stroke="#2563eb" stroke-width="2"/><use href="#star" x="210" y="86" fill="#f59e0b" mask="url(#soft)"/><path d="M310 120C285 20 425 20 430 120" fill="none" stroke="#7c3aed" stroke-width="5" marker-start="url(#arrow)" marker-end="url(#arrow)"/>'+text('Pattern / Mask',45,169,16)+text('Markers',329,169,16)+
    '<g clip-path="url(#round)"><rect x="50" y="185" width="145" height="120" fill="url(#dots)"/><path d="M55 300L180 190" stroke="#ef4444" stroke-width="15"/></g><g style="isolation:isolate"><rect x="290" y="195" width="145" height="102" fill="white"/><circle cx="338" cy="243" r="38" fill="#60a5fa"/><circle cx="382" cy="243" r="38" fill="#f472b6" style="mix-blend-mode:multiply"/></g>')

add('S45-live','P startet die Bewegung, Z/X/C/V/B setzen feste Zeiten. Der Kreis wandert mit seinem Schatten. Farbe anklicken (oder Tab/Enter): beide Verlaufsformen wechseln gemeinsam Blau/Gruen. R setzt Zeit und Farbe zurueck.',
    '<defs><linearGradient id="paint"><stop id="tone" stop-color="#2563eb"/><stop offset="1" stop-color="#a5f3fc"/></linearGradient><filter id="shadow" x="-50%" y="-50%" width="200%" height="200%" color-interpolation-filters="sRGB"><feDropShadow dx="5" dy="7" stdDeviation="3" flood-color="#0f172a" flood-opacity=".5"/></filter></defs><path d="M70 100H410" stroke="#94a3b8" stroke-dasharray="4 5"/>'+''.join(f'<path d="M{x} 87v26" stroke="#94a3b8"/>' for x in [70,155,240,325,410])+
    '<circle id="traveler" cx="70" cy="100" r="28" fill="url(#paint)" filter="url(#shadow)"><animate attributeName="cx" from="70" to="410" dur="1s" fill="freeze"/></circle><rect x="55" y="180" width="370" height="45" rx="12" fill="url(#paint)"/><rect id="action" x="160" y="260" width="160" height="42" rx="8" fill="#cbd5e1" cursor="pointer" tabindex="0"/>'+text('Farbe',218,288,20),
    "let green=false;function toggle(){green=!green;document.getElementById('tone').setAttribute('stop-color',green?'#16a34a':'#2563eb');}const action=document.getElementById('action');action.addEventListener('click',toggle);action.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}});")

faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=w,Style=s) for face,w,s in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]
digest=hashlib.sha256((''.join(c['SVG'] for c in cases)+json.dumps(faces)).encode()).hexdigest()
luau='--!strict\n-- Generated by scripts/sync-svg-acceptance.py.\nreturn {Animate=true,Scripted=true,Stage="S45",Title="S45 · SVG-Gesamtabgleich",SourceSHA256="'+digest+'",Cases={\n'
browser=[]
outputs={}
for c in cases:
    luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+',SVG=[===['+c['SVG']+']===]},\n'
    scripts=re.findall(r'<script><!\[CDATA\[(.*?)\]\]></script>',c['SVG'],re.S)
    browser.append(dict(c,SVG=re.sub(r'<script>.*?</script>','',c['SVG'],flags=re.S),Scripts=scripts))
    outputs[ROOT/'examples/svg-tests'/(c['Name']+'.svg')]=c['SVG']
outputs[ROOT/'examples/SVGLab/AcceptanceSources.luau']=luau+'}}\n'
template=(ROOT/'scripts/svg-acceptance-template.html.in').read_text(encoding='utf-8')
outputs[ROOT/'examples/svg-tests/s45.html']=template.replace('@@TITLE@@','S45 · SVG-Gesamtabgleich').replace('@@CASES@@',json.dumps(browser,ensure_ascii=False).replace('<','\\u003c')).replace('@@FONTS@@',json.dumps(faces))
for path,content in outputs.items():
    if '--check' in sys.argv: assert path.read_text(encoding='utf-8')==content,f'Outdated: {path}'
    else:path.write_text(content,encoding='utf-8')
print('S45: four combined SVGs, shared scripts and animation-clock browser page synchronized/checked.')
