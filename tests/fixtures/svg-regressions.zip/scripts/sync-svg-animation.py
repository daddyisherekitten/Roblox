"""S39/S40 animation sources and independent native comparison frames."""
from pathlib import Path
import json,hashlib,base64,sys
ROOT=Path(__file__).resolve().parent.parent;folder=ROOT/'examples/svg-tests';cases=[]
def label(t,x,y):return f'<text x="{x}" y="{y}" font-size="17" fill="#172033" pointer-events="none">{t}</text>'
def add(name,caption,body):cases.append(dict(Name=name,Caption=caption,SVG='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+body+'</svg>\n'))
def anim(key,first,last,extra=''):return f'<animate attributeName="{key}" from="{first}" to="{last}" dur="1s" fill="freeze" {extra}/>'
guides=''.join(f'<path d="M{x} 45v245" stroke="#94a3b8" stroke-dasharray="3 5" pointer-events="none"/>'+label(str(t),x-9,25) for x,t in [(40,0),(115,.25),(190,.5),(265,.75),(340,1)])
add('S39-values','Z/X/C/V/B: feste Zeitpunkte 0/.25/.5/.75/1 s. Oben wandert ein Rechteck; Mitte aendern sich Radius und Farbe; unten wird die Flaeche transparenter. P startet/pausiert die Zeit.',guides+'<rect id="moving" x="40" y="55" width="60" height="45" fill="#2563eb">'+anim('x',40,340)+'</rect><circle id="growing" cx="240" cy="170" r="12" fill="#2563eb">'+anim('r',12,45)+anim('fill','#2563eb','#ef4444')+'</circle><rect x="80" y="255" width="320" height="35" fill="#16a34a">'+anim('opacity',1,.2)+'</rect>')
body=''
for i,(kind,first,last) in enumerate([('translate','0 0','80 0'),('rotate','0','180'),('scale','1','2'),('skewX','0','35')]):
 x=90+(i%2)*240;y=95+(i//2)*155
 body+=label(kind,x-55,y-55)+f'<g transform="translate({x} {y})"><path d="M-50 0H110M0-40V45" stroke="#94a3b8"/><g><path d="M-20-15H20V-25L45 0 20 25V15H-20Z" fill="#2563eb"/><animateTransform attributeName="transform" type="{kind}" from="{first}" to="{last}" dur="1s" fill="freeze"/></g></g>'
add('S39-transforms','Translation, Rotation, Skalierung und Scherung um die grauen Urspruenge. Alle vier starten bei 0 s und erreichen bei 1 s ihr Endbild. Zwischenwerte mit den Zeittasten vergleichen.',body)
body=''
for y,mode,extra in [(70,'linear',''),(165,'discrete',''),(260,'spline','keyTimes="0;.5;1" keySplines=".42 0 .58 1;.42 0 .58 1"')]:
 body+=label(mode,20,y-28)+f'<path d="M40 {y}H440" stroke="#94a3b8"/><circle cx="40" cy="{y}" r="15" fill="#2563eb"><animate attributeName="cx" values="40;240;440" calcMode="{mode}" {extra} dur="1s" fill="freeze"/></circle>'
add('S39-easing','Gleiche Werte, unterschiedliche Interpolation: linear, diskrete Spruenge und cubic-bezier ueber keySplines. Besonders 0.25 und 0.75 s vergleichen; diskret bleibt bis zum naechsten Wert stehen.',body)
body=''
for y,fill,acc in [(75,'remove','none'),(165,'freeze','none'),(255,'freeze','sum')]:
 body+=label(fill+' / accumulate '+acc,20,y-30)+f'<path d="M40 {y}H440" stroke="#94a3b8"/><circle cx="40" cy="{y}" r="14" fill="#16a34a"><animate attributeName="cx" from="40" to="140" dur=".4s" repeatCount="2.5" fill="{fill}" accumulate="{acc}"/></circle>'
body+='<rect x="420" y="20" width="30" height="25" fill="#f59e0b" visibility="hidden"><set attributeName="visibility" to="visible" begin=".5s" dur=".5s" fill="freeze"/></rect>'
add('S39-repeat','Dauer .4 s, 2.5 Durchlaeufe: Ende bei 1 s. Oben Rueckkehr zum Basiswert, Mitte friert den halben letzten Durchlauf ein, unten addieren sich die Endwerte. Gelbes Feld erscheint ab .5 s per set.',body)
track='M40 160 C140 20 340 300 440 160'
arrow='<path d="M-17-9L18 0-17 9-10 0Z" fill="#2563eb"/>'
add('S40-motion','Pfeil folgt der S-Kurve mit rotate=auto, per mpath referenziert. Der Knopf spiegelt den Pfad waehrend der Bewegung; Richtung und Position muessen sofort dem neuen Pfad folgen. Zum Bewegen P druecken.',f'<path id="track" d="{track}" fill="none" stroke="#94a3b8" stroke-width="2"/><g id="traveler">{arrow}<animateMotion dur="1s" fill="freeze" rotate="auto"><mpath xlink:href="#track"/></animateMotion></g><rect id="change" x="150" y="260" width="180" height="40" rx="8" fill="#cbd5e1" cursor="pointer"/>'+label('Pfad wechseln',185,286))
add('S40-keypoints','Oben konstantes Tempo. Unten keyPoints 0/.8/1 und keyTimes 0/.5/1 mit Splines: bei .5 s bereits 80 Prozent. Der untere Pfeil zeigt mit auto-reverse gegen die Bewegungsrichtung.', '<path d="M40 90H440M40 225H440" stroke="#94a3b8"/><g>'+arrow+'<animateMotion path="M40 90H440" dur="1s" fill="freeze" rotate="auto"/></g><g>'+arrow+'<animateMotion path="M40 225H440" keyPoints="0;.8;1" keyTimes="0;.5;1" calcMode="spline" keySplines=".42 0 .58 1;.42 0 .58 1" dur="1s" fill="freeze" rotate="auto-reverse"/></g>')
add('S40-events','P starten, dann Start klicken. Blau beginnt per go.click und laeuft .5 s; Gruen folgt .1 s nach flight.end. Erneuter Klick startet Blau neu. R setzt die Ereignisse zurueck.', '<path d="M40 90H420M40 180H420" stroke="#94a3b8"/><circle cx="40" cy="90" r="18" fill="#2563eb"><animate id="flight" attributeName="cx" from="40" to="420" begin="go.click" dur=".5s" fill="freeze"/></circle><circle cx="40" cy="180" r="18" fill="#16a34a"><animate attributeName="cx" from="40" to="420" begin="flight.end+.1s" dur=".4s" fill="freeze"/></circle><rect id="go" x="150" y="255" width="180" height="40" rx="8" fill="#cbd5e1" cursor="pointer"/>'+label('Start',222,282))
add('S40-css','Oben echte CSS-keyframes: Bewegung und Transparenz, durch dieselben Zeittasten steuerbar. Unten Hover-Transition der Deckkraft ueber .4 s; diese laeuft auch bei pausierter SVG-Zeit. Schnelles Rein/Raus prueft Unterbrechungen.', '<style>@keyframes slide {from {transform:translateX(0px);opacity:1}to {transform:translateX(300px);opacity:.35}} #css {animation-name:slide;animation-duration:1s;animation-timing-function:linear;animation-fill-mode:both} #fade {transition-property:opacity;transition-duration:.4s;transition-timing-function:ease;opacity:1} #fade:hover {opacity:.2}</style><circle id="css" cx="60" cy="90" r="25" fill="#2563eb"/><path d="M60 90H360" stroke="#94a3b8" pointer-events="none"/><rect id="fade" x="80" y="200" width="320" height="80" rx="15" fill="#16a34a" cursor="pointer"/>'+label('Hover',215,246))
faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=w,Style=s) for face,w,s in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]
template=(ROOT/'scripts/svg-animation-template.html.in').read_text(encoding='utf8')
outputs={folder/(c['Name']+'.svg'):c['SVG'] for c in cases}
for stage,title,subset,module,page in [('S39','S39 · SVG-Animationen',cases[:4],'TimingSources','s39.html'),('S40','S40 · Pfadbewegung und CSS',cases[4:],'MotionSources','s40.html'),('S39_S40','S39 + S40 · Animation und Bewegung',cases,'AnimationSources','s39-s40.html')]:
 digest=hashlib.sha256((''.join(c['SVG'] for c in subset)+json.dumps(faces)).encode()).hexdigest()
 luau='--!strict\n-- Generated by scripts/sync-svg-animation.py.\nreturn {Animate=true,Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",Cases={\n'
 for c in subset:luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+',SVG=[===['+c['SVG']+']===]},\n'
 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]=luau+'}}\n'
 outputs[folder/page]=template.replace('@@TITLE@@',title).replace('@@CASES@@',json.dumps(subset,ensure_ascii=False).replace('<','\\u003c')).replace('@@FONTS@@',json.dumps(faces))
for path,content in outputs.items():
 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'
 else:path.write_text(content,encoding='utf8')
print('S39/S40: eight animation boards and three comparison pages synchronized/checked.')
