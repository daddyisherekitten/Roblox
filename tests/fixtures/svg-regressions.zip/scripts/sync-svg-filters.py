"""Native SVG and Luau filter fixtures from identical source strings."""
from pathlib import Path
import hashlib,json,sys,base64
ROOT=Path(__file__).resolve().parent.parent
folder=ROOT/'examples/svg-tests'
specs=[]
def add(name,caption,body): specs.append((name,caption,body))
def label(text,x,y):return f'<text x="{x}" y="{y}" font-size="16" fill="#172033">{text}</text>'
def palette(x,y,w=420,h=38):
 colors=['#ff0000','#00ff00','#0000ff','#808080','#ffffff','#000000']
 return ''.join(f'<rect x="{x+i*w/6}" y="{y}" width="{w/6}" height="{h}" fill="{c}"/>' for i,c in enumerate(colors))
def filt(id,content,attrs=''):return f'<filter id="{id}" {attrs}>{content}</filter>'
def group(body,id):return f'<g filter="url(#{id})">{body}</g>'
identity='<feColorMatrix/>'
invert='<feComponentTransfer><feFuncR type="table" tableValues="1 0"/><feFuncG type="table" tableValues="1 0"/><feFuncB type="table" tableValues="1 0"/></feComponentTransfer>'
# 1: explicitly branch through named results; last primitive is graph output.
red='<feColorMatrix in="SourceAlpha" values="0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 .55 0" result="red"/>'
chain=red+'<feBlend in="SourceGraphic" in2="red" mode="screen"/>'
add('S29-graph','Oben Original, Mitte SourceAlpha rot mit 55 % Alpha, unten der benannte rote Zweig per in/in2 mit SourceGraphic kombiniert (screen).', '<defs>'+filt('red',red,'color-interpolation-filters="sRGB"')+filt('graph',chain,'color-interpolation-filters="sRGB"')+'</defs>'+label('SourceGraphic',30,25)+palette(30,35)+label('SourceAlpha → red',30,120)+group(palette(30,130),'red')+label('SourceGraphic + red → screen',30,215)+group(palette(30,225),'graph'))
# 2: identical stroked sources, object and user regions.
def block(x,y):return f'<rect x="{x}" y="{y}" width="160" height="75" fill="#2563eb" stroke="#f97316" stroke-width="24"/>'
add('S29-regions','Links oben volle Kontur, rechts oben eng auf die Fuellbox beschnitten. Unten links vergroesserte Filterregion; rechts primitiveUnits=objectBoundingBox mit nur linker Haelfte. Rote Linien zeigen die Fuellbox.', '<defs>'+filt('wide',identity,'x="-20%" y="-30%" width="140%" height="160%"')+filt('tight',identity,'x="0" y="0" width="1" height="1"')+filt('half','<feColorMatrix x="0" y="0" width=".5" height="1"/>','primitiveUnits="objectBoundingBox"')+'</defs>'+block(40,40)+group(block(280,40),'tight')+group(block(40,200),'wide')+group(block(280,200),'half')+''.join(f'<rect x="{x}" y="{y}" width="160" height="75" fill="none" stroke="#ef4444"/>' for x,y in [(40,40),(280,40),(40,200),(280,200)]))
# 3: gamma space causes intentionally different brightness.
def half(space):return filt(space,'<feComponentTransfer><feFuncR type="linear" slope=".5"/><feFuncG type="linear" slope=".5"/><feFuncB type="linear" slope=".5"/></feComponentTransfer>',f'color-interpolation-filters="{space}"')
add('S29-color-space','Oben Original. Mitte halbe RGB-Werte in sRGB (Weiss wird #808080). Unten dieselbe Rechnung in linearRGB (Weiss etwa #BCBCBC). Die untere Reihe muss heller sein.', '<defs>'+half('sRGB')+half('linearRGB')+'</defs>'+label('Original',30,25)+palette(30,35)+label('sRGB × 0.5',30,120)+group(palette(30,130),'sRGB')+label('linearRGB × 0.5',30,215)+group(palette(30,225),'linearRGB'))
# 4: direct shared filter, transform, text, opacity + clipping after filter.
# filter href is legacy and unsupported by the target browser.
add('S29-text-order','Oben gefilterte echte Textkonturen (invertiert, Buchstaben bleiben getrennt). Unten derselbe Filter direkt auf einer gedrehten Gruppe; Clip und 50 % Gruppen-Opacity wirken auf das fertige Filterergebnis.', '<defs>'+filt('base',invert,'color-interpolation-filters="sRGB"')+'<clipPath id="cut"><rect x="40" y="175" width="260" height="115"/></clipPath></defs><text x="30" y="115" font-size="100" font-weight="700" fill="#2563eb" filter="url(#base)">SVG</text><g transform="rotate(-8 240 230)"><g filter="url(#base)" clip-path="url(#cut)" opacity=".5"><rect x="40" y="180" width="340" height="70" fill="#ff0000"/><circle cx="340" cy="235" r="50" fill="#0000ff"/></g></g>')
# 5: all color matrix types except luminance on next board.
filters=filt('id',identity,'color-interpolation-filters="sRGB"')+filt('sat','<feColorMatrix type="saturate" values="0"/>','color-interpolation-filters="sRGB"')+filt('hue','<feColorMatrix type="hueRotate" values="90"/>','color-interpolation-filters="sRGB"')+filt('swap','<feColorMatrix values="0 0 1 0 0 1 0 0 0 0 0 1 0 0 0 0 0 0 1 0"/>','color-interpolation-filters="sRGB"')
add('S30-matrices','Von oben: identity, saturate(0), hueRotate(90), RGB-Kanäle vertauscht (B,R,G). Rot/Grün/Blau/Grau/Weiss/Schwarz in jeder Zeile.', '<defs>'+filters+'</defs>'+''.join(label(name,30,20+i*78)+group(palette(30,28+i*78,h=35),id) for i,(name,id) in enumerate([('identity','id'),('saturate 0','sat'),('hueRotate 90','hue'),('matrix: B,R,G','swap')])))
# 6: same input gradient, transfer types.
funcs=[('identity',''),('table','tableValues="0 0 1"'),('discrete','tableValues="0 .5 1"'),('linear','slope=".5" intercept=".25"'),('gamma','amplitude="1" exponent="2" offset="0"')]
defs='<linearGradient id="ramp"><stop stop-color="black"/><stop offset="1" stop-color="white"/></linearGradient>'
body=''
for i,(kind,attrs) in enumerate(funcs):
 defs+=filt(kind,'<feComponentTransfer>'+''.join(f'<feFunc{c} type="{kind}" {attrs}/>' for c in 'RGB')+'</feComponentTransfer>','color-interpolation-filters="sRGB"')
 body+=label(kind,20,22+i*62)+f'<rect x="125" y="{8+i*62}" width="330" height="42" fill="url(#ramp)" filter="url(#{kind})"/>'
add('S30-transfer','Schwarz-Weiss-Rampe: identity, interpolierte table, dreistufige discrete, linear, gamma. Die Stufen bei discrete sind beabsichtigt.', '<defs>'+defs+'</defs>'+body)
# 7: alpha including making transparent pixels visible.
add('S30-alpha','Oben luminanceToAlpha: schwarze Felder mit Alpha aus Rot/Grün/Blau/Grau/Weiss/Schwarz. Mitte Alpha-Rampe mit drei Stufen. Unten Alpha-Offset: auch zuvor transparente Umgebung wird innerhalb der Filterregion sichtbar.', '<defs>'+filt('lum','<feColorMatrix type="luminanceToAlpha"/>','color-interpolation-filters="sRGB"')+'<linearGradient id="alpha"><stop stop-color="#2563eb" stop-opacity="0"/><stop offset="1" stop-color="#2563eb"/></linearGradient>'+filt('steps','<feComponentTransfer><feFuncA type="discrete" tableValues="0 .5 1"/></feComponentTransfer>')+filt('offset','<feComponentTransfer><feFuncA type="linear" slope=".5" intercept=".25"/></feComponentTransfer>','filterUnits="userSpaceOnUse" x="30" y="215" width="420" height="80"')+'</defs>'+group(palette(30,25,h=55),'lum')+'<rect x="30" y="120" width="420" height="55" fill="url(#alpha)" filter="url(#steps)"/><circle cx="240" cy="255" r="30" fill="#2563eb" filter="url(#offset)"/>')
# 8: actual image filtering and graph precision.
add('S30-image','Dasselbe Rasterbild: links Original, rechts Kanalfilter. Oben RGB-Invertierung, unten gamma(2). Filter ändern nur Pixel, keine SVG-Geometrie.', '<defs>'+filt('inv',invert,'color-interpolation-filters="sRGB"')+filt('gamma','<feComponentTransfer>'+''.join(f'<feFunc{c} type="gamma" exponent="2"/>' for c in 'RGB')+'</feComponentTransfer>','color-interpolation-filters="sRGB"')+'</defs>'+''.join(f'<image href="S21-source.png" x="{x}" y="{y}" width="210" height="130" preserveAspectRatio="none"'+(f' filter="url(#{id})"' if id else '')+'/>' for x,y,id in [(20,15,None),(250,15,'inv'),(20,175,None),(250,175,'gamma')]))
faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=weight,Style=style) for face,weight,style in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]

png=(folder/'S21-source.png').read_bytes()
font=b''.join(base64.b64decode(face['Data']) for face in faces)

cases=[dict(Name=n,Caption=c,SVG='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+svg+'\n</svg>\n') for n,c,svg in specs]

outputs={folder/(c['Name']+'.svg'):c['SVG'] for c in cases}
# Keep the user-observed legacy incompatibility separate from the parity boards.
legacy=next(c['SVG'] for c in cases if c['Name']=='S29-text-order')
legacy=legacy.replace('<clipPath id="cut">','<filter id="linked" href="#base"/><clipPath id="cut">')
legacy=legacy.replace('<g filter="url(#base)"','<g filter="url(#linked)"')
outputs[folder/'S29-filter-href-known-difference.svg']=legacy

for stage,title,subset,module,page in [('S29','S29 · Filtergraph und Regionen',cases[:4],'FilterGraphSources','s29.html'),('S30','S30 · Farbmatrizen und Kanalfilter',cases[4:],'FilterColorSources','s30.html'),('S29_S30','S29 + S30 · SVG-Filter und Farben',cases,'FilterSources','s29-s30.html')]:

 digest=hashlib.sha256(''.join(c['SVG'] for c in subset).encode()+font+png).hexdigest()

 luau='--!strict\n-- Generated by scripts/sync-svg-filters.py.\nlocal imageSource=require(script.Parent.ImageClipSources)\nreturn {ResolveImage=imageSource.ResolveImage,Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",Cases={\n'

 for c in subset:luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+',SVG=[===['+c['SVG']+']===]},\n'

 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]=luau+'}}\n'

 html='''<!doctype html><html lang="de"><meta charset="utf-8"><title>TITLE</title>

<style>body{margin:24px;font:14px Arial,sans-serif;color:#172033;background:#eef2f7}h1{font-size:20px}a{color:#245fb2}.board{display:block;outline:1px solid #aab4c3;background:conic-gradient(#fff 25%,#ddd 0 50%,#fff 0 75%,#ddd 0);background-size:32px 32px;margin-top:16px}.caption{margin:10px 0 16px;max-width:900px}</style>

<h1>TITLE</h1><p>Gleiche Source-Sans-Pro-Datei in Browser und Roblox. Tasten 1 / 2 / 3: 240 / 480 / 960 px · R: 20 Neuaufbauten.</p><p><a href="s27-s28.html">S27 / S28 ansehen</a></p><div id="cases"></div>

<script>

const sources=CASES, font=FONT;const png=PNG;let width=480, urls=[];

function render(){const host=document.querySelector('#cases');host.replaceChildren();for(const url of urls)URL.revokeObjectURL(url);urls=[];for(const item of sources){const parsed=new DOMParser().parseFromString(item.SVG,'image/svg+xml');if(parsed.querySelector('parsererror'))throw Error(item.Name);for(const image of parsed.querySelectorAll('image')){if(image.getAttribute('href')==='S21-source.png')image.setAttribute('href',png)}const svg=parsed.documentElement;const style=parsed.createElementNS(svg.namespaceURI,'style');style.textContent=font.map(f=>'@font-face{font-family:"Source Sans Pro";src:url(data:font/ttf;base64,'+f.Data+') format("truetype");font-weight:'+f.Weight+';font-style:'+f.Style+'}').join('');svg.prepend(style);svg.setAttribute('width','100%');svg.setAttribute('height','100%');const board=document.createElement('div');board.className='board';board.style.width=width+'px';board.style.height=320*width/480+'px';const frame=document.createElement('iframe');frame.title=item.Name;frame.style.cssText='border:0;width:100%;height:100%;display:block';const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'}));urls.push(url);frame.src=url;board.append(frame);const caption=document.createElement('p');caption.className='caption';caption.textContent=item.Caption;frame.addEventListener('load',async()=>{try{const sets=await Promise.all(font.map(f=>frame.contentDocument.fonts.load(f.Style+' '+f.Weight+' 32px "Source Sans Pro"')));if(sets.some(s=>!s.length))throw Error('Font fehlt');frame.dataset.fontReady='true'}catch(error){caption.textContent+=' FONT-LADEFEHLER: '+error.message}});host.append(board,caption)}}

addEventListener('keydown',e=>{if(e.repeat)return;const size={'1':240,'2':480,'3':960}[e.key];if(size){width=size;render()}else if(e.key.toLowerCase()==='r'){for(let n=0;n<20;n++)render()}});render();

</script></html>

'''.replace('TITLE',title).replace('CASES',json.dumps(subset,ensure_ascii=False).replace('<','\\u003c')).replace('font=FONT;', 'font='+json.dumps(faces)+';').replace('const png=PNG;', 'const png='+json.dumps('data:image/png;base64,'+base64.b64encode(png).decode())+';')
 outputs[folder/page]=html

for path,content in outputs.items():

 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'

 else:path.write_text(content,encoding='utf8')

print('S29/S30: eight native SVG boards and three comparison pages synchronized/checked.')

