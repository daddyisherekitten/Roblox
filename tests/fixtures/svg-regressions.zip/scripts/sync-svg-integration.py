"""Shared HTML/SVG integration and deterministic 10/100/1000-shape fixtures."""
from pathlib import Path
import hashlib,json,sys,base64
ROOT=Path(__file__).resolve().parent.parent;out=ROOT/'examples/svg-tests'
ns='http://www.w3.org/2000/svg'
def svg(body,attrs='',vb='0 0 480 200'):return f'<svg xmlns="{ns}" viewBox="{vb}" width="480" height="200" {attrs}>{body}</svg>'
def panel(title,note,body):return '<section><h2>'+title+'</h2><p>'+note+'</p>'+body+'</section>'
motif='<style>.hot:hover{fill:#16a34a}</style><rect x="20" y="25" width="180" height="145" rx="15" fill="#2563eb" class="hot" cursor="crosshair"/><circle cx="330" cy="100" r="72" fill="#f59e0b" cursor="pointer"/>'
panels=[]
panels.append(panel('S43 · Inline und Block','SVG zwischen normalen Textelementen. Beim Umbruch bleibt der folgende Text im Fluss. Hover auf Blau: gruen und Fadenkreuz.','<p>Vorher '+svg(motif,'style="width:180px;height:75px;vertical-align:middle"')+' Nachher</p>'+svg(motif,'style="display:block;width:100%;height:auto"')+'<p>Diese Zeile bleibt unter dem SVG.</p>'))
panels.append(panel('S43 · Clipping und Ueberlagerung','Das SVG wird am Elternrahmen abgeschnitten. Die HTML-Flaeche liegt darueber; darunter darf der SVG-Cursor nicht durchscheinen. Den unteren Bereich horizontal und vertikal scrollen.','<div style="position:relative;width:100%;height:130px;overflow:hidden;background:#dbeafe">'+svg(motif,'style="display:block;width:600px;height:250px"')+'<div style="position:absolute;left:95px;top:35px;width:145px;height:55px;background:#fda4af;z-index:4;cursor:help">HTML darueber</div></div><div style="width:100%;height:150px;overflow:scroll;background:#fef3c7"><div style="width:700px;height:330px;padding:15px">'+svg(motif,'style="width:650px;height:270px"')+'</div></div>'))
panels.append(panel('S43 · Verschachtelte Deckkraft','HTML-Elternteil 0.5, SVG-Gruppe 0.5. Die beiden inneren Rechtecke werden zuerst gemeinsam zusammengesetzt.','<div style="background:#e2e8f0;padding:12px"><div style="opacity:0.5">'+svg('<g opacity="0.5"><rect x="30" y="30" width="250" height="140" fill="#2563eb"/><rect x="180" y="30" width="250" height="140" fill="#ef4444"/></g>','style="display:block;width:100%;height:auto"')+'</div></div>'))
grad='<defs><linearGradient id="local"><stop stop-color="COLOR"/><stop offset="1" stop-color="#ffffff"/></linearGradient></defs><rect x="10" y="25" width="460" height="150" rx="16" fill="url(#local)"/>'
panels.append(panel('S43 · Getrennte SVG-Instanzen','Zwei SVGs mit getrennten Verlaufsdefinitionen. Links bleibt der Verlauf blau, rechts rot; beide folgen der HTML-Breite.',svg(grad.replace('COLOR','#2563eb').replace('local','blue-local'),'style="width:48%;height:auto"')+svg(grad.replace('COLOR','#ef4444').replace('local','red-local'),'style="width:48%;height:auto"')))
shapes=[]
for count,cols in [(10,5),(100,20),(1000,50)]:
 rows=count//cols;cw,ch=480/cols,200/rows
 body=''.join(f'<rect x="{(i%cols)*cw+1:.3f}" y="{(i//cols)*ch+1:.3f}" width="{cw-2:.3f}" height="{ch-2:.3f}" fill="'+(['#2563eb','#16a34a','#f59e0b','#ef4444'][i%4])+'"/>' for i in range(count))
 raw=svg(body);shapes.append(dict(Name='S44-'+str(count),SVG=raw))
 panels.append(panel('S44 · '+str(count)+' Formen','Dieselbe Rasterflaeche mit '+str(count)+' Rechtecken. 1/2/3 wechselt die Groesse; C startet/stoppt kontinuierliches Resize.',svg(body,'style="display:block;width:100%;height:auto"')))
body='<defs><clipPath id="cut"><circle cx="240" cy="100" r="95"/></clipPath><linearGradient id="shade"><stop stop-color="#2563eb"/><stop offset="1" stop-color="#ef4444"/></linearGradient></defs><g clip-path="url(#cut)">'+''.join(f'<path d="M0 {i*8} Q240 {200-i*8} 480 {i*8}" fill="none" stroke="url(#shade)" stroke-width="3"/>' for i in range(25))+'</g>'
shapes.append(dict(Name='S44-curves',SVG=svg(body)))
panels.append(panel('S44 · Kurven, Verlauf und Clip','25 Kurven im runden Clip. R prueft 20 komplette Seiten-Lebenszyklen in Roblox; am Ende darf der Speicher nicht pro Zyklus steigen.',svg(body,'style="display:block;width:100%;height:auto"')))
base='<!doctype html><html><head><meta charset="utf-8"><style>body{margin:12px;font-family:Arial;font-size:16px;color:#172033;background:#ffffff}section{margin-bottom:26px;padding-bottom:18px;border-bottom:1px solid #cbd5e1}h2{font-size:20px;margin:12px 0}p{margin:10px 0}svg{font-family:"Source Sans Pro"}</style></head><body>'
footer='<p>Ende der Vergleichsseite</p></body></html>'
font=(ROOT/'examples/fonts/SourceSansPro-Regular.ttf').read_bytes();fontcss='@font-face{font-family:"Source Sans Pro";src:url(data:font/ttf;base64,'+base64.b64encode(font).decode()+')}html{overflow-y:scroll}::-webkit-scrollbar{width:10px;height:10px}'
outputs={}
for stage,title,subset,module,page in [('S43','S43 · SVG im HTML',panels[:4],'HTMLIntegrationSource','s43'),('S44','S44 · SVG-Leistung',panels[4:],'PerformanceSource','s44'),('S43_S44','S43 + S44 · HTML und Leistung',panels,'IntegrationPerformanceSource','s43-s44')]:
 html=base+''.join(subset)+footer;digest=hashlib.sha256(html.encode()).hexdigest()
 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]='--!strict\n-- Generated by scripts/sync-svg-integration.py.\nreturn {Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",HTML=[===['+html+']===]}\n'
 bridge="addEventListener('keydown',function(e){if(e.target.matches('input,textarea,select'))return;parent.postMessage({channel:'svg-integration-key',key:e.key,repeat:e.repeat},'*')});"
 outputs[out/(page+'-content.html')]=html.replace('</head>','<style>'+fontcss+'</style></head>').replace('</body>','<script>'+bridge+'</script></body>')
 wrapper=(ROOT/'scripts/svg-integration-template.html.in').read_text(encoding='utf8').replace('@@TITLE@@',title).replace('@@PAGE@@',page+'-content.html')
 outputs[out/(page+'.html')]=wrapper
for c in shapes:outputs[out/(c['Name']+'.svg')]=c['SVG']
outputs[ROOT/'examples/SVGLab/StressSources.luau']='--!strict\nreturn {Cases={'+','.join('{Name='+json.dumps(c['Name'])+',SVG=[===['+c['SVG']+']===]}' for c in shapes)+'}}\n'
for path,content in outputs.items():
 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'
 else:path.write_text(content,encoding='utf8')
print('S43/S44: eight HTML comparison panels and four deterministic stress SVGs synchronized/checked.')
