"""S33/S34: native SVG and Luau comparison sources, generated together."""
from pathlib import Path
import hashlib,json,sys,base64
ROOT=Path(__file__).resolve().parent.parent
folder=ROOT/'examples/svg-tests'
specs=[]
def add(n,c,s):specs.append((n,c,s))
def label(text,x,y):return f'<text x="{x}" y="{y}" font-size="15" fill="#172033">{text}</text>'
def filt(id,body,w=200,h=110,extra=''):return f'<filter id="{id}" filterUnits="userSpaceOnUse" x="0" y="0" width="{w}" height="{h}" color-interpolation-filters="sRGB" {extra}>{body}</filter>'
def panel(x,y,id,w=200,h=110):return f'<g transform="translate({x} {y})"><rect width="{w}" height="{h}" fill="black" filter="url(#{id})"/></g>'
def image(extra=''):return f'<feImage href="S21-source.png" {extra}/>'
add('S33-image','Dasselbe RGBA-Bild als feImage: meet, slice und none. Unten rechts nur ein kleiner Ausschnitt der Filterregion. Rote Rahmen markieren die Zielrechtecke; das transparente Loch bleibt durchsichtig.', '<defs>'+''.join(filt(id,image(f'preserveAspectRatio="{a}" '+extra)) for id,a,extra in [('meet','xMidYMid meet',''),('slice','xMidYMid slice',''),('none','none',''),('small','none','x="40" y="15" width="100" height="80"')])+'</defs>'+''.join(label(id,20+(i%2)*240,22+(i//2)*155)+panel(20+(i%2)*240,30+(i//2)*155,id)+f'<rect x="{20+(i%2)*240}" y="{30+(i//2)*155}" width="200" height="110" fill="none" stroke="#ef4444"/>' for i,id in enumerate(['meet','slice','none','small'])))
add('S33-tile','Oben die 48 x 32 grosse Bildkachel einmal und wiederholt. Unten hat die Kachel einen transparenten Rand: feTile wiederholt die ganze 64 x 48 grosse Eingangsregion, nicht nur die farbigen Pixel.', '<defs>'+filt('one',image('x="0" y="0" width="48" height="32" preserveAspectRatio="none"'))+filt('tile',image('x="0" y="0" width="48" height="32" preserveAspectRatio="none"')+'<feTile/>')+filt('gap',image('x="8" y="8" width="48" height="32" preserveAspectRatio="none"')+'<feOffset dx="0" dy="0" x="0" y="0" width="64" height="48"/><feTile/>',440,120)+'</defs>'+label('eine Kachel',20,22)+label('feTile',260,22)+panel(20,30,'one')+panel(260,30,'tile')+panel(20,185,'gap',440,120)+''.join(f'<path d="M{x} 185v120" stroke="#ef4444" stroke-opacity=".55"/>' for x in range(20,461,64)))
shape='<path d="M15 15h170v80h-170z M40 35v40h120v-40z" fill="#2563eb" fill-rule="evenodd"/><text x="55" y="70" font-size="36" font-weight="700" fill="#ef4444">AB</text>'
add('S33-morphology','Oben Original und Dilatation Radius 3. Unten Erosion Radius 2 und anisotrope Dilatation Radius 6 / 1. Sowohl das Innenloch als auch die echten Schriftkonturen veraendern sich.', '<defs>'+''.join(filt(id,body) for id,body in [('plain','<feOffset/>'),('dilate','<feMorphology operator="dilate" radius="3"/>'),('erode','<feMorphology operator="erode" radius="2"/>'),('xy','<feMorphology operator="dilate" radius="6 1"/>')])+'</defs>'+''.join(label(id,20+(i%2)*240,22+(i//2)*155)+f'<g transform="translate({20+(i%2)*240} {30+(i//2)*155})" filter="url(#{id})">{shape}</g>' for i,id in enumerate(['plain','dilate','erode','xy'])))
conv=[('Original','<feOffset/>'),('Schaerfen','<feConvolveMatrix order="3" kernelMatrix="0 -1 0 -1 5 -1 0 -1 0" preserveAlpha="true"/>'),('Kanten','<feConvolveMatrix order="3" kernelMatrix="-1 -1 -1 -1 8 -1 -1 -1 -1" bias=".5" preserveAlpha="true"/>'),('Praegung','<feConvolveMatrix order="3" kernelMatrix="-2 -1 0 -1 1 1 0 1 2" bias=".5" preserveAlpha="true"/>')]
add('S33-convolve','Original, Schaerfung, Kanten und Praegung mit 3 x 3 Faltungsmatrizen. Alpha bleibt erhalten. Der Praegeeffekt macht die Orientierung des um 180 Grad gedrehten Kernels sichtbar.', '<defs>'+''.join(filt('c'+str(i),image('preserveAspectRatio="none"')+body) for i,(_,body) in enumerate(conv))+'</defs>'+''.join(label(name,20+(i%2)*240,22+(i//2)*155)+panel(20+(i%2)*240,30+(i//2)*155,'c'+str(i)) for i,(name,_) in enumerate(conv)))
def grid():return '<rect width="200" height="110" fill="#fff"/>'+''.join(f'<path d="M{x} 0v110" stroke="#2563eb"/>' for x in range(0,201,20))+''.join(f'<path d="M0 {y}h200" stroke="#2563eb"/>' for y in range(0,111,22))+''.join(f'<text x="{x*40+5}" y="60" font-size="18" fill="#172033">{x+1}</text>' for x in range(5))
def gpanel(x,y,id):return f'<g transform="translate({x} {y})" filter="url(#{id})">{grid()}</g>'
def mapfilter(id,c,selectors='R G',scale='40'):
 x,y=selectors.split();return filt(id,f'<feFlood flood-color="{c}" result="map"/><feDisplacementMap in="SourceGraphic" in2="map" scale="{scale}" xChannelSelector="{x}" yChannelSelector="{y}"/>')
add('S34-displacement','Nummeriertes Raster mit konstanten Karten: neutral, rot, gruen und gelb. Ein Kanalwert ueber 0.5 tastet weiter rechts/unten ab; das sichtbare Raster wandert daher nach links/oben. Massstab 40.', '<defs>'+''.join(mapfilter(id,c) for id,c in [('neutral','rgb(50%,50%,0%)'),('red','rgb(100%,50%,0%)'),('green','rgb(50%,100%,0%)'),('yellow','rgb(100%,100%,0%)')])+'</defs>'+''.join(label(id,20+(i%2)*240,22+(i//2)*155)+gpanel(20+(i%2)*240,30+(i//2)*155,id) for i,id in enumerate(['neutral','red','green','yellow'])))
# A known R/G ramp supplied as the same immutable RGBA pixels to both renderers.
def ramp(extra=''):return f'<feImage href="S34-ramp.png" preserveAspectRatio="none" {extra}/>'
add('S34-channels','Oben die Karte: Rot steigt nach rechts, Gruen nach unten. Daneben das verzerrte Raster mit R/G, unten mit G/R oder B/Alpha. Blau ist konstant 128, Alpha 255. Damit sind Richtung und Kanalwahl vorhersagbar.', '<defs>'+filt('map',ramp())+''.join(filt(id,ramp('result="map"')+f'<feDisplacementMap in="SourceGraphic" in2="map" scale="45" xChannelSelector="{x}" yChannelSelector="{y}"/>') for id,x,y in [('rg','R','G'),('gr','G','R'),('ba','B','A')])+'</defs>'+label('R/G-Karte',20,22)+panel(20,30,'map')+label('R / G',260,22)+gpanel(260,30,'rg')+label('G / R',20,177)+gpanel(20,185,'gr')+label('B / Alpha',260,177)+gpanel(260,185,'ba'))
noises=[('turbulence, 1 Oktave','turbulence',1,7),('fractalNoise, 1 Oktave','fractalNoise',1,7),('fractalNoise, 4 Oktaven','fractalNoise',4,7),('fractalNoise, Seed 19','fractalNoise',4,19)]
add('S34-noise','Feste Seeds: turbulence und fractalNoise, eine oder vier Oktaven. R sollte bei jedem Neuaufbau dasselbe Muster erzeugen. Farben und Alpha stammen aus vier unabhaengigen Kanaelen.', '<defs>'+''.join(filt('n'+str(i),f'<feTurbulence type="{typ}" baseFrequency=".035 .055" numOctaves="{oct}" seed="{seed}"/>') for i,(_,typ,oct,seed) in enumerate(noises))+'</defs>'+''.join(label(name,20+(i%2)*240,22+(i//2)*155)+panel(20+(i%2)*240,30+(i//2)*155,'n'+str(i)) for i,(name,_,_,_) in enumerate(noises)))
add('S34-stitch','Oben feTurbulence mit stitchTiles=stitch, unten noStitch; beide 80 x 60 gross und mit feTile wiederholt. Rote Markierungen zeigen Kachelgrenzen. Oben sollen keine harten Naehte entstehen.', '<defs>'+''.join(filt(id,f'<feTurbulence type="fractalNoise" baseFrequency=".043 .067" numOctaves="3" seed="7" stitchTiles="{mode}" x="0" y="0" width="80" height="60"/><feTile/>',440,120) for id,mode in [('stitch','stitch'),('raw','noStitch')])+'</defs>'+label('stitch',20,22)+panel(20,30,'stitch',440,120)+label('noStitch',20,177)+panel(20,185,'raw',440,120)+''.join(f'<path d="M{x} 26v8 M{x} 146v8 M{x} 181v8 M{x} 301v8" stroke="#ef4444"/>' for x in range(20,461,80)))

import struct,zlib
def chunk(tag,data):return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data))
ramp_bytes=b''.join(b'\0'+bytes(v for x in range(64) for v in (round(x*255/63),round(y*255/63),128,255)) for y in range(64))
ramp_png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',64,64,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(ramp_bytes))+chunk(b'IEND',b'')
ramp_path=folder/'S34-ramp.png'
if '--check' in sys.argv:assert ramp_path.read_bytes()==ramp_png
else:ramp_path.write_bytes(ramp_png)
faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=weight,Style=style) for face,weight,style in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]

png=(folder/'S21-source.png').read_bytes()
font=b''.join(base64.b64decode(face['Data']) for face in faces)

cases=[dict(Name=n,Caption=c,SVG='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+svg+'\n</svg>\n') for n,c,svg in specs]

outputs={folder/(c['Name']+'.svg'):c['SVG'] for c in cases}
for stage,title,subset,module,page in [('S33','S33 · Bild, Kacheln und Konturen',cases[:4],'KernelFilterSources','s33.html'),('S34','S34 · Verzerrung und Rauschen',cases[4:],'NoiseFilterSources','s34.html'),('S33_S34','S33 + S34 · Bildfilter und Rauschen',cases,'KernelNoiseSources','s33-s34.html')]:

 digest=hashlib.sha256(''.join(c['SVG'] for c in subset).encode()+font+png+ramp_png).hexdigest()

 luau='--!strict\n-- Generated by scripts/sync-svg-kernel-filters.py.\nlocal imageSource=require(script.Parent.ImageClipSources)\nlocal rampPixels=buffer.create(64*64*4)\nfor y=0,63 do for x=0,63 do local at=(y*64+x)*4;buffer.writeu8(rampPixels,at,math.round(x*255/63));buffer.writeu8(rampPixels,at+1,math.round(y*255/63));buffer.writeu8(rampPixels,at+2,128);buffer.writeu8(rampPixels,at+3,255) end end\nlocal function resolve(url,base) if url:match("S34%-ramp%.png$") then return {Width=64,Height=64,Pixels=rampPixels} end;return imageSource.ResolveImage(url,base) end\nreturn {ResolveImage=resolve,Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",Cases={\n'

 for c in subset:luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+',SVG=[===['+c['SVG']+']===]},\n'

 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]=luau+'}}\n'

 html='''<!doctype html><html lang="de"><meta charset="utf-8"><title>TITLE</title>

<style>body{margin:24px;font:14px Arial,sans-serif;color:#172033;background:#eef2f7}h1{font-size:20px}a{color:#245fb2}.board{display:block;outline:1px solid #aab4c3;background:conic-gradient(#fff 25%,#ddd 0 50%,#fff 0 75%,#ddd 0);background-size:32px 32px;margin-top:16px}.caption{margin:10px 0 16px;max-width:900px}</style>

<h1>TITLE</h1><p>Gleiche Source-Sans-Pro-Datei in Browser und Roblox. Tasten 1 / 2 / 3: 240 / 480 / 960 px · R: 20 Neuaufbauten.</p><p><a href="s31-s32.html">S31 / S32 ansehen</a></p><div id="cases"></div>

<script>

const sources=CASES, font=FONT;const png=PNG;const ramp=RAMP;let width=480, urls=[];

function render(){const host=document.querySelector('#cases');host.replaceChildren();for(const url of urls)URL.revokeObjectURL(url);urls=[];for(const item of sources){const parsed=new DOMParser().parseFromString(item.SVG,'image/svg+xml');if(parsed.querySelector('parsererror'))throw Error(item.Name);for(const image of parsed.querySelectorAll('image, feImage')){if(image.getAttribute('href')==='S21-source.png')image.setAttribute('href',png);if(image.getAttribute('href')==='S34-ramp.png')image.setAttribute('href',ramp)}const svg=parsed.documentElement;const style=parsed.createElementNS(svg.namespaceURI,'style');style.textContent=font.map(f=>'@font-face{font-family:"Source Sans Pro";src:url(data:font/ttf;base64,'+f.Data+') format("truetype");font-weight:'+f.Weight+';font-style:'+f.Style+'}').join('');svg.prepend(style);svg.setAttribute('width','100%');svg.setAttribute('height','100%');const board=document.createElement('div');board.className='board';board.style.width=width+'px';board.style.height=320*width/480+'px';const frame=document.createElement('iframe');frame.title=item.Name;frame.style.cssText='border:0;width:100%;height:100%;display:block';const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'}));urls.push(url);frame.src=url;board.append(frame);const caption=document.createElement('p');caption.className='caption';caption.textContent=item.Caption;frame.addEventListener('load',async()=>{try{const sets=await Promise.all(font.map(f=>frame.contentDocument.fonts.load(f.Style+' '+f.Weight+' 32px "Source Sans Pro"')));if(sets.some(s=>!s.length))throw Error('Font fehlt');frame.dataset.fontReady='true'}catch(error){caption.textContent+=' FONT-LADEFEHLER: '+error.message}});host.append(board,caption)}}

addEventListener('keydown',e=>{if(e.repeat)return;const size={'1':240,'2':480,'3':960}[e.key];if(size){width=size;render()}else if(e.key.toLowerCase()==='r'){for(let n=0;n<20;n++)render()}});render();

</script></html>

'''.replace('TITLE',title).replace('CASES',json.dumps(subset,ensure_ascii=False).replace('<','\\u003c')).replace('font=FONT;', 'font='+json.dumps(faces)+';').replace('const png=PNG;', 'const png='+json.dumps('data:image/png;base64,'+base64.b64encode(png).decode())+';')
 html=html.replace('const ramp=RAMP;', 'const ramp='+json.dumps('data:image/png;base64,'+base64.b64encode(ramp_png).decode())+';')
 outputs[folder/page]=html

for path,content in outputs.items():

 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'

 else:path.write_text(content,encoding='utf8')

print('S33/S34: eight native SVG boards and three comparison pages synchronized/checked.')

