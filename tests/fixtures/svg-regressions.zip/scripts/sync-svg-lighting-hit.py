"""S35/S36 comparison boards: lighting and native pointer targets."""
from pathlib import Path
import hashlib,json,sys,base64
ROOT=Path(__file__).resolve().parent.parent
folder=ROOT/'examples/svg-tests'
specs=[]
def add(n,c,s):specs.append((n,c,s))
def label(text,x,y):return f'<text pointer-events="none" x="{x}" y="{y}" font-size="15" fill="#172033">{text}</text>'
def filt(id,body,w=140,h=230):return f'<filter id="{id}" filterUnits="userSpaceOnUse" x="0" y="0" width="{w}" height="{h}" color-interpolation-filters="sRGB">{body}</filter>'
lights=[('distant','<feDistantLight azimuth="225" elevation="40"/>'),('point','<fePointLight x="25" y="25" z="70"/>'),('spot','<feSpotLight x="25" y="25" z="90" pointsAtX="70" pointsAtY="120" pointsAtZ="0" limitingConeAngle="25" specularExponent="6"/>')]
bump='<ellipse cx="70" cy="85" rx="43" ry="48" fill="#2563eb"/><text x="25" y="195" font-size="62" font-weight="700" fill="#2563eb">AB</text>'
for name,kind in [('diffuse','feDiffuseLighting'),('specular','feSpecularLighting')]:
 defs='';body=''
 for i,(id,light) in enumerate(lights):
  attrs='diffuseConstant="1"' if name=='diffuse' else 'specularConstant="1.2" specularExponent="14"'
  defs+=filt(id,f'<feGaussianBlur stdDeviation="4"/><{kind} surfaceScale="10" {attrs} lighting-color="#fff0c0">{light}</{kind}>')
  body+=label(id,15+i*155,25)+f'<g transform="translate({10+i*155} 50)" filter="url(#{id})">{bump}</g>'
  if i>0:body+=f'<g pointer-events="none" stroke="#ef4444"><path d="M{30+i*155} 75h10 M{35+i*155} 70v10"/></g>'
 add('S35-'+name,('Diffuse Beleuchtung (deckende Lichtkarte)' if name=='diffuse' else 'Spiegelnde Beleuchtung (Alpha aus staerkstem Farbkanal)')+': identische Hoehenkarte mit Fern-, Punkt- und Spotlicht. Rote Kreuze zeigen die XY-Lichtpositionen. Links oben liegendes Licht, Glanzkante und Spotgrenze vergleichen.', '<defs>'+defs+'</defs>'+body)
defs='';body=''
for i,(height,exponent) in enumerate([(3,4),(12,4),(3,32),(12,32)]):
 id='p'+str(i);defs+=filt(id,f'<feGaussianBlur stdDeviation="3"/><feSpecularLighting surfaceScale="{height}" specularExponent="{exponent}" lighting-color="#7dd3fc"><fePointLight x="55" y="30" z="80"/></feSpecularLighting>',210,115)
 body+=label(f'Hoehe {height}, Glanz {exponent}',20+(i%2)*240,23+(i//2)*155)+f'<g transform="translate({15+(i%2)*240} {32+(i//2)*155})" filter="url(#{id})"><rect x="35" y="20" width="140" height="80" rx="22" fill="#2563eb"/></g>'
add('S35-surface','Oben/unten unterscheiden sich im Glanzexponenten, links/rechts in der Hoehe. Ein hoeherer Exponent macht den Glanz schmaler. Die Form und der Blur bleiben gleich.', '<defs>'+defs+'</defs>'+body)
light='<fePointLight x="30" y="20" z="100"/>'
diff=f'<feDiffuseLighting in="height" surfaceScale="9" result="light" lighting-color="#ffffff">{light}</feDiffuseLighting><feComposite in="SourceGraphic" in2="light" operator="arithmetic" k1="1" result="base"/>'
spec=f'<feSpecularLighting in="height" surfaceScale="9" specularExponent="14" lighting-color="#ffffff">{light}</feSpecularLighting><feComposite in2="base" operator="arithmetic" k2="1" k3="1"/>'
add('S35-combined','Links Original, rechts diffuse Farbe plus Glanz. Oben Ring, unten Schrift. Der Graph kombiniert die Lichtkarten mit SourceGraphic; die Hoehenkarte selbst kommt aus weichgezeichnetem Alpha.', '<defs>'+filt('lit','<feGaussianBlur in="SourceAlpha" stdDeviation="3" result="height"/>'+diff+spec,210,260)+'</defs>'+label('Original',20,24)+label('Diffuse + Specular',260,24)+''.join(f'<g transform="translate({x} 40)"'+(' filter="url(#lit)"' if x>20 else '')+'><circle cx="95" cy="75" r="48" fill="none" stroke="#2563eb" stroke-width="22"/><text x="20" y="225" font-size="82" font-weight="700" fill="#f59e0b">SVG</text></g>' for x in [10,250]))
def markers(points):return '<g pointer-events="none">'+''.join(f'<path d="M{x-4} {y}h8 M{x} {y-4}v8" stroke="#dc2626" stroke-width="1"/><text x="{x+5}" y="{y-5}" font-size="13" fill="#991b1b">{i+1}</text>' for i,(x,y,_) in enumerate(points))+'</g>'
probes={}
def hit(name,caption,body,points):
 probes[name]=[dict(X=x,Y=y,Expected=expected) for x,y,expected in points]
 add(name,caption,body+markers(points))
hit('S36-fill','Maus ueber die Kreuze bewegen. 1: Loch = nichts, 2: Donut, 3: transparente Fuellung trifft, 4: fill=none ohne Kontur trifft nicht. Die Statuszeile nennt das tatsaechlich getroffene Element.', '<path id="donut" d="M20 45h190v210h-190z M65 90v120h100v-120z" fill="#2563eb" fill-rule="evenodd"/><rect id="transparent" x="270" y="45" width="170" height="90" fill="#16a34a" fill-opacity="0"/><rect id="unpainted" x="270" y="175" width="170" height="90" fill="none"/>'+label('fill-opacity: 0',275,35)+label('fill: none',275,165),[(110,145,''),(40,145,'donut'),(340,90,'transparent'),(340,220,'')])
hit('S36-stroke','1 trifft die dicke Linie, 2 liegt daneben. 3 trifft einen Strich, 4 liegt in der Luecke. 5 trifft die gedrehte Form, 6 liegt nur in ihrer aeusseren achsenparallelen Box. Konturen werden geometrisch getestet.', '<path id="line" d="M35 65H215" fill="none" stroke="#2563eb" stroke-width="22" stroke-linecap="round"/><path id="dashes" d="M35 160H235" fill="none" stroke="#16a34a" stroke-width="20" stroke-dasharray="30 20"/><rect id="rotated" x="305" y="75" width="90" height="150" fill="#a855f7" transform="rotate(30 350 150)"/>',[(120,65,'line'),(120,86,''),(45,160,'dashes'),(75,160,''),(350,150,'rotated'),(280,65,'')])
hit('S36-events','Oben: pointer-events=none laesst den Treffer zur blauen Form durch; darunter ein verdecktes Element mit all. Unten: stroke trifft auch ohne gezeichnete Kontur, fill trifft auch ohne Fuellfarbe. Hilfsrahmen fangen keine Maus ab.', '<rect id="back" x="25" y="35" width="180" height="95" fill="#2563eb"/><rect id="ignore" x="90" y="55" width="160" height="65" fill="#ef4444" pointer-events="none"/><rect id="hidden-all" x="290" y="35" width="150" height="95" fill="#16a34a" visibility="hidden" pointer-events="all"/><rect id="stroke-only" x="35" y="200" width="150" height="65" fill="none" stroke="none" stroke-width="14" pointer-events="stroke"/><rect id="fill-only" x="290" y="200" width="150" height="65" fill="none" pointer-events="fill"/><g fill="none" stroke="#94a3b8" pointer-events="none"><rect x="290" y="35" width="150" height="95"/><rect x="35" y="200" width="150" height="65"/><rect x="290" y="200" width="150" height="65"/></g>',[(130,80,'back'),(345,80,'hidden-all'),(35,230,'stroke-only'),(100,230,''),(345,230,'fill-only')])
hit('S36-clip-mask','Links schneidet clipPath auch den Trefferbereich ab: 1 trifft, 2 nicht. Rechts blendet eine Maske die Mitte aus: 3 und 4 treffen trotzdem masked. Unten ueberlappen zwei Formen: die spaeter gezeichnete gewinnt.', '<defs><clipPath id="clip"><circle cx="110" cy="95" r="65"/></clipPath><mask id="mask" maskUnits="userSpaceOnUse" x="255" y="25" width="195" height="145"><rect x="255" y="25" width="195" height="145" fill="white"/><circle cx="350" cy="95" r="40" fill="black"/></mask></defs><g clip-path="url(#clip)"><rect id="clipped" x="25" y="25" width="190" height="145" fill="#2563eb"/></g><rect id="masked" x="255" y="25" width="195" height="145" fill="#16a34a" mask="url(#mask)"/><rect id="bottom" x="90" y="215" width="200" height="80" fill="#a855f7"/><rect id="top" x="210" y="230" width="190" height="65" fill="#f59e0b"/>',[(110,95,'clipped'),(30,30,''),(350,95,'masked'),(420,95,'masked'),(140,250,'bottom'),(250,250,'top')])

faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=weight,Style=style) for face,weight,style in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]

png=(folder/'S21-source.png').read_bytes()
font=b''.join(base64.b64decode(face['Data']) for face in faces)

cases=[dict(Name=n,Caption=c,SVG='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+svg+'\n</svg>\n') for n,c,svg in specs]

for c in cases:c['Probes']=probes.get(c['Name'],[])
outputs={folder/(c['Name']+'.svg'):c['SVG'] for c in cases}
for stage,title,subset,module,page in [('S35','S35 · Beleuchtung',cases[:4],'LightingSources','s35.html'),('S36','S36 · Formgenaue Maustests',cases[4:],'HitSources','s36.html'),('S35_S36','S35 + S36 · Beleuchtung und Maustests',cases,'LightingHitSources','s35-s36.html')]:

 digest=hashlib.sha256(''.join(c['SVG'] for c in subset).encode()+font+png).hexdigest()

 luau='--!strict\n-- Generated by scripts/sync-svg-lighting-hit.py.\nlocal imageSource=require(script.Parent.ImageClipSources)\nreturn {ResolveImage=imageSource.ResolveImage,Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",Cases={\n'

 for c in subset:luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+',Probes={'+','.join('{X='+str(q['X'])+',Y='+str(q['Y'])+',Expected='+json.dumps(q['Expected'])+'}' for q in c['Probes'])+'},SVG=[===['+c['SVG']+']===]},\n'

 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]=luau+'}}\n'

 html='''<!doctype html><html lang="de"><meta charset="utf-8"><title>TITLE</title>

<style>body{margin:24px;font:14px Arial,sans-serif;color:#172033;background:#eef2f7}h1{font-size:20px}a{color:#245fb2}.board{display:block;outline:1px solid #aab4c3;background:conic-gradient(#fff 25%,#ddd 0 50%,#fff 0 75%,#ddd 0);background-size:32px 32px;margin-top:16px}.caption{margin:10px 0 16px;max-width:900px}</style>

<h1>TITLE</h1><p>Gleiche Source-Sans-Pro-Datei in Browser und Roblox. Tasten 1 / 2 / 3: 240 / 480 / 960 px · R: 20 Neuaufbauten.</p><p><a href="s33-s34.html">S33 / S34 ansehen</a></p><div id="cases"></div>

<script>

const sources=CASES, font=FONT;const png=PNG;let width=480, urls=[];

function render(){const host=document.querySelector('#cases');host.replaceChildren();for(const url of urls)URL.revokeObjectURL(url);urls=[];for(const item of sources){const parsed=new DOMParser().parseFromString(item.SVG,'image/svg+xml');if(parsed.querySelector('parsererror'))throw Error(item.Name);for(const image of parsed.querySelectorAll('image')){if(image.getAttribute('href')==='S21-source.png')image.setAttribute('href',png)}const svg=parsed.documentElement;const style=parsed.createElementNS(svg.namespaceURI,'style');style.textContent=font.map(f=>'@font-face{font-family:"Source Sans Pro";src:url(data:font/ttf;base64,'+f.Data+') format("truetype");font-weight:'+f.Weight+';font-style:'+f.Style+'}').join('');svg.prepend(style);svg.setAttribute('width','100%');svg.setAttribute('height','100%');const board=document.createElement('div');board.className='board';board.style.width=width+'px';board.style.height=320*width/480+'px';const frame=document.createElement('iframe');frame.title=item.Name;frame.style.cssText='border:0;width:100%;height:100%;display:block';const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'}));urls.push(url);frame.src=url;board.append(frame);const caption=document.createElement('p');caption.className='caption';caption.textContent=item.Caption;frame.addEventListener('load',async()=>{try{const sets=await Promise.all(font.map(f=>frame.contentDocument.fonts.load(f.Style+' '+f.Weight+' 32px "Source Sans Pro"')));if(sets.some(s=>!s.length))throw Error('Font fehlt');frame.dataset.fontReady='true'}catch(error){caption.textContent+=' FONT-LADEFEHLER: '+error.message}});const readout=document.createElement('p');readout.textContent=item.Probes.length?'Treffer: — (Maus über die Tafel bewegen)':'';frame.addEventListener('load',()=>{const doc=frame.contentDocument;if(!doc)return;doc.addEventListener('pointermove',e=>{let target=e.target;while(target&&target!==doc.documentElement&&!target.id)target=target.parentElement;readout.textContent='Treffer: '+(target&&target!==doc.documentElement&&target.id?target.id:'—')});doc.addEventListener('pointerleave',()=>readout.textContent='Treffer: —')});host.append(board,caption,readout)}}

addEventListener('keydown',e=>{if(e.repeat)return;const size={'1':240,'2':480,'3':960}[e.key];if(size){width=size;render()}else if(e.key.toLowerCase()==='r'){for(let n=0;n<20;n++)render()}});render();

</script></html>

'''.replace('TITLE',title).replace('CASES',json.dumps(subset,ensure_ascii=False).replace('<','\\u003c')).replace('font=FONT;', 'font='+json.dumps(faces)+';').replace('const png=PNG;', 'const png='+json.dumps('data:image/png;base64,'+base64.b64encode(png).decode())+';')
 outputs[folder/page]=html

for path,content in outputs.items():

 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'

 else:path.write_text(content,encoding='utf8')

print('S35/S36: eight native SVG boards and three comparison pages synchronized/checked.')

