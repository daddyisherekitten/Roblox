"""S41/S42: identical JavaScript sources, conditional branches and native SVG views."""
from pathlib import Path
import json,hashlib,base64,sys,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent.parent;folder=ROOT/'examples/svg-tests';cases=[]
NS='http://www.w3.org/2000/svg'
def label(t,x,y):return f'<text x="{x}" y="{y}" font-size="20" fill="#172033" pointer-events="none">{t}</text>'
def add(name,caption,body,script='',fragment=None):
 svg=f'<svg xmlns="{NS}" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+body+(('<script><![CDATA['+script+']]></script>') if script else '')+'</svg>\n'
 item=dict(Name=name,Caption=caption,SVG=svg)
 if fragment:item['Fragment']=fragment
 cases.append(item)
button='<rect id="action" x="150" y="250" width="180" height="45" rx="8" fill="#cbd5e1" cursor="pointer" tabindex="0"/>'+label('Klicken',208,280)
add('S41-create','Der Kreis entsteht ausschliesslich durch das eingebettete JavaScript. Jeder Klick vergroessert Radius und Zaehler; die Farbe wechselt. R stellt den Ausgangszustand wieder her.', '<g id="host"/><text id="count" x="220" y="220" font-size="26">0</text>'+button, """
const circle=document.createElementNS('http://www.w3.org/2000/svg','circle');
circle.setAttribute('cx',240);circle.setAttribute('cy',125);circle.setAttribute('r',35);circle.setAttribute('fill','#2563eb');
document.getElementById('host').appendChild(circle);
let count=0;
document.getElementById('action').addEventListener('click',function(e){count++;circle.setAttribute('r',35+(count%5)*8);circle.setAttribute('fill',count%2===1?'#16a34a':'#2563eb');document.getElementById('count').textContent=String(count);});
""")
add('S41-closures','Vier durch eine for-Schleife erzeugte Kreise. Jeder Kreis hat seine eigene gespeicherte Nummer und einen eigenen Klickzaehler. Anklicken vergroessert nur den getroffenen Kreis.', '<g id="host"/>'+label('Vier unabhaengige Rueckrufe',95,270), """
function make(index){
 const c=document.createElementNS('http://www.w3.org/2000/svg','circle');let clicks=0;
 c.setAttribute('id','circle'+index);c.setAttribute('cx',75+index*110);c.setAttribute('cy',130);c.setAttribute('r',28);c.setAttribute('fill','#2563eb');c.setAttribute('cursor','pointer');
 c.addEventListener('click',function(e){clicks++;c.setAttribute('r',28+(clicks%4)*5);c.setAttribute('fill',clicks%2===1?'#f59e0b':'#2563eb');});
 document.getElementById('host').appendChild(c);
}
for(let i=0;i<4;i++){make(i);}
""")
add('S41-remove','Klick entfernt den Kreis aus dem DOM und setzt ihn beim naechsten Klick wieder ein. Die rechte Beschriftung zeigt den Zustand; Tab fokussiert den Knopf, Enter/Leertaste schaltet ebenfalls.', '<g id="host"><circle id="dot" cx="125" cy="130" r="48" fill="#16a34a"/></g><text id="status" x="240" y="140" font-size="22">Sichtbar</text>'+button,"""
const host=document.getElementById('host');const dot=document.getElementById('dot');let visible=true;
function toggle(){if(visible){host.removeChild(dot);}else{host.appendChild(dot);}visible=!visible;document.getElementById('status').textContent=visible?'Sichtbar':'Entfernt';}
const action=document.getElementById('action');action.addEventListener('click',toggle);
action.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle();}});
""")
add('S41-resource','Das Skript aendert einen stop-color-Wert und beide Verbraucher desselben Verlaufs wechseln gemeinsam. Ein zweiter Klick stellt die Ursprungsfarbe wieder her.', '<defs><linearGradient id="paint"><stop id="stop" stop-color="#2563eb"/><stop offset="1" stop-color="#ffffff"/></linearGradient></defs><rect x="35" y="70" width="180" height="135" fill="url(#paint)"/><circle cx="340" cy="138" r="68" fill="url(#paint)"/>'+button,"""
let green=false;document.getElementById('action').addEventListener('click',function(e){green=!green;document.getElementById('stop').setAttribute('stop-color',green?'#16a34a':'#2563eb');e.currentTarget.setAttribute('fill',green?'#bbf7d0':'#cbd5e1');});
""")
add('S42-language','switch waehlt nur den ersten passenden Zweig: Fantasiesprache und unbekannte Erweiterung werden uebersprungen. Gruen bei en/de/fr/it/es, sonst violetter Fallback. Roblox verwendet hier en; Browser seine echte bevorzugte Sprache.', '<switch><g systemLanguage="zz-ZZ"><rect x="45" y="45" width="390" height="210" fill="#ef4444"/>'+label('FALSCHE SPRACHE',100,160)+'</g><g requiredExtensions="urn:unsupported:demo"><rect width="480" height="320" fill="#ef4444"/></g><g systemLanguage="en,de,fr,it,es"><rect x="45" y="45" width="390" height="210" rx="16" fill="#16a34a"/>'+label('SPRACHE PASST',140,160)+'</g><g><rect x="45" y="45" width="390" height="210" rx="16" fill="#a855f7"/>'+label('FALLBACK',180,160)+'</g></switch>')
views='<view id="left" viewBox="0 0 480 320"/><view id="right" viewBox="480 0 480 320"/><rect x="40" y="40" width="400" height="240" rx="15" fill="#2563eb"/>'+label('ANSICHT A',190,160)+'<circle cx="720" cy="160" r="95" fill="#f59e0b"/>'+label('ANSICHT B',670,160)
add('S42-view-left','Native SVG-Datei mit #left: ausschliesslich das blaue linke Motiv, zentriert im gleichen 480x320-Ausschnitt. Roblox liest viewBox aus dem referenzierten view-Element; das Basis-SVG bleibt unveraendert.',views,fragment='left')
add('S42-view-right','Dieselbe SVG-Geometrie mit #right: ausschliesslich der gelbe Kreis. Die Ansichten sind echte Dateifragmente im Browser, keine nachgebaute Zoom-Aktion.',views,fragment='right')
add('S42-resources','Links lokale use-Ressource vorhanden, rechts fehlt die referenzierte Ressource absichtlich. Rahmen und Beschriftung bleiben. Mit Tab/Klick Fokus und Titel/Beschreibung im Status pruefen.', '<defs><g id="icon"><path d="M-45 30L0-45 45 30Z" fill="#16a34a"/></g></defs><g id="known" tabindex="0" role="img"><title>Vorhandenes Symbol</title><desc>Gruenes Dreieck aus einer lokalen Definition</desc><rect x="40" y="55" width="165" height="155" fill="#dbeafe"/><use href="#icon" x="122" y="135"/></g><g id="missing" tabindex="0" role="img"><title>Fehlende Ressource</title><desc>Die leere Flaeche ist beabsichtigt</desc><rect x="270" y="55" width="165" height="155" fill="#fef3c7"/><use href="#does-not-exist"/></g>'+label('Vorhanden',76,252)+label('Fehlt',331,252))
faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=w,Style=s) for face,w,s in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]
fontcss=''.join('@font-face{font-family:"Source Sans Pro";src:url(data:font/ttf;base64,'+f['Data']+');font-weight:'+str(f['Weight'])+';font-style:'+f['Style']+'}' for f in faces)
template=(ROOT/'scripts/svg-scripting-template.html.in').read_text(encoding='utf8');outputs={}
for c in cases:
 svg=c['SVG']
 if c.get('Fragment'):
  svg=svg.replace('width="480" height="320"','width="100%" height="100%"',1)
  bridge="addEventListener('keydown',function(e){parent.postMessage({channel:'svg-doc-native',key:e.key},'*');});"
  svg=svg.replace('</svg>','<style>'+fontcss+'</style><script><![CDATA['+bridge+']]></script></svg>')
 outputs[folder/(c['Name']+'.svg')]=svg
for stage,title,subset,module,page in [('S41','S41 · JavaScript und SVG-DOM',cases[:4],'ScriptSources','s41.html'),('S42','S42 · Dokumente und Ansichten',cases[4:],'DocumentSources','s42.html'),('S41_S42','S41 + S42 · Skripte und Dokumente',cases,'ScriptDocumentSources','s41-s42.html')]:
 digest=hashlib.sha256((''.join(c['SVG'] for c in subset)+json.dumps(faces)).encode()).hexdigest()
 luau='--!strict\n-- Generated by scripts/sync-svg-scripting.py.\nreturn {Scripted=true,Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",Cases={\n'
 browser=[]
 for c in subset:
  luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+(','+'Fragment='+json.dumps(c['Fragment']) if c.get('Fragment') else '')+',SVG=[===['+c['SVG']+']===]},\n'
  xml=ET.fromstring(c['SVG']);scripts=[]
  for node in list(xml):
   if node.tag=='{'+NS+'}script':scripts.append(node.text or '');xml.remove(node)
  # Keep original serialization/prefixes; extract only the known inline script section.
  svg=c['SVG'];start=svg.find('<script>')
  if start>=0:svg=svg[:start]+svg[svg.index('</script>',start)+9:]
  browser.append(dict(c,SVG=svg,Scripts=scripts))
 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]=luau+'}}\n'
 outputs[folder/page]=template.replace('@@TITLE@@',title).replace('@@CASES@@',json.dumps(browser,ensure_ascii=False).replace('<','\\u003c')).replace('@@FONTS@@',json.dumps(faces))
for path,content in outputs.items():
 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'
 else:path.write_text(content,encoding='utf8')
print('S41/S42: eight boards, same JavaScript sources, native view fragments, three pages synchronized/checked.')
