"""S31/S32 native SVG parity boards, generated with identical Luau source."""
from pathlib import Path
import hashlib,json,sys,base64
ROOT=Path(__file__).resolve().parent.parent
folder=ROOT/'examples/svg-tests'
specs=[]
def add(n,c,s):specs.append((n,c,s))
def label(text,x,y):return f'<text x="{x}" y="{y}" font-size="15" fill="#172033">{text}</text>'
def filt(id,body,attrs=''):return f'<filter id="{id}" color-interpolation-filters="sRGB" {attrs}>{body}</filter>'
def ring(x,y,id=None):return f'<g'+(f' filter="url(#{id})"' if id else '')+f'><path d="M{x-45} {y-45}h90v90h-90z M{x-22} {y-22}v44h44v-44z" fill="#2563eb" fill-rule="evenodd"/><path d="M{x+60} {y+40}v-80h35" fill="none" stroke="#ef4444" stroke-width="10"/></g>'
def group(body,id):return f'<g filter="url(#{id})">{body}</g>'
wide='x="-40%" y="-50%" width="180%" height="200%"'
add('S31-blur','Gleiche hohle Form mit scharfer Ecke: links oben Original, rechts sigma=4; unten nur horizontal (7,0) bzw. nur vertikal (0,7). Loecher und Konturtransparenz bleiben erhalten.', '<defs>'+''.join(filt(id,f'<feGaussianBlur stdDeviation="{s}"/>',wide) for id,s in [('both','4'),('x','7 0'),('y','0 7')])+'</defs>'+label('Original',25,22)+label('sigma 4',260,22)+label('sigma 7 / 0',25,172)+label('sigma 0 / 7',260,172)+ring(75,85)+ring(310,85,'both')+ring(75,235,'x')+ring(310,235,'y'))
# offsets include a bounding-box-relative displacement and transformed source.
add('S31-offset','Rot umrandet ist die Ausgangsposition. Blau wurde um +30/+15, -20/-10 oder um 25 % der Fuellbox verschoben. Unten rechts wirkt der Offset entlang einer gedrehten SVG-Achse.', '<defs>'+filt('p','<feOffset dx="30" dy="15"/>',wide)+filt('n','<feOffset dx="-20" dy="-10"/>',wide)+filt('box','<feOffset dx=".25" dy=".25"/>',wide+' primitiveUnits="objectBoundingBox"')+'</defs>'+''.join(f'<g'+(' transform="rotate(-20 340 235)"' if i==3 else '')+'>'+f'<rect x="{x}" y="{y}" width="100" height="65" fill="none" stroke="#ef4444"/>'+f'<rect x="{x}" y="{y}" width="100" height="65" fill="#2563eb" filter="url(#{id})"/></g>' for i,(x,y,id) in enumerate([(45,45,'p'),(310,45,'n'),(45,205,'box'),(310,205,'p')])))
# Drop shadow shorthand vs equivalent primitive graph.
shadow='<feDropShadow dx="12" dy="10" stdDeviation="4" flood-color="#7c3aed" flood-opacity=".7"/>'
manual='<feGaussianBlur in="SourceAlpha" stdDeviation="4"/><feOffset dx="12" dy="10" result="blur"/><feFlood flood-color="#7c3aed" flood-opacity=".7"/><feComposite in2="blur" operator="in"/><feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>'
add('S31-shadow','Links feDropShadow, rechts dieselbe Operation aus fuenf Filterprimitiven. Oben Ring, unten echte Schriftkonturen. Schattenfarbe, Versatz, weiche Kanten und Innenraeume sollen uebereinstimmen.', '<defs>'+filt('shadow',shadow,wide)+filt('manual',manual,wide)+'</defs>'+label('feDropShadow',25,22)+label('einzelne Primitive',260,22)+ring(75,95,'shadow')+ring(310,95,'manual')+''.join(f'<text x="{x}" y="270" font-size="76" font-weight="700" fill="#2563eb" filter="url(#{id})">SVG</text>' for x,id in [(20,'shadow'),(255,'manual')]))
add('S31-regions','Oben: identischer Blur in weiter bzw. absichtlich enger Filterregion. Unten links halbtransparenter Ring mit Schatten nach links oben, rechts eine isolierte feFlood-Farbfläche mit 50 % Alpha.', '<defs>'+filt('wide','<feGaussianBlur stdDeviation="7"/>',wide)+filt('tight','<feGaussianBlur stdDeviation="7"/>','x="0" y="0" width="1" height="1"')+filt('shadow','<feDropShadow dx="-15" dy="-12" stdDeviation="3" flood-color="#ef4444"/>',wide)+filt('flood','<feFlood flood-color="#16a34a" flood-opacity=".5"/>')+'</defs>'+''.join(f'<rect x="{x}" y="35" width="145" height="90" fill="#2563eb" filter="url(#{id})"/><rect x="{x}" y="35" width="145" height="90" fill="none" stroke="#ef4444"/>' for x,id in [(35,'wide'),(295,'tight')])+group('<circle cx="100" cy="235" r="36" fill="none" stroke="#2563eb" stroke-width="15" stroke-opacity=".5"/>','shadow')+'<rect x="300" y="195" width="130" height="80" fill="blue" filter="url(#flood)"/>')
# Two offset overlapping disks derived from SourceAlpha allow general graph composition.
def branches():return '<feFlood flood-color="#ef4444"/><feComposite in2="SourceAlpha" operator="in" result="red"/><feOffset in="SourceAlpha" dx="38"/><feFlood flood-color="#2563eb" result="blue"/><feComposite in="blue" in2="SourceAlpha" operator="in"/><feOffset dx="38" result="blueDisk"/>'
def disc(x,y,id):return f'<circle cx="{x}" cy="{y}" r="32" fill="black" filter="url(#{id})"/>'
region='x="-20%" y="-20%" width="200%" height="140%"'
ops=['over','in','out','atop','xor','lighter']
add('S32-composite','Rot ist in, Blau ist in2. Sechs Porter-Duff-Operatoren: over, in, out, atop, xor, lighter. Form und Farbe der Ueberlappung vergleichen.', '<defs>'+''.join(filt(op,branches()+f'<feComposite in="red" in2="blueDisk" operator="{op}"/>',region) for op in ops)+'</defs>'+''.join(label(op,20+(i%3)*155,30+(i//3)*155)+disc(58+(i%3)*155,92+(i//3)*155,op) for i,op in enumerate(ops)))
blend=['normal','multiply','screen','darken','lighten','difference']
add('S32-blend','Dieselben roten und blauen Scheiben in sechs Mischmodi. Beide Formen bleiben sichtbar; der Mischmodus veraendert die Ueberlappung.', '<defs>'+''.join(filt(op,branches()+f'<feBlend in="red" in2="blueDisk" mode="{op}"/>',region) for op in blend)+'</defs>'+''.join(label(op,20+(i%3)*155,30+(i//3)*155)+disc(58+(i%3)*155,92+(i//3)*155,op) for i,op in enumerate(blend)))
ks=[('0 .5 .5 0','0.5 in + 0.5 in2'),('1 0 0 0','in × in2'),('0 1 -1 0','in - in2'),('0 0 0 .25','konstant 0.25')]
add('S32-arithmetic','Vier arithmetic-Rechnungen auf premultiplizierten RGBA-Kanaelen. Die letzte erzeugt eine 25-%-weisse Flaeche in der gesamten Filterregion; die Multiplikation bleibt nur in der Ueberlappung sichtbar.', '<defs>'+''.join(filt('a'+str(i),branches()+'<feComposite in="red" in2="blueDisk" operator="arithmetic" '+ ' '.join(f'k{n+1}="{v}"' for n,v in enumerate(k.split()))+'/>',region) for i,(k,_) in enumerate(ks))+'</defs>'+''.join(label(name,20+(i%2)*235,30+(i//2)*155)+disc(75+(i%2)*235,95+(i//2)*155,'a'+str(i)) for i,(_,name) in enumerate(ks)))
add('S32-merge','Oben links erst Rot, dann Blau; rechts umgekehrte Merge-Reihenfolge. Unten zwei verschiedenfarbige Schatten hinter einem Bild mit transparentem Loch. Die letzte MergeNode liegt jeweils oben.', '<defs>'+filt('rb',branches()+'<feMerge><feMergeNode in="red"/><feMergeNode in="blueDisk"/></feMerge>',region)+filt('br',branches()+'<feMerge><feMergeNode in="blueDisk"/><feMergeNode in="red"/></feMerge>',region)+filt('multi','<feDropShadow dx="10" dy="8" stdDeviation="3" flood-color="#7c3aed"/><feDropShadow dx="-10" dy="-8" stdDeviation="3" flood-color="#16a34a"/>',wide)+'</defs>'+label('Rot → Blau',25,25)+disc(80,85,'rb')+label('Blau → Rot',260,25)+disc(315,85,'br')+'<image href="S21-source.png" x="135" y="175" width="210" height="120" preserveAspectRatio="none" filter="url(#multi)"/>')
faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=weight,Style=style) for face,weight,style in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]

png=(folder/'S21-source.png').read_bytes()
font=b''.join(base64.b64decode(face['Data']) for face in faces)

cases=[dict(Name=n,Caption=c,SVG='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+svg+'\n</svg>\n') for n,c,svg in specs]

outputs={folder/(c['Name']+'.svg'):c['SVG'] for c in cases}
for stage,title,subset,module,page in [('S31','S31 · Blur und Schatten',cases[:4],'SpatialFilterSources','s31.html'),('S32','S32 · Filter-Komposition',cases[4:],'CompositeFilterSources','s32.html'),('S31_S32','S31 + S32 · Raeumliche Filter und Komposition',cases,'SpatialCompositeSources','s31-s32.html')]:

 digest=hashlib.sha256(''.join(c['SVG'] for c in subset).encode()+font+png).hexdigest()

 luau='--!strict\n-- Generated by scripts/sync-svg-spatial-filters.py.\nlocal imageSource=require(script.Parent.ImageClipSources)\nreturn {ResolveImage=imageSource.ResolveImage,Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",Cases={\n'

 for c in subset:luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+',SVG=[===['+c['SVG']+']===]},\n'

 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]=luau+'}}\n'

 html='''<!doctype html><html lang="de"><meta charset="utf-8"><title>TITLE</title>

<style>body{margin:24px;font:14px Arial,sans-serif;color:#172033;background:#eef2f7}h1{font-size:20px}a{color:#245fb2}.board{display:block;outline:1px solid #aab4c3;background:conic-gradient(#fff 25%,#ddd 0 50%,#fff 0 75%,#ddd 0);background-size:32px 32px;margin-top:16px}.caption{margin:10px 0 16px;max-width:900px}</style>

<h1>TITLE</h1><p>Gleiche Source-Sans-Pro-Datei in Browser und Roblox. Tasten 1 / 2 / 3: 240 / 480 / 960 px · R: 20 Neuaufbauten.</p><p><a href="s29-s30.html">S29 / S30 ansehen</a></p><div id="cases"></div>

<script>

const sources=CASES, font=FONT;const png=PNG;let width=480, urls=[];

function render(){const host=document.querySelector('#cases');host.replaceChildren();for(const url of urls)URL.revokeObjectURL(url);urls=[];for(const item of sources){const parsed=new DOMParser().parseFromString(item.SVG,'image/svg+xml');if(parsed.querySelector('parsererror'))throw Error(item.Name);for(const image of parsed.querySelectorAll('image')){if(image.getAttribute('href')==='S21-source.png')image.setAttribute('href',png)}const svg=parsed.documentElement;const style=parsed.createElementNS(svg.namespaceURI,'style');style.textContent=font.map(f=>'@font-face{font-family:"Source Sans Pro";src:url(data:font/ttf;base64,'+f.Data+') format("truetype");font-weight:'+f.Weight+';font-style:'+f.Style+'}').join('');svg.prepend(style);svg.setAttribute('width','100%');svg.setAttribute('height','100%');const board=document.createElement('div');board.className='board';board.style.width=width+'px';board.style.height=320*width/480+'px';const frame=document.createElement('iframe');frame.title=item.Name;frame.style.cssText='border:0;width:100%;height:100%;display:block';const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'}));urls.push(url);frame.src=url;board.append(frame);const caption=document.createElement('p');caption.className='caption';caption.textContent=item.Caption;frame.addEventListener('load',async()=>{try{const sets=await Promise.all(font.map(f=>frame.contentDocument.fonts.load(f.Style+' '+f.Weight+' 32px "Source Sans Pro"')));if(sets.some(s=>!s.length))throw Error('Font fehlt');frame.dataset.fontReady='true'}catch(error){caption.textContent+=' FONT-LADEFEHLER: '+error.message}});host.append(board,caption)}}

addEventListener('keydown',e=>{if(e.repeat)return;const size={'1':240,'2':480,'3':960}[e.key];if(size){width=size;render()}else if(e.key.toLowerCase()==='r'){for(let n=0;n<20;n++)render()}});render();

</script></html>

'''.replace('TITLE',title).replace('CASES',json.dumps(subset,ensure_ascii=False).replace('<','\\u003c')).replace('font=FONT;', 'font='+json.dumps(faces)+';').replace('const png=PNG;', 'const png='+json.dumps('data:image/png;base64,'+base64.b64encode(png).decode())+';')
 outputs[folder/page]=html

for path,content in outputs.items():

 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'

 else:path.write_text(content,encoding='utf8')

print('S31/S32: eight native SVG boards and three comparison pages synchronized/checked.')

