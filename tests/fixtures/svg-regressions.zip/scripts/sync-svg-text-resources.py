"""Shared textPath and text resource fixtures. Browser embeds the exact licensed font bytes."""

from pathlib import Path

import hashlib,json,sys,base64

ROOT=Path(__file__).resolve().parent.parent

folder=ROOT/'examples/svg-tests'

specs=[
('S27-curves','S27: Derselbe Text folgt drei roten Pfaden: S-Kurve, Kreisbogen und geschlossener Kreis. Die Glyphen drehen sich entlang der Tangente; ihre Grundlinien bleiben am Pfad.', """
<defs><path id="wave" d="M20 75 C120 -10 210 150 450 55"/><path id="arc" d="M30 205 A180 80 0 0 1 420 205"/><path id="circle" d="M240 275 A60 60 0 1 1 240 155 A60 60 0 1 1 240 275 Z"/></defs>
<g fill="none" stroke="#ef4444"><use href="#wave"/><use href="#arc"/><use href="#circle"/></g>
<g font-size="24" fill="#172033"><text><textPath href="#wave" startOffset="15">H x p am Pfad</textPath></text><text><textPath href="#arc" startOffset="15">H x p am Pfad</textPath></text><text font-size="20"><textPath href="#circle" startOffset="10">H x p am Pfad</textPath></text></g>"""),
('S27-offsets','S27: Gerade Pfade mit 0 %, 25 % und 50 % startOffset. Blaue Marken bei x=20/120/220. Unten ist der Text mittig auf der 50-%-Marke verankert.', """
<defs><path id="a" d="M20 70 H420"/><path id="b" d="M20 160 H420"/><path id="c" d="M20 250 H420"/></defs>
<g fill="none" stroke="#ef4444"><use href="#a"/><use href="#b"/><use href="#c"/></g><path d="M20 35V90 M120 125V180 M220 215V275" stroke="#2563eb"/>
<g font-size="30" fill="#172033"><text><textPath href="#a" startOffset="0%">Start am Pfad</textPath></text><text><textPath href="#b" startOffset="25%">Start am Pfad</textPath></text><text text-anchor="middle"><textPath href="#c" startOffset="50%">Start am Pfad</textPath></text></g>"""),
('S27-path-style','S27: Oben ein transformierter Pfad mit verschiedenfarbigen tspan-Abschnitten und dy-Abstand. Unten kurze Linie: Glyphen mit Mittelpunkten hinter dem Pfadende verschwinden.', """
<defs><path id="p" d="M0 0 C60 -45 160 65 350 0" transform="translate(40 100) rotate(5)"/><path id="short" d="M30 240 H160"/></defs>
<g fill="none" stroke="#ef4444"><use href="#p"/><use href="#short"/></g>
<text font-size="26" fill="#172033"><textPath href="#p" startOffset="10"><tspan>Am </tspan><tspan fill="#2563eb" dy="-8">roten </tspan><tspan fill="#15803d" dy="8">Pfad</tspan></textPath></text>
<text font-size="32" fill="#172033"><textPath href="#short">ABC DEFGHI</textPath></text>"""),
('S27-lines','S27: Links tspan-Zeilen mit relativen dy-Abstaenden, rechts dieselben Zeilen mit absoluten y-Positionen. Beide nutzen explizite SVG-Zeilen. Rote Baselines bei 70/110/150. CSS-Zeilenumbruch und automatischer Wortumbruch bleiben offen.', """
<path d="M20 70H450 M20 110H450 M20 150H450" stroke="#ef4444"/>
<text x="20" y="70" font-size="26" fill="#172033"><tspan x="20">Zeile A</tspan><tspan x="20" dy="40">Zeile B</tspan><tspan x="20" dy="40">Zeile C</tspan></text>
<text font-size="26" fill="#2563eb"><tspan x="255" y="70">Zeile A</tspan><tspan x="255" y="110">Zeile B</tspan><tspan x="255" y="150">Zeile C</tspan></text>"""),
('S28-text-clip','S28: Rasterbild durch echte SVG-Buchstabenkonturen. Oben SVG, unten B O: Die Innenraeume bleiben ausgeschnitten. Die rote Hilfslinie zeigt die Bildgrenze.', """
<defs><clipPath id="letters"><text x="35" y="145" font-size="150" font-weight="700">SVG</text><text x="110" y="290" font-size="150" font-weight="700">B O</text></clipPath></defs>
<image href="S21-source.png" x="20" y="20" width="440" height="280" preserveAspectRatio="none" clip-path="url(#letters)"/>
<rect x="20" y="20" width="440" height="280" fill="none" stroke="#ef4444"/>"""),
('S28-text-mask','S28: Gleiche Buchstaben und gleicher Schwarz-Weiss-Verlauf. Oben Luminanzmaske: links ausgeblendet. Unten Alphamaske: alle Buchstaben sichtbar. Echte Glyphenalpha statt TextLabels.', """
<defs><linearGradient id="fade"><stop stop-color="black"/><stop offset="1" stop-color="white"/></linearGradient><mask id="l"><text x="25" y="145" font-size="145" font-weight="700" fill="url(#fade)">SVG</text></mask><mask id="a" mask-type="alpha"><text x="25" y="290" font-size="145" font-weight="700" fill="url(#fade)">SVG</text></mask></defs>
<rect x="20" y="20" width="440" height="280" fill="#2563eb" mask="url(#l)"/><rect x="20" y="20" width="440" height="280" fill="#7c3aed" mask="url(#a)"/>"""),
('S28-text-pattern','S28: Oben werden Aa-Glyphen selbst zu einem wiederholten Muster. Unten fuellt dieses Muster grosse SVG-Buchstaben. Die Musterzelle ist 48 x 36 SVG-Einheiten.', """
<defs><pattern id="type" width="48" height="36" patternUnits="userSpaceOnUse"><rect width="48" height="36" fill="#dbeafe"/><text x="4" y="25" font-size="24" fill="#2563eb">Aa</text></pattern></defs>
<rect x="20" y="20" width="440" height="95" fill="url(#type)"/>
<text x="25" y="280" font-size="155" font-weight="700" fill="url(#type)" stroke="#172033" stroke-width="1">SVG</text>"""),
('S28-path-clip','S28: Text auf einer Kurve dient als Clip fuer ein Rasterbild. Darunter eine gedrehte maskierte Schriftgruppe. Konturen, Pfadposition und Transformation greifen gemeinsam.', """
<defs><path id="curve" d="M25 135 Q210 0 445 135"/><clipPath id="curved"><text font-size="52" font-weight="700"><textPath href="#curve" startOffset="15">SVG am Pfad</textPath></text></clipPath><mask id="letters"><text x="50" y="260" font-size="100" font-weight="700" fill="white">Text</text></mask></defs>
<use href="#curve" fill="none" stroke="#ef4444"/><image href="S21-source.png" width="480" height="190" preserveAspectRatio="none" clip-path="url(#curved)"/>
<g transform="rotate(-8 240 240)"><rect x="20" y="165" width="420" height="130" fill="#16a34a" mask="url(#letters)"/></g>""")]
faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=weight,Style=style) for face,weight,style in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]

png=(folder/'S21-source.png').read_bytes()
font=b''.join(base64.b64decode(face['Data']) for face in faces)

cases=[dict(Name=n,Caption=c,SVG='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+svg+'\n</svg>\n') for n,c,svg in specs]

outputs={folder/(c['Name']+'.svg'):c['SVG'] for c in cases}
# Preserve the user-observed unsupported CSS line-break case as a known difference.
outputs[folder/'S27-lines-css-known-difference.svg']='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">\n<path d="M20 70H450 M20 110H450 M20 150H450" stroke="#ef4444"/>\n<text x="20" y="70" font-size="26" fill="#172033"><tspan x="20">Zeile A</tspan><tspan x="20" dy="40">Zeile B</tspan><tspan x="20" dy="40">Zeile C</tspan></text>\n<text x="255" y="70" font-size="26" fill="#2563eb" style="white-space:pre;line-height:40px">Zeile A\nZeile B\nZeile C</text>\n</svg>\n'

for stage,title,subset,module,page in [('S27','S27 · Text auf Pfaden',cases[:4],'PathTextSources','s27.html'),('S28','S28 · Text als Ressource',cases[4:],'TextResourceSources','s28.html'),('S27_S28','S27 + S28 · Textpfade und Textressourcen',cases,'TextPathResourceSources','s27-s28.html')]:

 digest=hashlib.sha256(''.join(c['SVG'] for c in subset).encode()+font+png).hexdigest()

 luau='--!strict\n-- Generated by scripts/sync-svg-text-resources.py.\nlocal imageSource=require(script.Parent.ImageClipSources)\nreturn {ResolveImage=imageSource.ResolveImage,Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",Cases={\n'

 for c in subset:luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+',SVG=[===['+c['SVG']+']===]},\n'

 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]=luau+'}}\n'

 html='''<!doctype html><html lang="de"><meta charset="utf-8"><title>TITLE</title>

<style>body{margin:24px;font:14px Arial,sans-serif;color:#172033;background:#eef2f7}h1{font-size:20px}a{color:#245fb2}.board{display:block;outline:1px solid #aab4c3;background:conic-gradient(#fff 25%,#ddd 0 50%,#fff 0 75%,#ddd 0);background-size:32px 32px;margin-top:16px}.caption{margin:10px 0 16px;max-width:900px}</style>

<h1>TITLE</h1><p>Gleiche Source-Sans-Pro-Datei in Browser und Roblox. Tasten 1 / 2 / 3: 240 / 480 / 960 px · R: 20 Neuaufbauten.</p><p><a href="s25-s26.html">S25 / S26 ansehen</a></p><div id="cases"></div>

<script>

const sources=CASES, font=FONT;const png=PNG;let width=480, urls=[];

function render(){const host=document.querySelector('#cases');host.replaceChildren();for(const url of urls)URL.revokeObjectURL(url);urls=[];for(const item of sources){const parsed=new DOMParser().parseFromString(item.SVG,'image/svg+xml');if(parsed.querySelector('parsererror'))throw Error(item.Name);for(const image of parsed.querySelectorAll('image')){if(image.getAttribute('href')==='S21-source.png')image.setAttribute('href',png)}const svg=parsed.documentElement;const style=parsed.createElementNS(svg.namespaceURI,'style');style.textContent=font.map(f=>'@font-face{font-family:"Source Sans Pro";src:url(data:font/ttf;base64,'+f.Data+') format("truetype");font-weight:'+f.Weight+';font-style:'+f.Style+'}').join('');svg.prepend(style);svg.setAttribute('width','100%');svg.setAttribute('height','100%');const board=document.createElement('div');board.className='board';board.style.width=width+'px';board.style.height=320*width/480+'px';const frame=document.createElement('iframe');frame.title=item.Name;frame.style.cssText='border:0;width:100%;height:100%;display:block';const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'}));urls.push(url);frame.src=url;board.append(frame);const caption=document.createElement('p');caption.className='caption';caption.textContent=item.Caption;frame.addEventListener('load',async()=>{try{const sets=await Promise.all(font.map(f=>frame.contentDocument.fonts.load(f.Style+' '+f.Weight+' 32px "Source Sans Pro"')));if(sets.some(s=>!s.length))throw Error('Font fehlt');frame.dataset.fontReady='true'}catch(error){caption.textContent+=' FONT-LADEFEHLER: '+error.message}});host.append(board,caption)}}

addEventListener('keydown',e=>{if(e.repeat)return;const size={'1':240,'2':480,'3':960}[e.key];if(size){width=size;render()}else if(e.key.toLowerCase()==='r'){for(let n=0;n<20;n++)render()}});render();

</script></html>

'''.replace('TITLE',title).replace('CASES',json.dumps(subset,ensure_ascii=False).replace('<','\\u003c')).replace('font=FONT;', 'font='+json.dumps(faces)+';').replace('const png=PNG;', 'const png='+json.dumps('data:image/png;base64,'+base64.b64encode(png).decode())+';')
 outputs[folder/page]=html

for path,content in outputs.items():

 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'

 else:path.write_text(content,encoding='utf8')

print('S27/S28: eight native SVG boards and three comparison pages synchronized/checked.')

