"""Shared native SVG text fixtures. Browser embeds the exact licensed font bytes."""

from pathlib import Path

import hashlib,json,sys,base64

ROOT=Path(__file__).resolve().parent.parent

folder=ROOT/'examples/svg-tests'

specs=[

('S25-baselines','S25: Drei Basislinien mit H x p Äg. Die senkrechte Linie bei x=240 markiert links/start, mittig/middle und rechts/end. Buchstabenunterlängen reichen unter die rote Linie.', '''

<path d="M20 70H460 M20 165H460 M20 260H460 M240 20V300" fill="none" stroke="#ef4444" stroke-width="1"/>

<g font-size="32" fill="#172033"><text x="240" y="70">H x p Äg</text><text x="240" y="165" text-anchor="middle">H x p Äg</text><text x="240" y="260" text-anchor="end">H x p Äg</text></g>'''),

('S25-spans','S25: Oben gemischte tspan-Größen auf derselben Grundlinie. Mitte: x/y-Listen sowie dx/dy. Unten drei einzelne Text-Chunks, jeweils mittig verankert; ein tspan ohne x setzt den Text fort.', '''

<path d="M20 80H460 M20 170H460 M80 210V300 M240 210V300 M400 210V300" fill="none" stroke="#ef4444"/>

<text x="20" y="80" font-size="24" fill="#172033">H<tspan font-size="48" fill="#2563eb"> x </tspan><tspan font-size="32" fill="#15803d">p Äg</tspan></text>

<text x="25 100 185" y="170" font-size="32" fill="#172033">ABC<tspan dx="14" dy="12" fill="#2563eb">DE</tspan></text>

<text x="80" y="265" text-anchor="middle" font-size="30">A<tspan x="240">B</tspan><tspan x="400">C</tspan></text>'''),

('S25-spacing','S25: Oben normalisierte Leerzeichen und darunter erhaltener Leerraum. Mitte Buchstaben- und Wortabstände. Unten alphabetic und middle an der gleichen roten Linie.', '''

<g font-size="26" fill="#172033"><text x="20" y="45">A   B   C</text><text x="20" y="95" xml:space="preserve">A   B   C</text><text x="20" y="160" letter-spacing="5">Abstand</text><text x="20" y="215" word-spacing="16">A B C</text></g>

<path d="M20 285H460" stroke="#ef4444"/>

<g font-size="32" fill="#172033"><text x="20" y="285">Hxp</text><text x="200" y="285" dominant-baseline="middle">Hxp</text></g>'''),

('S25-fonts','S25: Vier echte Schriftschnitte derselben Familie: Regular, Bold, Italic und Bold Italic. Kein künstlich verbreiterter oder schräg gestellter Regular-Text.', '''

<g font-size="36" fill="#172033"><text x="20" y="65">Regular Äg</text><text x="20" y="135" font-weight="bold">Bold Äg</text><text x="20" y="205" font-style="italic">Italic Äg</text><text x="20" y="275" font-weight="700" font-style="italic">Bold Italic Äg</text></g>'''),

('S26-length','S26: Oben natürliche Breite. Mitte textLength=200 mit spacing: Buchstaben bleiben breit. Unten spacingAndGlyphs: auch die Konturen werden gestreckt. Der blaue Rahmen ist jeweils exakt 200 px breit.', '''

<g fill="none" stroke="#3b82f6"><rect x="30" y="25" width="200" height="55"/><rect x="30" y="120" width="200" height="55"/><rect x="30" y="215" width="200" height="55"/></g>

<g font-size="36" fill="#172033"><text x="30" y="65">SVG Text</text><text x="30" y="160" textLength="200" lengthAdjust="spacing">SVG Text</text><text x="30" y="255" textLength="200" lengthAdjust="spacingAndGlyphs">SVG Text</text></g>'''),

('S26-paint','S26: Echte Textkonturen: nur Umriss, Verlauf über die ganze Zeile und 50 % Gruppen-Deckkraft. Unten Zeichenrotation; der letzte rotate-Wert gilt für die restlichen Zeichen weiter.', '''

<defs><linearGradient id="ink"><stop stop-color="#ef4444"/><stop offset="1" stop-color="#2563eb"/></linearGradient></defs>

<text x="20" y="65" font-size="48" fill="none" stroke="#2563eb" stroke-width="1.5">Outline</text>

<text x="20" y="135" font-size="48" fill="url(#ink)">Gradient</text>

<g opacity=".5"><text x="20" y="200" font-size="42" fill="#7c3aed">Alpha</text></g>

<path d="M20 270H460" stroke="#ef4444"/>

<text x="30" y="270" font-size="36" rotate="-15 0 15">ABCDE</text>'''),

('S26-shaping','S26: Oben Kerning und Standardligaturen, darunter beides deaktiviert. Mitte Ä und A + kombinierendes Trema: gleiche Kontur. Unten direction=rtl mit lateinischem Text und rechts ein explizites bidi-override. Vollständiges Unicode-Bidi/arabisches Shaping ist noch offen.', '''

<g fill="#172033" font-size="34"><text x="20" y="55">AV ff fft</text><text x="20" y="110" style="font-kerning:none;font-variant-ligatures:none">AV ff fft</text><text x="20" y="180">Ä A&#x308;</text></g>

<path d="M200 220V300 M450 220V300 M20 270H460" stroke="#ef4444"/>

<g fill="#172033" font-size="28"><text x="200" y="270" direction="rtl">ABC</text><text x="450" y="270" direction="rtl" unicode-bidi="bidi-override">ABC</text></g>'''),

('S26-vertical','S26: Lateinischer Text mit vertical-rl (links), vertical-lr (Mitte) und aufrechten Zeichen (rechts). Die roten Linien markieren die vertikale Textachse. Vertikales OpenType-Shaping für CJK bleibt separat offen.', '''

<path d="M90 20V300 M240 20V300 M390 20V300" stroke="#ef4444"/>

<g fill="#172033" font-size="32"><text x="90" y="30" writing-mode="vertical-rl">ABC</text><text x="240" y="30" writing-mode="vertical-lr">ABC</text><text x="390" y="30" writing-mode="vertical-rl" style="text-orientation:upright">ABC</text></g>''')]
faces=[dict(Data=base64.b64encode((ROOT/'examples/fonts'/('SourceSansPro-'+face+'.ttf')).read_bytes()).decode(),Weight=weight,Style=style) for face,weight,style in [('Regular',400,'normal'),('Bold',700,'normal'),('It',400,'italic'),('BoldIt',700,'italic')]]

font=b''.join(base64.b64decode(face['Data']) for face in faces)

cases=[dict(Name=n,Caption=c,SVG='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="320" viewBox="0 0 480 320" font-family="Source Sans Pro">'+svg+'\n</svg>\n') for n,c,svg in specs]

outputs={folder/(c['Name']+'.svg'):c['SVG'] for c in cases}

for stage,title,subset,module,page in [('S25','S25 · SVG-Text',cases[:4],'TextSources','s25.html'),('S26','S26 · Textkonturen und Typografie',cases[4:],'TypographySources','s26.html'),('S25_S26','S25 + S26 · SVG-Text und Typografie',cases,'TextTypographySources','s25-s26.html')]:

 digest=hashlib.sha256(''.join(c['SVG'] for c in subset).encode()+font).hexdigest()

 luau='--!strict\n-- Generated by scripts/sync-svg-text.py.\nreturn {Stage='+json.dumps(stage)+',Title='+json.dumps(title,ensure_ascii=False)+',SourceSHA256="'+digest+'",Cases={\n'

 for c in subset:luau+='{Name='+json.dumps(c['Name'])+',Caption='+json.dumps(c['Caption'],ensure_ascii=False)+',SVG=[===['+c['SVG']+']===]},\n'

 outputs[ROOT/'examples/SVGLab'/(module+'.luau')]=luau+'}}\n'

 html='''<!doctype html><html lang="de"><meta charset="utf-8"><title>TITLE</title>

<style>body{margin:24px;font:14px Arial,sans-serif;color:#172033;background:#eef2f7}h1{font-size:20px}a{color:#245fb2}.board{display:block;outline:1px solid #aab4c3;background:conic-gradient(#fff 25%,#ddd 0 50%,#fff 0 75%,#ddd 0);background-size:32px 32px;margin-top:16px}.caption{margin:10px 0 16px;max-width:900px}</style>

<h1>TITLE</h1><p>Gleiche Source-Sans-Pro-Datei in Browser und Roblox. Tasten 1 / 2 / 3: 240 / 480 / 960 px · R: 20 Neuaufbauten.</p><p><a href="s23-s24.html">S23 / S24 ansehen</a></p><div id="cases"></div>

<script>

const sources=CASES, font=FONT;let width=480, urls=[];

function render(){const host=document.querySelector('#cases');host.replaceChildren();for(const url of urls)URL.revokeObjectURL(url);urls=[];for(const item of sources){const parsed=new DOMParser().parseFromString(item.SVG,'image/svg+xml');if(parsed.querySelector('parsererror'))throw Error(item.Name);const svg=parsed.documentElement;const style=parsed.createElementNS(svg.namespaceURI,'style');style.textContent=font.map(f=>'@font-face{font-family:"Source Sans Pro";src:url(data:font/ttf;base64,'+f.Data+') format("truetype");font-weight:'+f.Weight+';font-style:'+f.Style+'}').join('');svg.prepend(style);svg.setAttribute('width','100%');svg.setAttribute('height','100%');const board=document.createElement('div');board.className='board';board.style.width=width+'px';board.style.height=320*width/480+'px';const frame=document.createElement('iframe');frame.title=item.Name;frame.style.cssText='border:0;width:100%;height:100%;display:block';const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'}));urls.push(url);frame.src=url;board.append(frame);const caption=document.createElement('p');caption.className='caption';caption.textContent=item.Caption;frame.addEventListener('load',async()=>{try{const sets=await Promise.all(font.map(f=>frame.contentDocument.fonts.load(f.Style+' '+f.Weight+' 32px "Source Sans Pro"')));if(sets.some(s=>!s.length))throw Error('Font fehlt');frame.dataset.fontReady='true'}catch(error){caption.textContent+=' FONT-LADEFEHLER: '+error.message}});host.append(board,caption)}}

addEventListener('keydown',e=>{if(e.repeat)return;const size={'1':240,'2':480,'3':960}[e.key];if(size){width=size;render()}else if(e.key.toLowerCase()==='r'){for(let n=0;n<20;n++)render()}});render();

</script></html>

'''.replace('TITLE',title).replace('CASES',json.dumps(subset,ensure_ascii=False).replace('<','\\u003c')).replace('font=FONT;', 'font='+json.dumps(faces)+';')
 outputs[folder/page]=html

for path,content in outputs.items():

 if '--check' in sys.argv:assert path.read_text(encoding='utf8')==content,f'Outdated: {path}'

 else:path.write_text(content,encoding='utf8')

print('S25/S26: eight native SVG boards and three comparison pages synchronized/checked.')

